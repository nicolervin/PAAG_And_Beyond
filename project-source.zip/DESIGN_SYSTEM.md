# Process at a Glance design system

This file defines locked interaction and interface standards for Process at a Glance. New UI work must follow these standards. Existing screens may require separate, explicitly scoped retrofit work.

## Universal Deletion Standard

Every editable table in this app must follow this exact deletion pattern, with no exceptions:

1. On a table with an approved deletion workflow, selecting one or more rows must reveal Streamlit's native **Delete row(s)** action in the table's upper-right toolbar.
2. Clicking the native action initiates deletion but must not persist it immediately. Capture the selected records, reset and rerun the editor so every selected row remains visible, and only then open a confirmation dialog that lists or summarizes the selected records and explains related records that will be deleted, preserved, unassigned, or otherwise affected.
3. The confirmation dialog must not be dismissible by clicking outside it, pressing Escape, or using a close control. Cancel clears the pending request while keeping every selected row visible. The final confirmed action performs the database write, records history, resets the editor, shows a toast, and reruns; only that confirmed rerun removes the rows from the table.
4. Do not add a second trash-can button, separate Delete button beside the table, per-row delete control, or Delete `ButtonColumn`. The native toolbar action is the single table-level entry point.
5. Tables without an approved, relationship-safe deletion workflow must keep the native Delete action hidden. Adding such a workflow still requires explicit project-owner approval.
6. The final confirmation button is the red destructive action and must not require typing a confirmation word.
7. This standard applies to every table in the app, including low-stakes tables like Questions and concerns.

Every approved destructive confirmation or standalone destructive action must use a stable Streamlit widget key beginning with `destructive_`. The entry point uses this prefix to render destructive actions red without styling Cancel actions.

This standard is **locked** and replaces prior inconsistent patterns, including globally hiding Streamlit's native deletion action, Yamazumi's typed-`CLEAR` dialogs, Process at a Glance's single-click **Remove pairing** action, and delete-on-save behavior in Questions and concerns and Feature definitions.

A Parts Catalog row linked from `manufacturing_assemblies.catalog_part_id` cannot be deleted directly. The relationship-aware Parts deletion dialog must identify every selected linked Part number and assembly number, keep confirmation unavailable while any such link exists, and instruct the contributor to delete or merge the assembly first. Deleting an assembly preserves its completed-subassembly Parts Catalog row and every downstream relationship owned by that part.

Retrofitting existing screens to this standard is a separate future task and is not part of this documentation update. Do not modify screen code as part of documenting this standard.

### Approved Task 09 Components v2 exception

**Implementation status:** Active on `Nicole_assembly_grid_editor` as of September 3, 2026.

The project-wide Task 09 assembly grid is the only approved exception to the native-toolbar entry-point requirement in items 1, 2, and 4 above and to the native row-selection checkbox requirement in the Universal Table Row Selection Standard below. Its integrated category, model, assembly, and nested mini-BOM layout requires a Components v2 grid that Streamlit's native table editor cannot represent. The component may therefore use its own selection and deletion controls for assembly-grid categories, direct model mappings, and nested mini-BOM component rows.

The same exception covers the approved multi-section Assembly grid. Selected Fishbone sections appear as separate labeled groups in one workspace with shared model and active-feature filters and one atomic **Save & Refresh** footer. The component must always show the owning Fishbone section for each category group and distinguish completed-subassembly component choices from ordinary Fishbone parts. Multi-section display does not weaken the existing confirmation, deletion disclosure, audit, Undo, or preservation requirements.

The Assembly grid begins with one protected **Top-level packaged unit** row immediately below the active feature headers and before all Fishbone-section headings. It remains visible regardless of the section filter, exposes a required final Built-section selector and optional Installed-section selector, and provides one Part number cell per visible official model. Its mini-BOM may select completed subassemblies from any active Fishbone section; ordinary parts remain limited to exact uses in the selected final Built section. The structural row has no category-delete control, although its model mappings and mini-BOM rows retain the approved confirmation behavior below.

This exception changes only where the deletion request begins. The component must never write to the database or remove a row by itself. It sends stable record identifiers to Python, which resets and reruns the draft as needed and opens the same non-dismissible, relationship-aware Streamlit confirmation required everywhere else. The dialog must list or summarize the selected records and disclose what will be deleted, preserved, or otherwise affected. Cancel preserves the records and clears the pending request. Confirmation validates the complete action, performs one atomic store-layer write, records Current editor history, resets the component, shows a toast, and reruns.

For Task 09 specifically:

- Clearing a direct model mapping deletes only the mapping row. The real `manufacturing_assemblies` record and its mini-BOM, rules, images, nesting, and uploaded files remain unchanged.
- Deleting an assembly-grid category deletes its mapping rows but preserves every mapped assembly and all assembly-owned data.
- Deleting a nested mini-BOM component removes only the selected `manufacturing_assembly_components` row; its Fishbone use and Parts Catalog record remain.
- Reassigning a blank mapping cell to an existing assembly, or renaming a mapped assembly to an unused number, is an ordinary edit and does not require deletion confirmation.
- Editing a mapped cell to a number already owned by another same-category assembly is a narrowly scoped merge action because it deletes the superseded old assembly. **Save & Refresh** must open a non-dismissible dialog that names the old and target numbers, states that the old assembly record will be deleted, discloses every affected relationship and dependent-record count, and explains that the target assembly's existing mini-BOM will appear in the redirected cells. Cancel preserves the draft and both records. Confirmation performs the mapping redirection and old-record deletion atomically, records Current editor history under both the grid mapping and Assemblies catalog categories, resets the grid, shows a toast, and reruns.
- Outside that confirmed same-category merge, deleting a real assembly remains available only through the existing full Task 04 assembly-deletion workflow.

All destructive confirmation widget keys still begin with `destructive_`. No other custom component or screen inherits this exception; every other table continues to require the native Streamlit deletion entry point.

## Universal Table Row Selection Standard

Every data table in this app must show Streamlit's native row-selection checkboxes on the far left. The unlabeled checkbox in the upper-left corner must select or clear all rows currently visible in the table with one click.

Selection is transient and does not write data by itself. On editable tables, the native checkboxes expose deletion intent through the editor's `deleted_rows` state; they are not a supported general-purpose bulk-selection event. On tables with an approved deletion workflow, the native Delete action converts that intent into a pending confirmed deletion. Editable tables that need an ordinary bulk action must add a compact read-only native-selection surface for that action unless Streamlit later provides supported editor selection events. Filters define which rows are currently visible and therefore which rows the upper-left checkbox selects.

Use the shared table conventions in `utils/table_ui.py`: read-only tables use `selectable_dataframe()` and editable tables use native deletion selection through `num_rows="dynamic"` or `num_rows="delete"`. Use `native_selected_rows()` only to resolve that editable-table deletion intent. Show the native Delete toolbar action only when the editor is connected to an approved confirmation workflow. Do not add a named checkbox column or a separate **Select all** control to imitate selection. Where an editable-table business workflow needs ordinary single- or multi-row selection, place a compact `selectable_dataframe()` surface near that action and keep its hidden stable identifiers separate from friendly display values.

This standard is **locked** and applies to every existing and future data table, including Questions and concerns, Fishbone assembly hierarchy tables, previews, and History tables.

## Universal Save Action Standard

Every editable table in this app must use the exact label **Save & Refresh** for its primary save action button, regardless of what is being saved. Do not use table-specific variants such as **Save concerns**, **Save model definitions**, **Save features**, or **Save complexity tree**.

Keep the section title, filters, and sorting controls above the table. Immediately below the table, use the shared footer pattern implemented in `utils/table_ui.py`: the orange **Unsaved changes** indicator, **Undo**, and the blue **Save & Refresh** button with the save icon must appear together in a right-aligned row.

This standard is **locked** and replaces all screen-specific save button labels identified during the current-state audit, including those on Overview, Questions and concerns, all three Model definitions subsections, and Parts to fishbone.

Retrofitting existing screens to this standard is a separate future task. Do not modify screen code as part of documenting this standard.

## Universal Row Creation Standard

Editable tables that permit new records must allow contributors to type or paste one or many spreadsheet rows directly into Streamlit's native blank entry row. Do not expose a separate **Add row** button. Use `direct_entry_editor_rows(..., editor_key=...)` immediately before `st.data_editor(..., num_rows="dynamic")`.

Because Streamlit disables native header sorting when an editor permits row creation, the shared helper supplies external **Sort rows by** and **Descending** controls. Apply sorting before editing; once the editor contains draft changes, pasted rows, or native row selections, the sort controls must remain locked until the contributor saves, undoes, or clears the selection. Approved new-row defaults belong in `st.column_config`. Saving or undoing must clear the editor draft while retaining the chosen saved-row sort. Apply this standard to every existing and future editable table that permits row creation.

## Shared Editable-Table Implementation Checklist

Use `utils/table_ui.py` and `utils/table_filters.py` for every new or modernized data table. These helpers implement the locked standards above and must not be recreated independently in page code.

- Put keyword and relevant dropdown filters above every table with `filter_table()`.
- Put the section title above the filters with `editable_table_heading()`. Put the orange **Unsaved changes** indicator, **Undo**, and blue **Save & Refresh** action immediately below the table with `editable_table_footer()`.
- Use `selectable_dataframe()` for read-only tables and ordinary bulk-action selection. Editable-table native checkboxes expose deletion intent only; never add a named `CheckboxColumn` or separate Select all control.
- Read editable-table deletion targets with `native_selected_rows()`; do not use this helper for ordinary bulk actions. Treat deletion selection as transient UI state and exclude it from change detection with `table_has_unsaved_changes(..., native_row_selection=True)` where applicable.
- Refuse a normal save while editable-table deletion targets remain selected; ordinary bulk actions use their separate read-only selection surface.
- Keep native Sort ascending and Sort descending on read-only tables and editable tables that do not create rows. For `num_rows="dynamic"`, call `direct_entry_editor_rows(..., editor_key=...)` immediately before `st.data_editor()` and use its locked external sort controls.
- When saving a filtered editor, use `merge_filtered_edits()` so rows hidden by filters are preserved. Filters affect only the visible and exported view; they must never delete or overwrite hidden records.
- Mark required fields in `st.column_config` and validate them again with `required_field_errors()` or store-layer validation.
- Convert multi-value database fields to lists for `MultiselectColumn`, then convert them back to their persisted representation before saving. Use `universal_values` in `filter_table()` for values such as All models that match every specific choice.
- Keep stable identifiers separate from friendly display values. Hide internal IDs visually while retaining them for callback and write resolution; remove genuinely sensitive values before data reaches the browser.
- Validate an entire bulk operation before writing. Never partially apply a bulk change because one selected record is invalid.
- Provide bulk editing for meaningful shared fields, subject to the Universal Deletion Standard.
- Use the shared Details/Edit action configuration, and do not change established column sizing unless a request specifically calls for it.
- Export the currently filtered table with `dataframe_to_excel()`.
- Do not impose Draft/In review/Approved as a universal status model. Status values are specific to each business table.

Use this normal save sequence:

1. Read the filtered editor output and native selection.
2. Refuse a normal save if persisted rows remain selected.
3. Validate required fields and business rules.
4. Merge filtered edits into the complete unfiltered data.
5. Convert display labels back to stored identifiers or codes.
6. Call one named store-layer save function.
7. Record the audit event with Current editor attribution and the timestamp returned by the store layer.
8. Request an editor reset, show a success toast, and rerun.

### Editor state and reset behavior

Treat `st.session_state` as browser-session state, not permanent storage. Apply `apply_pending_table_editor_reset(editor_key)` before constructing an editor whose prior state may need clearing. After a successful save or approved destructive action, call `request_table_editor_reset(editor_key)` before rerunning so stale edits and selections cannot replay.

Unsaved-change Undo normally clears the editor's session-state entry and reruns. A complex multi-table workflow may retain a pre-save snapshot in session state when it genuinely needs saved-state Undo; follow the existing Model definitions and Fishbone patterns. Session-state Undo remains limited to the current browser session and is not an audit or version-control mechanism.

## Deferred decisions

Multi-step Undo/Redo (spreadsheet-style, multiple sequential steps backward/forward through edits): considered and intentionally deferred. A feasibility review found it technically possible but high-risk in Streamlit, requiring a new shared edit-history subsystem across all tables. The core problem it was meant to solve — protection against accidental data loss — is instead addressed in part by the Universal Deletion Standard, which removes deletion affordances from editable tables unless a separate workflow is explicitly approved. Revisit multi-step Undo/Redo only as a deliberate future project, not as an incidental addition to any single-screen task.

This is a documentation-only decision. Do not modify screen code as part of documenting it.

## Universal Audit Trail Standard

Every persisted change in this app — every save, delete, and bulk action, on every screen, with no exceptions — must write an entry to `audit_log`. This applies even to screens currently considered low-stakes, such as Questions and concerns, and screens that still have incomplete coverage, including Overview, imports, and most Parts to fishbone changes. Model definitions now records standardized Model information, Feature definitions, and Complexity tree saves and displays their History at the bottom of the page.

Each `audit_log` entry must follow the existing pattern used by compliant screens such as Parts, Process at a Glance, and most of Yamazumi. It must record:

- a logical table or workflow name;
- the action taken;
- the affected row count;
- free-text Current editor attribution;
- JSON details describing what changed; and
- a timestamp.

Use `record_audit_event()` for standardized saves, approved destructive actions, and bulk edits. Include the timestamp supplied by the store layer and `st.session_state.get("current_editor", "")`. Keep action names consistent with the visible workflow, such as `Save & Refresh` or `Bulk edit`; do not create near-duplicate action labels for equivalent events.

This standard is **locked**. Bringing all existing screens into compliance is a separate future retrofit task and is not part of this documentation update. Any new screen or feature built from this point forward must include audit logging from the start. Audit logging is not optional and must not be treated as an item to add later.

This is a documentation-only standard. Do not modify screen code as part of documenting it.

## Universal History Display Standard

Every screen or tab in this app must display a **History** section at the bottom of the page showing that screen's own `audit_log` entries in a consistent, shared layout. Reuse the existing history-display pattern implemented on Parts Catalog and Process at a Glance.

This standard pairs directly with the Universal Audit Trail Standard: if a screen logs events, it must also display them. No screen is exempt, including currently history-less or incomplete screens such as Overview, Questions and concerns, Parts to fishbone, and Pin Map. Model definitions already displays its Model information, Feature definitions, and Complexity tree audit categories in one bottom History expander.

The History section must show, at minimum:

- what changed;
- who made the change, using the free-text Current editor attribution; and
- when the change occurred.

It must use the same visual placement and format on every screen so users always know where to look.

Use `audit_history()` in a bottom expander. When a page has multiple history categories, group them into tabs inside that expander rather than scattering separate History sections through the page.

This standard is **locked**. Retrofitting all existing screens to include this History section is a separate future task and is not part of this documentation update. Any new screen or feature built from this point forward must include a History section from the start.

This is a documentation-only standard. Do not modify screen code as part of documenting it.

## Stable Identifier vs. Friendly Display Name Standard

This app intentionally keeps certain stable identifiers separate from editable friendly display names. This is not an inconsistency — it is a deliberate pattern that allows the friendly label to be renamed or clarified over time without altering the permanent underlying identifier.

Confirmed examples of this intentional pattern from the naming audit include:

- `project_models.model_number` versus `project_models.display_name`;
- `assembly_sections.parent_id` versus its displayed **Parent assembly** name;
- `fishbone_part_assignments.section_id` versus its displayed section name; and
- `pits_records.pits_id` as a fixed source key.

Do not "fix" these pairs by renaming the database identifier to match the friendly label, or vice versa. When building new features, follow this same pattern for any new stable identifier that needs a human-friendly label.

This standard is locked.

This is a documentation-only standard. Do not modify code as part of documenting it.

## Imperial Units Standard

At this stage of the project, all linear dimensional measurements (e.g., height, width, depth, length, distance) are stored AND displayed in imperial units (inches), with no internal metric conversion layer. This replaces the prior pattern of storing values in millimeters and converting to inches for display, which was removed when `work_elements.conveyor_height_mm`, `platform_height_mm`, and `pit_depth_mm` were renamed to `conveyor_height_in`, `platform_height_in`, and `pit_depth_in`.

This standard does not apply to non-dimensional measurements such as time, torque, weight, temperature, or pressure. Those measurements retain their own appropriate units and are unaffected by this standard.

### Yamazumi time units

Each planning scenario saves one Yamazumi-only time unit: **Seconds**, **Minutes**, or **Hours**. Use it consistently for Yamazumi takt controls, work-element entry and tables, metrics, board labels and tooltips, and workbook time values. Always convert back to the canonical seconds fields before persistence; changing the unit must never rewrite existing timing quantities or change relative board-stack heights.

The Yamazumi settings row uses one explicit **Save & Refresh** action for the scenario unit, selected area's takt override, and optional Fishbone pairing shown only for an unlinked imported area. It saves the complete change atomically, records only changed old/new values in Yamazumi History, and refuses a unit change while the work-element editor has unsaved changes. Takt-only and pairing-only changes remain available in that state. A takt matching the scenario target clears the area override. Labels and workbook exports name the active unit.

Project and planning-scenario takt values have separate saved display-unit preferences of **Seconds**, **Minutes**, or **Hours**. Their canonical `takt_time_s` values and Yamazumi area `takt_override_s` values remain seconds. New projects default to Seconds, new scenarios inherit the project's preference, and scenario clones copy the source scenario preference. Every project/scenario takt input places its unit selector beside the value, converts to seconds before saving, and preserves the real duration when only the unit changes. Scenario takt displays use the scenario preference throughout the sidebar, Overview, Yamazumi, Pin Map, and Functional Ergonomics. When takt and Yamazumi work time appear together, label and format each with its own preference so the two units cannot be mistaken for one another.

### Guided Yamazumi pitch initialization

Selecting a Yamazumi area with no pitch addresses opens one non-dismissible native setup dialog per area visit. The dialog and the persistent **Generate pitch addresses** expander share the same project line code, editable Fishbone-derived section code, inclusive numeric range, odd/even option, status, pitch type, feed target, and model-variant controls. Cancel suppresses the prompt until the contributor leaves and returns to that area. Subassembly and Kitter remain unavailable until the area has a receiving pitch.

Generated address suggestions use `LL-SSS-NNN`: a saved two-character project line code, an editable three-character section abbreviation, and a minimum three-digit sequential suffix that expands naturally at 1000. This is guidance rather than a universal address validator; imports, existing values, and direct edits retain their established compatibility and scenario-wide uniqueness rules. A changed project line code affects future suggestions only and never rewrites saved addresses.

The interactive board renders its **Unassigned** lane only while at least one persisted or drafted work element is unassigned. The regular work-element editor and Edit element dialog retain Unassigned as a destination even while that empty lane is hidden.

The **Edit Yamazumi work element** dialog uses its native X, outside-click, and Escape behavior instead of a redundant Cancel button. **Model variants** occupies its own line above the Work type and Work region row. Its red **Delete element** action is a standalone destructive workflow, not a second table-deletion control: it hands off to a non-dismissible confirmation with an explicit Cancel action, identifies the element, and discloses the preserved Process at a Glance step and the Yamazumi relationship and legacy-dependent effects. Cancel restores the edit dialog and its unsaved field values. Confirmation preserves other browser-session board moves, records Current editor history, resets the work-element editor, shows a toast, and reruns.

Rule: any new linear dimensional field added to this app must store and display in inches by default. Do not introduce a metric storage column unless explicitly approved by the project owner.

This standard is locked. It may be revisited in the future if the project requires metric-native data sources or equipment specs; until then, it remains imperial-only.

## Scenario Boundary Indicator Standard

Every screen must display a small, consistently placed badge next to the page title indicating the scope of the data shown, using exactly one of these three states:

1. **Project-wide** — Data here is shared across every planning scenario in the project. Changes affect all scenarios.
2. **Scenario-specific** — Data here belongs only to the currently active planning scenario. Changes do not affect other scenarios.
3. **Scenario-aware** — The underlying data is shared across all scenarios, but some fields or visibility on this screen change depending on which scenario is currently active.

Assign each active screen its correct badge state based on the scope definitions in `DATA_DICTIONARY.md`:

- **Project-wide:** Overview project-identity fields, Questions and concerns, Import/Export Projects, Import/Export PITS, Model definitions, and Fishbone framework/structure.
- **Scenario-specific:** Overview active-scenario fields, Yamazumi, Process at a Glance, and Pin Map.
- **Scenario-aware:** Parts Catalog, where the catalog is project-wide but Active status is scenario-specific; and Parts to fishbone, where the structure is project-wide but visible and active parts depend on the scenario.

Because Overview contains both project-wide identity fields and scenario-specific active-scenario fields, display the applicable badge next to each corresponding section heading as well as maintaining the standard page-title placement, so neither scope is presented ambiguously.

Every badge state must include hover/tooltip text explaining its meaning:

1. **Project-wide** badge tooltip: "Changes on this page affect every planning scenario in this project."
2. **Scenario-specific** badge tooltip: "Changes on this page only affect the [scenario name] scenario. Other scenarios are not affected."
3. **Scenario-aware** badge tooltip: Write this specifically for each screen where it appears, clearly explaining exactly which data is shared across all scenarios and which part is scenario-dependent. Do not use one generic sentence for this badge state across multiple screens.

For Parts Catalog specifically, use: "The parts catalog itself is shared across every scenario. Whether a part is marked Active applies only to the currently selected scenario."

The badge must use consistent colors, wording, and placement on every screen with no exceptions. This standard is locked. Use the shared helpers in `utils/scope_ui.py` for every page title and for Overview's two scoped section headings.

Every **Scenario-specific** and **Scenario-aware** page title must also show the active scenario's revision and name in a dropdown beside the badge. The badge itself stays concise and does not repeat the active scenario name or revision. Changing that dropdown changes the browser session's single active scenario, synchronizes the sidebar selector, and controls the scenario data shown on every subsequent page until the contributor changes it again. When no valid scenario has been selected, default to the newest non-archived scenario returned by the standard scenario ordering.

Every scenario-specific page title must also place a blue **Save as scenario** button immediately beside that scenario dropdown. The shared page-title helper owns this control so new scenario-specific screens receive it automatically. It creates a complete branch from the scenario shown in the adjacent dropdown, makes the new branch the browser session's active scenario, and exposes it immediately in Overview's Planning scenarios table. Scenario-aware and project-wide pages do not receive this button.

## Help Text (Hover) Standard

Any field, column header, section, or control that a collaborator judges as potentially confusing may include an optional help icon (a "?" symbol) placed immediately to the right of its label. This is discretionary — not every field requires one — and any contributor may add one wherever they see fit, without requiring special approval beyond the normal weekly branch review process.

The help icon must use the same hover/tooltip display mechanism as the Scenario Boundary Indicator badges (see above), so all hover help in the app looks and behaves identically regardless of where it appears.

Content rules for help text:

- One to three sentences maximum
- Plain, non-technical language — avoid engineering jargon and internal database terminology
- Explain what the field/control means and, if relevant, why it matters or how it's used downstream
- Do not restate the field's label; add real explanatory value

## Fishbone Section Ordering and Sidebar Context Standard

Every Fishbone-section option list must follow the deterministic depth-first order returned by `assembly_section_walk_order()`: each main-spine section, its recursively nested subassemblies, then the next main-spine section. Siblings retain `(sequence, name)` ordering. Do not substitute alphabetical order or the flat raw `assembly_sections.sequence` order in a selector.

Dropdowns use ancestry breadcrumbs such as **Main line 2 › Wheel Assembly** so nested sections remain understandable without relying on indentation alone. Stable section UUIDs remain the widget values. Special choices such as **All active sections**, **Unlinked**, **Not assigned**, and **Product / main assembly** appear before the ordered business choices. Each workflow retains its established eligibility rules: active-only controls remain active-only, while existing-record and continuity workflows may retain inactive current values.

The upper-left sidebar shows **Fishbone view** only on Assembly grid, Parts to fishbone, Yamazumi, Process at a Glance, and Pin Map. It displays one breadcrumb, **All active sections**, a selected-section count, or **Unlinked**. The selector synchronizes only the page-level view; it must never change a placement destination, parent relationship, Built/Installed value, deletion target, or persisted record.

One exact preferred section and its walk ordinal are browser-session state scoped to the project. Linked pages reuse that section when valid. If it is unavailable, choose the next page-valid section in walk order, then the previous valid section. Assembly grid and Pin Map support **All active sections**; Process at a Glance and Yamazumi require one exact editable context. Yamazumi and Pin Map areas follow their linked Fishbone-section order, with unlinked areas alphabetically last. This context is navigation state only and creates no audit event.

Adding a Fishbone section automatically creates its linked Yamazumi area in every existing planning scenario and records both Fishbone framework and Yamazumi audit history with Current editor attribution. This automatic path creates missing areas only. It must preserve same-name imports and conflicting links unchanged, disclose skipped scenarios, and leave relinking or duplicate cleanup behind the explicit **Repair Fishbone area links** action.

An already linked Yamazumi area must not show a redundant read-only Fishbone field. An imported or legacy area that remains unlinked instead shows **Pair with Fishbone section** using the standard depth-first Fishbone option order; after a successful save and rerun, that control disappears because the relationship is fixed.

## Yamazumi Board Pitch Order Standard

The interactive board presents pitch stacks in numeric-aware, case-insensitive pitch-address order, which is the pitch tier of the area's Op ID sequence. A complete Subassembly or Kitter feed chain appears immediately before its receiving pitch; sibling feeders retain pitch-address order. This ordering is derived UI state only. It must not update `yamazumi_pitches.sequence`, addresses, feed targets, stack contents, audit history, or any other persisted record. The established north/top odd-address and south/bottom even-address rendering remains unchanged.

Draw one continuous red takt line across each assigned-pitch lane using the effective area takt. Element heights must be proportional to time so a stack crosses the line only when its model-variant total exceeds takt. Mirror the scale from the assembly-flow centerline: north grows upward and south grows downward. Hide the line for zero or invalid takt and on Unassigned work. The line is read-only derived presentation and must not add a saved over-takt status or audit event.

## Canonical Terminology Glossary

Before adding any new label, caption, dialog, or button text, check this glossary first. If a new UI label describes a concept already listed here, use the canonical label exactly as written below.

This glossary is active, locked policy, not merely informational, and must be checked before adding new UI labels.

| Concept | Canonical label | Applies to |
| --- | --- | --- |
| Questions page | **Questions and concerns** | Navigation and page title |
| Import/export page | **Import/Export Projects** | Navigation and page title |
| Focused PITS exchange page | **Import/Export PITS** | Product structure navigation and page title |
| Fishbone page | **Parts to fishbone** | Navigation and page title |
| Pin Map page | **Pin Map** | Navigation and page title |
| Model Tree page | **Model Tree** | Navigation and page title |
| Parts master | **Parts Catalog** | Page title, captions, help text, dialogs, and cross-page references |
| Fishbone framework | **Fishbone framework** | Section headings and explanatory copy |
| Fishbone section | **Fishbone section** | Filters, selectors, table columns, captions, and help text |
| Placed part occurrence | **Fishbone use** | Table headings, actions, confirmation dialogs, and history display |
| Friendly model label | **Common name** | Model definitions, fallback text, captions, and help |
| Stable model label | **Official model number** | Model tables and explanatory copy |
| PITS source-row identifier | **PITS ID** | Parts Catalog columns, filters, details, validation messages, and PITS previews |
| PITS subsystem identifier | **Subsystem** | Parts Catalog column, filter, export, and PITS previews |
| PITS part classification | **Part Code** | Parts Catalog column, filter, export, and hover help |
| Scenario revision | **Scenario revision** | Editable field labels and explanatory text; compact value summaries may still abbreviate it as **Rev** |
| Yamazumi area | **Yamazumi area** | Selectors, tables, captions, and help text |
| Process material group | **Part requirement** | Forms, captions, dialog content, and history display |
| Fishbone occurrence quantity | **Fishbone quantity** | Forms, tables, and dialogs |
| Part-use description | **Use / installation location** | Forms, tables, search results, and help text |
| Generic enabled-state wording | **Active** | Boolean columns and filters where the value genuinely means enabled or disabled |
| History attribution | **Editor** | Sidebar field and History column; supporting help must continue stating that this is free-text attribution |

The following terms remain contextual exceptions rather than globally unified labels:

- **Import/Export Projects** deliberately uses title case and a slash as an approved exception to the general sentence-case convention.
- **Import/Export PITS** uses the same approved title-case and slash exception and names the focused Product structure entry point.
- **Subassembly** remains a valid Fishbone section type.
- **Common name** and **Official model number** remain separate fields.
- Compact scenario summaries may use **Rev** even though the editable field label is **Scenario revision**.
- **Active** must not replace a genuinely different status such as **Draft**, **Open**, **Blocked**, or **Released**.

This update is documentation-only and does not modify screen code. The glossary itself remains active, locked, and binding policy for all future UI work.
