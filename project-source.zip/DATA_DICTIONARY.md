# Process at a Glance data dictionary

This file is the authoritative reference for every Process at a Glance database table, its business purpose, ownership scope, and relationships. No new database table or field should be added without updating this file in the same change. When code, labels, or older documentation disagree with this file, stop and resolve the discrepancy with the project owner before extending the data model.

## Active tables

### `projects`

- **Purpose:** The top-level record for an NPI planning project. It holds the project identity, program or product, product line, lead industrial engineer, baseline revision, status, default takt time in canonical seconds, its saved `takt_time_unit` display preference (`seconds`, `minutes`, or `hours`), the project-wide Yamazumi line-code suggestion, notes, and timestamps.
- **Key relationships:** Parent of `planning_scenarios`, `parts`, `project_models`, `complexity_features`, `assembly_sections`, `concerns`, source-import records, Yamazumi records, Process at a Glance records, and `audit_log` entries.
- **Scope:** Project-wide; this is the root of all other business data.

### `planning_scenarios`

- **Purpose:** A named planning branch used to compare alternative takt, balancing, and process plans without mixing their records. `takt_time_s` remains canonical seconds while `takt_time_unit` stores the scenario's independent takt display preference. `yamazumi_time_unit` separately controls Yamazumi work-duration presentation and entry; neither preference changes persisted timing quantities.
- **Key relationships:** Belongs to `projects`. May reference another `planning_scenarios` row as its parent. Owns `part_scenario_activity`, `yamazumi_areas`, `work_elements`, and `process_part_groups`. Scenario cloning copies the applicable scenario-owned planning data.
- **Scope:** Scenario-specific.

Creating a new active Fishbone section or subassembly atomically creates one linked Yamazumi area in every existing planning scenario, including archived scenarios. Automatic creation is idempotent and create-only: it uses a new UUID, the Fishbone section name, and no takt override, but never relinks, renames, detaches, or otherwise repairs an existing area. A same-name or conflicting area is preserved and reported for explicit repair; unaffected scenarios still receive their new areas. Later scenario clones retain the established behavior of copying the source scenario's linked areas. Yamazumi does not display the fixed Fishbone relationship for an already linked area; only an imported or legacy area with a null `section_id` exposes **Pair with Fishbone section**.

#### Scenario-saved Yamazumi time unit — approved September 15, 2026

The setting connects one `planning_scenarios` row to its scenario-owned `yamazumi_areas`, `yamazumi_pitches`, and `yamazumi_elements` presentation in the critical thread. A dedicated `yamazumi_time_unit` field is required because the existing `takt_time_s`, `takt_override_s`, `time_s`, and downstream `cycle_time_s` fields are canonical quantities in seconds rather than display preferences. Existing and newly initialized scenarios default to `seconds`; scenario cloning copies the source preference.

Yamazumi accepts and displays Seconds, Minutes, or Hours for work durations using this scenario setting. Every entered work duration is converted back to seconds before persistence, calculations remain in seconds, and changing the preference never rewrites existing timing records. Takt values use the separate scenario `takt_time_unit` preference described below.

The Yamazumi workbook's unlabelled `Pitch_Takt_time` and `Work_Time_to_complete` values are interpreted in the saved scenario unit. Filtered work-element exports use that unit and name it explicitly in the exported time header. One explicit audited **Save & Refresh** action atomically saves the scenario unit, selected area's takt override, and optional Fishbone pairing for an unlinked imported area. A takt matching the scenario target is stored as no override. Unit changes remain blocked while the work-element editor has unsaved values, while takt-only and pairing-only saves remain available. No deletion behavior is introduced.

### `concerns`

- **Purpose:** Tracks project questions, concerns, decisions, and assumptions, including ownership, priority, status, and optional related part or station text.
- **Key relationships:** Belongs directly to `projects`. Related-part and related-station values are descriptive text rather than enforced foreign keys.
- **Scope:** Project-wide.

### `audit_log`

- **Purpose:** Stores lightweight history for supported saves and workflow actions, including the logical table or workflow name, action, row count, Current editor text, JSON details, and timestamp.
- **Key relationships:** Belongs to `projects`. It does not have a direct scenario foreign key; scenario identifiers may be included in the JSON details for scenario-specific events.
- **Scope:** Project-wide history, with some entries describing scenario-specific work.

### `project_transfer_events`

- **Purpose:** Stores structured evidence for whole-project package exports and imports, including operation, package version, complete manifest JSON, source and target project identity, per-table record counts, detected import conflicts, Current editor attribution, and timestamp.
- **Key relationships:** Belongs to `projects`. Each transfer also writes the required complementary `audit_log` entry under the dedicated `Project transfer` category; the structured row supports future transfer-history reporting and does not replace universal audit history.
- **Scope:** Project-wide. Export rows describe a package containing the project and all of its planning scenarios. Import rows identify whether the package created a new project or replaced an explicitly selected project and retain the source/target evidence and validated package counts.

### `pits_records`

- **Purpose:** Stores the latest imported PITS source record for each stable PITS ID, including source fields, a source hash, and the current source revision number.
- **Key relationships:** Belongs to `projects`. Parent of `pits_record_revisions`. A new record also creates a corresponding MBOM-review candidate in `fishbone_nodes`.
- **Scope:** Project-wide source evidence.

### `pits_record_revisions`

- **Purpose:** Preserves each imported source payload revision for a PITS record so upstream changes can be reviewed without silently replacing collaborator decisions.
- **Key relationships:** Belongs to `pits_records`; deleting the parent PITS record deletes its revisions.
- **Scope:** Project-wide source history through its parent record.

### `pits_bom_imports`

- **Purpose:** Records each successfully completed BOM-worksheet snapshot in the combined PITS import, including its per-project sequence, workbook identity, source row and occurrence counts, issue count, editor attribution, and completion time. The import row and all occurrence changes commit atomically; a failed or incomplete parse cannot become the latest snapshot or mark existing occurrences missing.
- **Key relationships:** Belongs to `projects`. Referenced by the first-seen, last-seen, and last-reviewed fields on `pits_bom_occurrences` and by `pits_bom_occurrence_revisions`.
- **Scope:** Project-wide source evidence. `UNIQUE(project_id, import_sequence)` defines deterministic snapshot order independently of timestamp ties.

### `pits_bom_occurrences`

- **Purpose:** Stores one stable BOM parent-child relationship per `(project_id, parent_tracker_number, child_tracker_number)`, with tracker values retained as trimmed text, the latest Level 1-11 depth and quantity evidence, source row and raw levels, source fingerprint, validation issues, independent review and source-change states, and optional reviewed Fishbone relationships. An empty parent tracker is reserved for a Level 1/root occurrence. When one snapshot contains the same parent-child key more than once, the import retains one occurrence, records every conflicting BOM row number in its validation issues, and continues importing the rest of the workbook.
- **Key relationships:** Belongs to `projects`; optionally resolves parent and child identities to `parts`; optionally references a human-confirmed `assembly_sections` row and one exact `fishbone_part_assignments` destination; and references the imports where it was first seen, last seen, and last reviewed. It has no relationship to `fishbone_nodes`.
- **Scope:** Project-wide source/review staging. New occurrences start as `Needs review` / `New`. Approved occurrences retain their assignment when source quantity changes or the occurrence disappears; re-import never overwrites the authoritative Fishbone quantity.

### `pits_bom_occurrence_revisions`

- **Purpose:** Preserves each distinct normalized depth/quantity source version for a BOM occurrence. Row movement alone updates current traceability without creating a false revision.
- **Key relationships:** Belongs to `pits_bom_occurrences` and references the `pits_bom_imports` snapshot in which that version first appeared.
- **Scope:** Project-wide source history through the parent occurrence. Revision number and source fingerprint are independently unique within an occurrence.

### `pits_bom_occurrence_concerns`

- **Purpose:** Links an escalated new, changed, or missing BOM occurrence to a real `concerns` record while preserving the occurrence's normal source state and the approved Fishbone use's PITS sync state.
- **Key relationships:** Belongs to `projects`, references `pits_bom_occurrences`, and references `concerns`. More than one concern may be linked over the lifetime of an occurrence, while each occurrence/concern pair is unique.
- **Scope:** Project-wide. Deleting a concern removes only this relationship and never clears a PITS difference.

### `fishbone_nodes`

- **Purpose:** Holds PITS and legacy-BOM candidate occurrences for the Manufacturing BOM review stage. It records proposed hierarchy, source evidence, review status, applicable models, and whether the upstream source changed.
- **Key relationships:** Belongs to `projects`. May reference another node through `parent_id`, but that relationship is not enforced by a database foreign key. Confirmed rows can be synchronized into `parts`; they are not the same entity as approved fishbone sections or part placements.
- **Scope:** Project-wide source/review staging.

### `project_models`

- **Purpose:** Stores official model numbers, imported PITS model attributes, estimated annual usage, source payload, and team-friendly display names and descriptions.
- **Key relationships:** Belongs to `projects`. Parent of `model_feature_values`. Referenced indirectly when displaying or interpreting part and process model applicability.
- **Scope:** Project-wide.

### `complexity_features`

- **Purpose:** Defines manufacturing-relevant product characteristics and their allowed choices, such as a door or control configuration.
- **Key relationships:** Belongs to `projects`. Parent of `model_feature_values` and `part_feature_rules`.
- **Scope:** Project-wide.

### `model_feature_values`

- **Purpose:** Assigns one selected feature value to an official model for each applicable complexity feature, forming the project complexity tree.
- **Key relationships:** Junction between `project_models` and `complexity_features`; also carries `project_id` for boundary validation.
- **Scope:** Project-wide.

### `parts`

- **Purpose:** The approved Parts Catalog, with one master record per project and official part number. It stores the part name in the legacy `description` field, revision, provenance, notes, legacy model-applicability text, the primary CAD image path, optional project-wide physical weight in `weight_lb`, and the collaborator-maintained Technology Engineer, unique PITS ID, controlled Source Code, Official Windchill Part Name, and Make vs Buy fields described below.
- **Key relationships:** Belongs to `projects`. Parent of `part_images`, `part_scenario_activity`, `part_feature_rules`, `fishbone_part_assignments`, and `process_part_options`. A completed `manufacturing_assemblies` record may reference one catalog row through `catalog_part_id`, allowing the built subassembly to return to the normal Parts Catalog → Fishbone-use → downstream-planning flow.
- **Scope:** Project-wide master data.
- **Weight:** `weight_lb` is a nullable `REAL` value storing physical part weight in pounds. It has no inferred or automatic source in Phase 1. The future Ergonomics trigger may evaluate deliberately entered values greater than 33 pounds, regardless of Handle/Consume classification.
- **Derived PITS fields:** The Parts Catalog displays read-only **Subsystem** and **Part Code** columns sourced respectively from tracker columns F and N through the catalog row's PITS ID and the matching project-wide `pits_records` row. They remain source evidence rather than duplicated `parts` fields; catalog rows without a matched PITS ID display blank. Part Code retains the workbook values `NP`, `NPNT`, `ASM`, `CP`, and `CP Other`. The legacy `official_windchill_part_name` value remains preserved for transfer compatibility but is not displayed or exported by the Parts Catalog.
- **Catalog engineering fields:** `technology_engineer`, `pits_tracker_number`, `source_code`, `official_windchill_part_name`, and `make_buy` are optional project-wide text fields. The legacy-named `pits_tracker_number` field is displayed as **PITS ID** and stores the source workbook's **ID Number**, normally found in column B after the detected header row. Nonblank values are unique within one project and preserve leading zeros. `source_code` accepts blank, `1`, `+1`, `2`, `2.4`, `3`, `4`, `5`, `6`, `7`, or `8` (`1 - Purchased Part`, `+1 - Purchased Asm`, `2.4 - From AP3`, `3 - Mfg Part`, `5 - Asm (Disassembly no)`, `6 - Asm (Disassembly yes)`, and `8 - Component of Purchased Asm`); `make_buy` accepts only blank, `Make`, or `Buy`. When importing a PITS snapshot, Technology Engineer is extracted from tracker column I, PITS ID from the detected **ID Number** column, Source Code from tracker column T, and revision from column BL. Imported values fill blank catalog fields and update PITS-sourced rows; nonblank collaborator-maintained values are preserved unless the contributor explicitly confirms overwrite. Because the catalog has one row per part number, a PITS ID is linked automatically when that part number has one distinct tracker ID. When the tracker has multiple IDs for one part number, the importer cross-references the BOM sheet's column-A PITS ID and column-B part number and uses the ID only if the BOM provides one matching value. Multiple BOM IDs for one part number are counted and reported to the contributor; unresolved catalog values remain unchanged.

### `part_scenario_activity`

- **Purpose:** Records whether a project catalog part is active in a particular planning scenario and should appear in downstream scenario views. If no row exists, current behavior treats the part as active.
- **Key relationships:** Junction between `planning_scenarios` and `parts`; also carries `project_id` for boundary validation.
- **Scope:** Scenario-specific.

### `part_images`

- **Purpose:** Stores paths and metadata for supplemental part images. The primary CAD image remains on `parts.image_path`.
- **Key relationships:** Belongs to `parts`; deleting a part deletes its supplemental image records.
- **Scope:** Project-wide through the parent part.

### `part_feature_rules`

- **Purpose:** Defines which manufacturing feature choices require a catalog part. Multiple values for one feature act as alternatives, while rules across different features combine to describe applicability.
- **Key relationships:** Junction between `parts` and `complexity_features`; also carries `project_id` for boundary validation.
- **Scope:** Project-wide.

### `assembly_sections`

- **Purpose:** Defines the station-independent assembly fishbone framework. Rows are either main-spine sections or subassemblies and include ordering, description, and active status.
- **Key relationships:** Belongs to `projects`. May reference another `assembly_sections` row as its parent. Parent of `fishbone_part_assignments`; optionally linked from `yamazumi_areas`, `process_part_groups`, and the Built and Installed fields on `manufacturing_assemblies`. Deleting a referenced section requires the combined continuity re-pointing workflow documented below.
- **Scope:** Project-wide.

### `fishbone_part_assignments`

- **Purpose:** Represents one placed occurrence or use of a catalog part in a fishbone section, with a strictly positive decimal occurrence quantity, use or installation description, notes, order, and a controlled `pits_sync_status` of `Not linked`, `In sync`, `Quantity differs`, or `No longer found`. One part may have multiple assignments.
- **Key relationships:** Belongs to `projects`, references `parts`, and references `assembly_sections`. Process pairing validates that selected catalog parts are available in the relevant section and may save the exact placement through `process_part_options.fishbone_assignment_id`. At most one `pits_bom_occurrences` row may reference an assignment as its approved source occurrence.
- **Scope:** Project-wide; scenario views filter these assignments using `part_scenario_activity`.

### `manufacturing_assemblies`

- **Purpose:** Stores the project-wide catalog of real, pre-existing assembly numbers, including friendly name, parent assembly, Built section, Installed section, project-wide Make / buy classification, active state, notes, primary image path, linked completed-subassembly Parts Catalog identity, and timestamps. The parked `pits_reference` and `planning_reason` fields remain hidden from the active catalog workflow.
- **Key relationships:** Belongs to `projects`; may reference another catalog assembly as its parent, references `assembly_sections` independently through Built and Installed section fields, and optionally references its completed-subassembly `parts` row through `catalog_part_id`. Parent of `manufacturing_assembly_components`, `manufacturing_assembly_feature_rules`, `manufacturing_assembly_images`, and the still-dormant scenario-policy relationships.
- **Scope:** Project-wide. Active catalog reads and writes are isolated from `assembly_scenario_policies` and never accept `scenario_id`.

### `manufacturing_assembly_components`

- **Purpose:** Stores one explicit, independently quantified mini-BOM component for an assembly number by referencing an exact Fishbone use. Quantities are positive decimals and do not stay synchronized with the Fishbone quantity after creation.
- **Key relationships:** Belongs to `manufacturing_assemblies` and references `fishbone_part_assignments`; deleting the assembly or Fishbone use cascades to the component row.
- **Scope:** Project-wide.

### `manufacturing_assembly_feature_rules`

- **Purpose:** Retains legacy Task 04 assembly-feature selections for database and snapshot compatibility. The active Assembly grid and Assembly Details UI no longer display or edit these rows, and current assembly-to-model applicability does not evaluate them.
- **Key relationships:** Belongs to `manufacturing_assemblies` and references `complexity_features` with `ON DELETE RESTRICT`; values are validated against the feature's current JSON `allowed_values`.
- **Scope:** Project-wide.

### `manufacturing_assembly_images`

- **Purpose:** Stores unlimited supplemental assembly-image paths and optional captions. The primary image remains on `manufacturing_assemblies.image_path`.
- **Key relationships:** Belongs to `manufacturing_assemblies`; deleting the assembly deletes its image rows and owned upload files through the supported workflow.
- **Scope:** Project-wide.

### `yamazumi_areas`

- **Purpose:** Defines a balancing area inside a planning scenario, normally corresponding to one fishbone section and optionally carrying a takt override.
- **Key relationships:** Belongs to `projects` and `planning_scenarios`. Optionally references `assembly_sections`. Parent of `yamazumi_pitches`, `yamazumi_elements`, and `yamazumi_work_regions`.
- **Scope:** Scenario-specific.

### `yamazumi_pitches`

- **Purpose:** Stores physical pitch addresses within a Yamazumi area, including pitch name, type, status, supported model variants, display order, and an optional directed feed target.
- **Key relationships:** Belongs to `yamazumi_areas` and `projects`. Referenced by `yamazumi_elements`; deleting a pitch through the supported workflow moves its work elements to Unassigned before deletion. `feeds_into_pitch_id` is a nullable self-reference to `yamazumi_pitches.id` with `ON DELETE RESTRICT`.
- **Scope:** Scenario-specific through the parent area.

#### Scenario-wide pitch-address uniqueness — approved September 14, 2026

Each trimmed pitch address is unique, case-insensitively, across every Yamazumi area in one planning scenario. The same physical address may be reused in another scenario of the project so alternative planning branches and scenario cloning retain their meaning. Idempotent SQLite insert/update triggers provide the final database safeguard without duplicating `scenario_id` on `yamazumi_pitches`; every supported add, edit, table replacement, range generation, import, and clone path also validates through the store layer and returns a contributor-readable error.

Legacy conflicts are reported on the affected Yamazumi page and are never automatically renamed, merged, moved, or deleted. Contributors must deliberately rename or delete a conflicting pitch through an existing audited workflow before unrelated pitch changes can be saved. Same-area imports continue reusing an existing address, while an address already owned by another area rejects the complete import. Range generation skips addresses already used anywhere in the scenario, reports the skipped count, and creates the remaining addresses atomically. A scenario containing a legacy conflict cannot be cloned until the conflict is resolved.

#### Yamazumi pitch feeds-into relationship — approved September 10, 2026

`yamazumi_pitches.feeds_into_pitch_id` identifies the other pitch that receives material from a `Subassembly` or `Kitter` pitch. The field applies only to those two `pitch_type` values and must be `NULL` for `Pitch`, `Waterspider`, and `Repacker`. New pitches and every contributor edit that saves a pitch as `Subassembly` or `Kitter` require a valid target. Existing feeder pitches remain compatibility-`NULL` without inferred backfill until a contributor manually edits them; the Yamazumi editor displays **Feed target required** on every such row.

The target must be a different pitch in the same `yamazumi_areas` row, which guarantees the same project and planning scenario. Any pitch type may be a target, allowing multi-step feeder chains. Every single-row, bulk, range-generation, and import save validates the complete resulting area graph before commit. Direct and indirect cycles are hard-blocked without override using directed depth-first traversal and an error that identifies every pitch in the loop by `pitch_number` and `pitch_name` when present.

Scenario cloning remaps populated targets through the cloned pitch-ID map; compatibility-`NULL` values remain `NULL`. A pitch referenced as a feed target cannot be deleted until every referring feeder is re-pointed or changed to a non-feeder type. Deleting a feeder removes its outgoing relationship and retains the established behavior that moves its `yamazumi_elements` to Unassigned. Successful UI saves use Current editor attribution, relationship-specific audit details containing source and old/new target IDs and addresses, Undo/Save & Refresh behavior, and the Yamazumi History expander.

This relationship supplies physical-routing input to the derived Yamazumi board order. It remains separate from Fishbone lineage and does not change the `M` or `S` designators in a human-readable Op ID.

#### Yamazumi board pitch order — approved September 15, 2026

The interactive balancing board derives pitch-stack presentation order without changing `yamazumi_pitches.sequence` or any persisted relationship. Within the board's single Fishbone-linked Yamazumi area, pitch address is the pitch-level Op ID sequence and is compared case-insensitively with numeric address segments in numeric order. This prevents a newly created pitch from appearing last merely because its stored creation sequence is newest.

Physical feed routing refines that address order. Each complete upstream Subassembly or Kitter chain is displayed immediately before the pitch it feeds; multiple feeders for one receiver use pitch-address order, and nested feeders are emitted upstream-to-downstream. Unlinked pitches and compatibility feeders without a target remain in address order. The board retains the established rule that odd ending addresses render north/top and even ending addresses render south/bottom. This is a read-only presentation transformation, creates no audit event, and does not renumber addresses, rewrite saved display sequence, change feed targets, or alter Op ID lineage.

Each assigned-pitch lane displays one continuous red takt line at the effective Yamazumi-area takt: the area override when present, otherwise the active scenario takt. North stacks grow upward toward and beyond their line; south stacks grow downward. Work-element heights remain strictly proportional to canonical time so crossing the line accurately indicates that a model-variant stack exceeds takt. A zero or invalid takt hides both lines, and Unassigned work is not evaluated. This is derived presentation only and creates no persisted status or audit event.

### `yamazumi_elements`

- **Purpose:** Stores measurable work content for Yamazumi balancing: description, time, work type, pitch assignment, variants, work region, source, order, and Process synchronization state. Yamazumi does not store collaborator-assigned CTQ or Safety flags.
- **Key relationships:** Belongs to `yamazumi_areas` and `projects`; optionally references `yamazumi_pitches`. `process_element_id` is a soft text link to `work_elements`, not an enforced foreign key. Reconciliation creates or updates the linked Process step.
- **Scope:** Scenario-specific through the parent area.
- **Deletion:** The interactive-board editor may delete one element only after a non-dismissible, relationship-aware confirmation. Any linked Process at a Glance step and its downstream records remain, but lose the deleted Yamazumi source used for pitch context, derived Op ID, and the inline pitch summary. Existing locked `work_element_material_groups` and their options retain their schema-defined cascade behavior and are disclosed if present; the pitch, area, Fishbone structure, work-region definition, and audit history remain.
- **Flag retirement:** Yamazumi does not own or display element flags. The former `flags` column and `yamazumi_flag_definitions` table are removed by an idempotent schema upgrade, and their legacy values are intentionally discarded. Reconciliation does not infer PAAG quality text from Yamazumi. Any future PAAG indicators generated from Functional Reviews require a separately approved design and must not be persisted on Yamazumi elements.

#### Copy to another Yamazumi area — approved September 11, 2026

The Yamazumi page provides a dedicated, read-only selection workflow for copying saved pitches and/or work elements from one source area into a different area in the same project, including across non-archived planning scenarios. The source is never edited. Each copied pitch and element receives a fresh UUID; copied work deliberately clears `process_element_id`, stores `source = 'Yamazumi copy'`, and begins with `process_sync_status = 'Needs IE review'` so no Process at a Glance relationship is shared or inferred.

A pitch copy includes all of its assigned work elements. Pitch addresses are checked case-insensitively against the target area and conflicts require an explicit replacement. Copied `Subassembly` and `Kitter` pitches remap their feed target to another pitch copied in the same batch when possible; otherwise the contributor must choose an existing pitch in the target area. Standalone element copies may append to an Active target pitch or Unassigned. Missing model variants are enabled on the selected target pitch after disclosure, and unmatched Work region text is retained as a legacy value. Selection overlap is deduplicated, destination pitch/stack sequences are appended in ten-step increments, and the complete copy plus one Current-editor-attributed Yamazumi audit event commits atomically. Unsaved board or table drafts must be saved or undone before copying.

Yamazumi derives a read-only **Criticality** tag list for each work element that has a valid `process_element_id`. **CTQ** comes from a linked PFMEA entry classified `E`, `P`, `P-`, `Q`, or `E-`; **Safety** comes from at least one active linked `safety_requirements` row. The tags are calculated from current scenario-owned records at display time, are not persisted on `yamazumi_elements`, and cannot be edited in Yamazumi. Retired legacy Yamazumi flag definitions and element values are discarded once per project through an editor-attributed atomic migration that records counts but not the removed text.

### `yamazumi_work_regions`

- **Purpose:** Defines area-specific work-region labels and colors used to categorize Yamazumi work elements.
- **Key relationships:** Belongs to `yamazumi_areas` and `projects`. Work elements store the selected region as text rather than by region ID, so rename and delete workflows must rewrite affected element values deliberately.
- **Scope:** Scenario-specific through the parent area.

### `safety_requirements`

- **Purpose:** Stores a reviewed Safety requirement for a Process at a Glance step. Only active rows create the derived Safety criticality indicator.
- **Key relationships:** Belongs to `projects` and `planning_scenarios` and references `work_elements.id` with `ON DELETE CASCADE`. Process-step deletion discloses the dependent count before the database removes those rows. Scenario cloning creates fresh Safety requirement IDs and remaps the Work Element relationship to the cloned step.
- **Scope:** Scenario-specific, matching the linked Process at a Glance step.
- **Storage and interaction:** Stores stable ID, project/scenario/Work Element relationships, requirement description, Active state, and timestamps. The Safety page provides direct entry, filtering, read-only derived Process labels, Undo, **Save & Refresh**, filtered export, relationship-safe confirmed deletion, Current editor audit attribution, and bottom History. All writes validate the active project/scenario boundary and commit with their audit evidence.
- **Approval status:** Nicole Ervin, project owner, approved this minimal Safety requirement module and its derived Process/Yamazumi indicator on September 11, 2026.

### `work_elements`

- **Purpose:** Stores the ordered Process at a Glance steps for a planning scenario, including pitch, operation/work-element text, time, status, model applicability, output-assembly milestone, tool, location, unit orientation, and geometry or requirement fields. Conveyor height, platform height, and pit depth are stored directly in inches as `conveyor_height_in`, `platform_height_in`, and `pit_depth_in`.
- **Key relationships:** Belongs to `projects` and `planning_scenarios`. Soft-linked from `yamazumi_elements.process_element_id`. Parent of `process_part_groups`. Detailed requirement fields remain retained by the schema, but the former Process step Details dialog has been replaced by the read-only Phase 3 inline pitch viewer. The legacy `status` value remains stored for compatibility but is no longer displayed, filtered, or edited by the Process at a Glance by pitch table.
- **Scope:** Scenario-specific.

Process at a Glance displays a read-only **Criticality** tag list derived live for each step. **CTQ** appears when at least one linked PFMEA entry has Classification `E`, `P`, `P-`, `Q`, or `E-`; **Safety** appears when at least one active `safety_requirements` row references the step. Both tags may appear together. The display uses `work_elements.id` only as a hidden relationship, stores no duplicate flag on `work_elements`, updates on the next render after source changes, and creates no audit event because viewing it persists nothing.

### `process_part_groups`

- **Purpose:** Defines a named material requirement for a Process at a Glance step, with a selection rule (`Use all`, `Choose one`, or `Optional`), quantity, notes, and originating fishbone section.
- **Key relationships:** Belongs to `projects` and `planning_scenarios`, references `work_elements`, optionally references `assembly_sections`, and is parent of `process_part_options`.
- **Scope:** Scenario-specific.

### `process_part_options`

- **Purpose:** Lists the catalog parts allowed or required by a process part group and optionally classifies each exact Process part-use as `Handle` or `Consume` through `handling_type`.
- **Key relationships:** Belongs to `process_part_groups`, references `parts`, and may reference the exact `fishbone_part_assignments` occurrence through nullable `fishbone_assignment_id`.
- **Scope:** Scenario-specific through the parent process part group.
- **Handle/Consume compatibility:** `handling_type` is nullable, has no default, and accepts only `Handle`, `Consume`, or compatibility `NULL`. `Consume` means the part is removed from its container and placed on the line for the first time; `Handle` means it is manipulated again after it is already on the line. The field belongs to this part-use rather than the project-wide Part or whole Process step because the same Part number may be consumed once and handled later. The 16 rows present when Phase 1 was approved remain `NULL`; no value is inferred or backfilled. Rows created before the Phase 2A picker also remain `NULL`. Ordinary Part-requirement saves preserve stable option IDs and any saved classification. Phase 2A requires an explicit classification and exact placement for every newly selected catalog part, while compatibility-null saved rows remain unchanged unless a future approved editing workflow explicitly classifies them.

#### Fishbone placement traceability and Consume allowance — amendment approved September 8, 2026

Add nullable `process_part_options.fishbone_assignment_id TEXT REFERENCES fishbone_part_assignments(id)` to identify the exact project-wide Fishbone placement represented by a scenario-specific Process part pairing. The relationship is placement-specific rather than part-number-specific because one catalog part may have multiple unrelated Fishbone placements, each with an independent recorded quantity and Consume allowance.

The field remains nullable for compatibility with existing unclassified `process_part_options` rows. Those rows retain both `handling_type = NULL` and `fishbone_assignment_id = NULL`; no placement is inferred or backfilled. In the Phase 2 Process at a Glance part-pairing workflow, any pairing explicitly classified as `Handle` or `Consume` must reference a valid Fishbone placement for the same catalog part and applicable Fishbone section.

When saving a pairing with `handling_type = 'Consume'`, validation counts existing Consume-classified `process_part_options` rows in the same planning scenario that reference the same `fishbone_part_assignments.id`, excluding the row currently being updated. Each pairing counts as one consumed unit. The proposed total after the save must not exceed `fishbone_part_assignments.quantity`. If the allowance has been reached, the complete save is blocked with a clear message that the specific Fishbone placement’s recorded quantity has already been fully consumed elsewhere in the scenario. This is a hard validation block with no override.

A pairing with `handling_type = 'Handle'` is permitted only after at least one Consume-classified pairing exists in the same scenario for that exact Fishbone placement. After that prerequisite is satisfied, the number of Handle pairings referencing the placement is unrestricted and does not reduce or otherwise affect its Consume allowance.

This relationship and validation belong exclusively to the Process at a Glance part-pairing workflow, where `process_part_options.handling_type` is classified. They do not aggregate by `parts.part_number`, alter the project-wide Fishbone quantity, or modify another scenario’s independent Consume count. No Process-step sequence or ordering comparison is required between a placement's Consume pairing and its Handle pairings; this is a deliberate simplification for this phase.

The Phase 2A Process at a Glance picker defaults each newly selected catalog part to `Consume` and allows the contributor to switch it to `Handle`. It automatically selects `fishbone_assignment_id` when the part has exactly one Use / installation location in the applicable Fishbone section; when several exist, the contributor must choose the exact location before saving. Location options show the scenario-specific remaining Consume allowance derived by the store layer. An unavailable Consume or Handle choice remains subject to the same hard store validation and its user-readable blocking message. Pairing Yamazumi work without a part does not create a `process_part_options` row and does not involve either field.

### `ergonomic_hazard_options`

- **Purpose:** Stores reusable Ergonomics hazard tags with a required Label and Active state, following the project-wide PFMEA manual-option catalog pattern. Labels are case-insensitively unique within a project.
- **Key relationships:** Belongs to `projects` and is referenced by `ergonomics_review_hazard_selections`. Deleting an option removes its dependent selection rows but does not delete an Ergonomics review.
- **Scope:** Project-wide. Inactive options remain available to existing saved selections but cannot be newly selected.

### `ergonomics_reviews`

- **Purpose:** Stores scenario-specific Ergonomics reviews, including independently controlled status and risk classification, reviewer attribution, notes, requested due date, and standard timestamps. A review may be linked to Process at a Glance work or may begin as an unlinked legacy item or pre-PAAG concern before a corresponding Process step exists. New rows default to status `Started` and risk classification `Not yet assessed`; allowed statuses remain `Started`, `Open`, `Pending`, `Validation`, `Closed (admin)`, and `Closed (engineering)`.
- **Key relationships:** Belongs to `projects` and `planning_scenarios`; optionally references a same-project, same-scenario `work_elements` row through nullable `work_element_id`. Deleting a `work_element` does not delete or block deletion of its linked `ergonomics_reviews` row; instead, `work_element_id` is set to `NULL` on the affected review, preserving all reviewer-entered content. The review then reappears in the **Unlinked** filtered view, following the same pattern already used for `process_part_option_id` nulling on deletion of its linked part-use. The review may reference the exact triggering `process_part_options` row through nullable `process_part_option_id`; removing that part-use sets the optional link to null while preserving the review. Parent of `ergonomics_review_hazard_selections`.
- **Scope:** Scenario-specific. An unlinked review still belongs to one project and planning scenario even while `work_element_id` is `NULL`. Phase 2B provides the scenario-specific editable Ergonomics review table, automatic starting reviews for newly created Process steps, relationship-aware linking/merge behavior, and confirmed deletion. The approved scenario-cloning behavior and active-scenario takt-time display below are implemented. Weight-based automatic review triggers, source-change re-review behavior, inline 16:9 Standard Work presentation, and production-readiness calculation remain follow-up work.
- **Approval status:** Nicole Ervin, project owner, approved the original module proposal and Phase 1 compatibility-null handling decision on September 8, 2026. The nullable Work Element relationship, automatic review creation, and explicit linking/merge workflow below were approved as an amendment on September 9, 2026. The independent risk classification and derived Process at a Glance cross-reference below were approved as a further amendment on September 9, 2026. Scenario cloning and active-scenario takt-time visibility were approved as a further amendment on September 9, 2026.

#### Nullable Work Element relationship and automatic review creation — amendment approved September 9, 2026

`ergonomics_reviews.work_element_id` is nullable. A `NULL` value supports **legacy items**, meaning known ergonomic issues from current production entered at the start of a program, and **pre-PAAG concerns**, meaning issues identified before parts have been paired to time elements. Both use the existing `ergonomics_reviews` table; no separate holding or staging table is introduced.

Every review with `work_element_id = NULL` must display a clear **Unlinked** badge or tag in the Ergonomics UI rather than relying on a blank Work Element cell. The review table must support filtering between linked and unlinked records.

Whenever a new `work_elements` Process at a Glance step is created, the system automatically creates one `ergonomics_reviews` row in the same project and planning scenario. The generated review has `status = 'Started'`, references the new step through `work_element_id`, has no hazard selections, and leaves every other contributor-editable field blank. The work-element creation path must guarantee that the starting review is present for every newly created Process step.

An ergonomist may explicitly link an existing unlinked review to a same-project, same-scenario Work Element that already has its automatically generated review. Exactly one of the two reviews survives:

1. A review has **real content** when its status differs from the default `Started`, or when it has any selected hazard tag, nonblank notes, nonblank reviewer attribution, or a requested due date.
2. If exactly one review has real content and the other is an empty, untouched automatically generated placeholder, the review with real content survives. Its `work_element_id` is set or retained as the target Work Element, and the empty placeholder is removed without a confirmation dialog because no real review content is discarded.
3. If both reviews have real content, a non-dismissible relationship-aware confirmation dialog displays both reviews' complete content side by side. The ergonomist must explicitly select which review survives before the merge can proceed. The selected survivor is linked to the target Work Element, and the other review is fully removed.
4. The merge is one atomic store-layer write. Removing the discarded review also removes its owned hazard-selection rows through the established relationship. The merge records one `record_audit_event()` entry with Current editor attribution and includes both the surviving and discarded `ergonomics_reviews.id` values in the audit details.

This amendment does not change the approved status list, `requested_due_date`, reviewer pattern, notes, project-wide `ergonomic_hazard_options` catalog, or normalized multiple-selection structure in `ergonomics_review_hazard_selections`.

#### Risk classification and Process at a Glance cross-reference — amendment approved September 9, 2026

Add `ergonomics_reviews.risk_classification` as a controlled field independent of `status`. Its allowed values are `Not yet assessed`, `Favorable Red`, `Favorable Green`, `Red`, and `Green`. Every newly created review, including an automatically generated review for a new Process at a Glance Work Element, defaults to `Not yet assessed`.

`risk_classification` is non-nullable and has a database-enforced default of `Not yet assessed`. Unlike the `handling_type` compatibility-null decision, initializing existing rows is a one-time factual backfill rather than an inferred guess: every existing `ergonomics_reviews` row genuinely has not yet had a risk classification recorded. The migration therefore sets every existing review to `Not yet assessed`, accurately representing the known state and ensuring that the field never has two representations of the same outcome through both `NULL` and the literal `Not yet assessed`. Future filters, reports, and displays may consequently treat the literal controlled value as the sole representation of a review that has not yet been assessed.

`status` and `risk_classification` represent separate dimensions of the review. Either field may hold any of its allowed values regardless of the other field's value; they do not form a linked or linear progression.

- `Favorable Red` and `Favorable Green` indicate that an assessment was performed using a non-production-intent part, such as a 3D-printed prototype, and remains subject to confirmation using the production-intent part. These classifications will typically be used during `Validation` around pilot launch, but they are not restricted to that status.
- `Red` and `Green` indicate that the assessment outcome was confirmed using the production-intent part.

Process at a Glance must derive a read-only informational tag for each `work_elements` row from its scenario-specific linked `ergonomics_reviews` rows. The tag appears when at least one individual linked review simultaneously has `status` equal to `Open` or `Pending` and `risk_classification` equal to `Red` or `Favorable Red`.

When multiple reviews reference the same Work Element, one qualifying review is sufficient to display the tag; other linked reviews do not need to agree. The tag is calculated at display time and is not persisted on `work_elements`. It is non-interactive and cannot be edited from Process at a Glance; contributors use the normal navigation to the Ergonomics page for review details. This follows the established derived-view approach used by Pin Map and does not duplicate Ergonomics state.

The previously contemplated acknowledgeable **weight review needed** flag is withdrawn. No acknowledgment field, persisted dismissal state, or dismiss control is introduced. This amendment adds no weight-trigger implementation.

This amendment does not change the existing Ergonomics status list, automatic review-creation trigger, nullable `work_element_id` and **Unlinked** behavior, or relationship-aware link and merge workflow.

#### Scenario cloning and current takt visibility — amendment approved September 9, 2026

When `clone_planning_scenario()` clones a planning scenario, every `ergonomics_reviews` row belonging to the source scenario is copied into the new scenario with a new `ergonomics_reviews.id`. The cloned review retains the source review’s status, risk classification, reviewer attribution, hazard selections, notes, and requested due date. Hazard-selection rows receive new IDs and continue referencing the same project-wide `ergonomic_hazard_options` records.

A source review with `work_element_id = NULL` is copied with `work_element_id = NULL` and remains **Unlinked** in the new scenario. This carries legacy items and pre-PAAG concerns forward as ongoing awareness items without assigning them to a Process step.

A source review with a non-null `work_element_id` is copied with that relationship remapped to the corresponding cloned `work_elements` row in the new scenario. The source scenario’s Work Element ID must never be retained on the cloned review.

A source review with a non-null `process_part_option_id` is copied with that relationship remapped to the corresponding cloned `process_part_options` row in the new scenario. If no corresponding cloned Process part-use can be identified, the cloned review stores `process_part_option_id = NULL`; it must never reference a Process part-use belonging to the source scenario.

Creating the cloned Work Elements invokes the existing automatic review-creation behavior, which initially creates a blank `Started` / `Not yet assessed` review for each cloned step. When a copied source review is remapped to that step, the automatically generated blank placeholder is discarded and the copied source review survives. This applies the established silent-merge principle automatically during the atomic scenario-cloning transaction, with no confirmation dialog because no contributor-entered content is discarded.

If the source scenario contains the edge case of multiple reviews linked to one Work Element, every source review is still copied and remapped as required; the single automatically generated blank placeholder is removed once. Under the normal one-review-per-step flow, the copied review is therefore the sole review linked to the cloned step. A copied source review survives even when it is itself still an untouched default review, preserving the requirement that every source review receives a corresponding new row while avoiding two blank reviews for the cloned step.

Scenario cloning does not set or trigger a re-review flag on any copied review. This remains true when the cloned scenario’s takt time differs from the source scenario’s takt time, even though frequency-driven ergonomic risk factors may need reconsideration. No automatic takt-difference detection, stored comparison, or derived re-review state is introduced.

The Ergonomics page must display the active planning scenario’s current takt time, sourced from `planning_scenarios.takt_time_s`, in a clearly visible location. This display allows contributors to judge manually whether carried-forward frequency-driven assessments remain applicable under the active scenario’s timing. It displays only the current scenario’s value and does not store or calculate a comparison with the source scenario’s takt time.

This amendment does not change the approved status list, the controlled `risk_classification` field, automatic review creation for new Work Elements, nullable `work_element_id` and **Unlinked** behavior, or the manual relationship-aware link/merge workflow, except that the empty-placeholder removal principle is applied automatically during scenario cloning as described above.

### `ergonomics_review_hazard_selections`

- **Purpose:** Stores ordered, multiple hazard-tag selections for one Ergonomics review using stable normalized rows rather than embedded label text.
- **Key relationships:** Belongs to one `ergonomics_reviews` row and references one `ergonomic_hazard_options` row. `UNIQUE(ergonomics_review_id, hazard_option_id)` prevents the same hazard from being selected twice for one review. Store validation enforces matching project and scenario boundaries.
- **Scope:** Scenario-specific through the parent Ergonomics review. New selections require an active project-wide hazard option; an inactive option may remain on an existing review until deliberately removed.

## Module proposals and decision records

### Task 09 — Grid-based assembly-to-model mapping

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** September 2, 2026
- **Review status:** **Approved by the project owner on September 2, 2026, and implemented on `Nicole_assembly_grid_editor` on September 3, 2026.**
- **Purpose:** Replace the standalone Assemblies catalog table as the primary day-to-day entry point with one workspace that can display one or more Fishbone-section grid groups. A protected project-level top row represents the completely packaged unit before warehouse handoff, followed by the real, named EBOM categories owned by Fishbone sections. Each visible model column maps the applicable row to one independent real assembly number, and nested component rows edit that mapped assembly's existing explicit mini-BOM. The Task 04 assembly catalog, compatibility feature-rule storage, images, Make / buy field, and deletion workflows remain authoritative infrastructure and are reused rather than rebuilt.
- **Connections:** Categories connect to `assembly_sections`. Direct mappings connect `assembly_grid_categories` to active `project_models` and `manufacturing_assemblies`, and those mappings are the authoritative source of assembly-to-model applicability. Header rows derive from active `complexity_features` and `model_feature_values`; visibility preferences affect display only. Component rows continue using `manufacturing_assembly_components.fishbone_assignment_id` -> `fishbone_part_assignments.part_id` -> `parts`. Legacy `manufacturing_assembly_feature_rules` rows remain stored for compatibility but are hidden and are neither generated nor evaluated by the grid.
- **Relationship to the critical thread:** The grid adds an explicit collaborator-reviewed path from Model definitions to real assembly-number decisions while preserving the existing Fishbone/Parts evidence path: `project_models` -> direct category mapping -> `manufacturing_assemblies`, and `assembly_sections` -> `fishbone_part_assignments` -> `manufacturing_assembly_components` -> `manufacturing_assemblies`. Imported evidence never creates, replaces, or approves a mapping automatically. Yamazumi and Process at a Glance remain unchanged.
- **Scope:** Categories, mappings, feature-visibility preferences, the grid, and the existing assembly records and mini-BOMs are Project-wide. None carries or reads `scenario_id`. The page uses the **Project-wide** scope badge. The current visible-model selection is browser-session state only and is not persisted.

#### New `assembly_grid_categories`

| Column | Definition | Purpose |
| --- | --- | --- |
| `id` | `TEXT PRIMARY KEY` | Stable string UUID for the category row, ordering, mappings, deletion, and audit details. |
| `project_id` | `TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE` | Carries and validates the project boundary. |
| `section_id` | `TEXT NOT NULL REFERENCES assembly_sections(id) ON DELETE RESTRICT` | Identifies the Fishbone section whose grid owns the category and supplies the Built section for every mapped assembly. |
| `ebom_name` | `TEXT NOT NULL` | Preserves the official EBOM category name as entered by the collaborator; it is not a foreign key to the blocked `fishbone_nodes` review stage. |
| `display_name` | `TEXT NOT NULL` | Stores the editable plain-English category name shown in the grid. It may differ from `ebom_name`. |
| `root_number` | `TEXT NOT NULL` | Legacy compatibility column retained for existing local databases and snapshots. The grid no longer displays, requires, or uses it; new categories store an empty value. |
| `is_top_level` | `INTEGER NOT NULL DEFAULT 0 CHECK(is_top_level IN (0, 1))` | Marks the single protected project-wide packaged-unit row that renders above all Fishbone-section groups. |
| `installed_section_id` | `TEXT REFERENCES assembly_sections(id) ON DELETE RESTRICT` | Stores the single shared Installed section applied to every model's mapped assembly in this category. It starts blank and may remain null until deliberately assigned. |
| `sequence` | `INTEGER NOT NULL DEFAULT 10` | Preserves explicit row order inside the section grid. |
| `created_at` | `TEXT NOT NULL` | UTC creation timestamp. |
| `updated_at` | `TEXT NOT NULL` | UTC latest-change timestamp. |

Enforce `UNIQUE(project_id, section_id, ebom_name)`, `UNIQUE(project_id, section_id, display_name)`, and a partial unique index allowing at most one row with `is_top_level=1` per project. Store validation trims and requires both names, compares them case-insensitively for duplicates, and confirms both section references belong to the project. The retained `root_number` compatibility value has no active validation or numbering behavior.

The top-level row uses the fixed Official EBOM and Display name **Top-level packaged unit** and is created as an in-memory draft when a project does not yet have one. Its required selectable `section_id` identifies the final packout Fishbone section and continuously synchronizes the Built section of every currently mapped top-level assembly. When that Built section changes, exact Fishbone uses already referenced by those assemblies' mini-BOMs move to the selected final section in the same transaction, matching the established assembly Built-section behavior. `installed_section_id` remains optional for warehouse handoff and retains the standard continuous synchronization behavior. The row is always displayed immediately below active feature headers and before every Fishbone-section group, regardless of which sections are selected. It cannot be deleted; contributors may clear or replace its individual model mappings through the normal confirmed workflow.

The top-level row has one ordinary mapping cell per active official model. Its mini-BOM may select completed subassemblies from any active Fishbone section, while ordinary parts must still use an exact placement in the selected final Built section. All existing Parts Catalog synchronization, assembly-number rename/merge confirmation, model-coverage checks, containment-cycle prevention, Details, audit, Undo, and **Save & Refresh** rules apply unchanged.

The category is a planning row, not an assembly master. Deleting a category deletes its mapping rows only after the approved confirmation; every referenced `manufacturing_assemblies` record, mini-BOM component, rule, image, nesting relationship, and uploaded file remains untouched. Section deletion extends the existing continuity workflow: category `section_id` values move to the approved target before the source section is deleted, category Installed-section values follow the same Installed-section replacement, and source-section feature-display preferences are disclosed and removed rather than merged into the target's independent preferences.

`assembly_grid_categories.installed_section_id` is authoritative for every currently mapped assembly. Changing it continuously synchronizes every distinct mapped assembly's `manufacturing_assemblies.installed_section_id` in the same atomic **Save & Refresh** transaction, including synchronizing to null while the category remains unassigned. Direct Installed-section editing is unavailable for a mapped assembly; after its final mapping is removed, the assembly retains its last value and becomes independently editable. Mapping an existing assembly whose Installed section conflicts with the category is blocked rather than silently overwritten. Editing the category is the explicit bulk action that may change its currently mapped assemblies, and the audit details list every affected assembly.

#### New `assembly_grid_model_mappings`

| Column | Definition | Purpose |
| --- | --- | --- |
| `id` | `TEXT PRIMARY KEY` | Stable string UUID for one model/category mapping cell. |
| `project_id` | `TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE` | Carries and validates the project boundary. |
| `category_id` | `TEXT NOT NULL REFERENCES assembly_grid_categories(id) ON DELETE CASCADE` | Identifies the category row containing the cell. |
| `model_id` | `TEXT NOT NULL REFERENCES project_models(id) ON DELETE CASCADE` | Identifies the official model column. |
| `assembly_id` | `TEXT NOT NULL REFERENCES manufacturing_assemblies(id) ON DELETE CASCADE` | Identifies the full, final real assembly number selected for that model and category. |
| `created_at` | `TEXT NOT NULL` | UTC creation timestamp. |
| `updated_at` | `TEXT NOT NULL` | UTC latest-change timestamp. |

Enforce `UNIQUE(category_id, model_id)`. Store validation confirms that category, model, and assembly belong to `project_id`; the mapped assembly's `built_section_id` equals the category's `section_id`; and the mapped assembly's `installed_section_id` equals the category's shared `installed_section_id`, including null while the category remains unassigned. One real assembly may be mapped to multiple models only within one category. The complete project state may not associate one `manufacturing_assemblies.id` with more than one distinct `assembly_grid_categories.id`, even when the categories share a Fishbone section or Installed section. A fully validated move between categories is allowed when the old mappings are removed in the same atomic save. Validation merges the complete persisted state with the full unfiltered draft, and a conflict identifies the assembly number, existing category, attempted category, and affected model. Add an index on `(project_id, assembly_id, category_id)` for this store-layer invariant; a simple uniqueness constraint cannot express repeated model mappings inside one permitted category.

Only `assembly_id` is persisted in the mapping. Each model cell exposes one **Part number** field where the collaborator types the complete, final assembly number directly. There is no root column, suffix mode, or full-number override. In a blank cell, that complete value resolves to or creates the corresponding `manufacturing_assemblies.assembly_number` as described below. Editing the Part number in an already-mapped cell to a new, unused number renames that same `manufacturing_assemblies` record in place, preserving its stable ID, mappings, mini-BOM, images, nesting, and other dependent data; it does not create a replacement assembly.

If a final assembly number entered in a blank cell already exists in the project, the save reuses it only when its Built section equals the category section and its Installed section is compatible with the category's shared value. An assembly built in a different section or carrying a conflicting Installed section is blocked with a plain-language message. A new final number entered in a blank cell creates a minimal active `manufacturing_assemblies` row in the same transaction: `assembly_number` is the resolved final number, `name` initially copies the category display name, `make_buy` remains the compatibility blank until deliberately classified, `built_section_id` comes from the category, and `installed_section_id` comes from the category or remains null. System UUIDs and UTC timestamps are supplied automatically. The richer detail workflow may later edit the friendly name, Make / buy, nesting, images, and other existing assembly fields.

Editing a saved cell to a number already owned by another assembly in the same category begins a confirmed merge instead of failing uniqueness validation. Before writing, a non-dismissible dialog identifies the old and existing numbers; states that the old assembly record will be deleted; discloses its persisted mini-BOM, images, legacy rules, mappings, nesting links, and dormant dependents; and reports how many mini-BOM components the existing target assembly already owns. Cancel preserves the draft and both assemblies. Confirmation atomically redirects every mapping from the old assembly to the existing assembly, ignores any old-assembly component draft, preserves the target assembly and its authoritative mini-BOM unchanged, and deletes the superseded old assembly plus its dependent records and owned uploaded images. After refresh, the target's existing mini-BOM therefore appears in every redirected cell. Child and dormant target links that referenced the deleted assembly become unassigned under their existing foreign-key behavior. A target already associated with a different category remains blocked by the one-category-per-assembly invariant; chained merges must be completed one at a time. The confirmed merge records both the Assembly grid mapping save and an `Assemblies catalog` / `Merge assembly number` audit event.

Clearing a saved mapping deletes only this junction row after the Task 09 confirmation. It never deletes or clears the underlying assembly record or any of its owned data. Actual assembly deletion remains available only through the existing full Task 04 deletion workflow; its impact calculation must add direct mapping rows to the disclosed and cascade-deleted dependents. Model deletion likewise discloses mapping rows removed through its approved workflow. Inactive models are hidden from the grid but retain their mappings for a later reactivation.

#### New `assembly_grid_feature_visibility`

| Column | Definition | Purpose |
| --- | --- | --- |
| `id` | `TEXT PRIMARY KEY` | Stable string UUID for editing and audit details. |
| `project_id` | `TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE` | Carries and validates the project boundary. |
| `section_id` | `TEXT NOT NULL REFERENCES assembly_sections(id) ON DELETE CASCADE` | Identifies the Fishbone section whose grid owns the preference. |
| `feature_id` | `TEXT NOT NULL REFERENCES complexity_features(id) ON DELETE CASCADE` | Identifies the Complexity Tree feature header row. |
| `is_visible` | `INTEGER NOT NULL DEFAULT 1 CHECK (is_visible IN (0, 1))` | Stores whether the active feature row is shown for this section. |
| `created_at` | `TEXT NOT NULL` | UTC creation timestamp. |
| `updated_at` | `TEXT NOT NULL` | UTC latest-change timestamp. |

Enforce `UNIQUE(section_id, feature_id)`. Missing rows mean visible, so a new section shows every active feature without pre-populating preference data. Inactive features never render regardless of the saved value. A reactivated feature resumes its saved preference. Deleting a feature or section deletes only its display-preference rows; this does not remove or reinterpret any model value, assembly rule, mapping, category, Fishbone use, or part rule.

#### Grid behavior and component ownership

- A Fishbone-sections multiselect includes **All active sections** and defaults to that choice. Selected section grids are grouped in Fishbone order. An active-model multiselect defaults to every active model and affects display only; mappings for hidden models and categories in unselected sections are preserved on save.
- Header rows show Official model number followed by every visible active feature and that model's `model_feature_values` value. Feature toggles persist per project and section but never become feature applicability.
- A Components v2 grid renders sticky category fields, model columns, and indented component rows. Its row-creation action is labeled **Add Subassembly**. It stores no business data directly and returns a JSON-serializable draft to Python. Python performs all project, section, uniqueness, quantity, and foreign-key validation before any write.
- Editable grid controls retain stable focus identities across draft-state reruns. A single click anywhere in a model's Part number cell focuses its input, while **Tab** and **Shift+Tab** move forward and backward through the controls in their rendered order without losing the intended destination when the prior value is committed.
- Repeated adjacent assembly numbers are suppressed only by the renderer. The underlying draft retains every cell's real value, so the display-only blank does not mean inheritance and cannot erase a mapping. Focusing or editing the cell reveals its actual value.
- Each mapped cell expands only that assembly's existing `manufacturing_assembly_components` rows. There is no category-level component list or named component slot. The **Add part** control offers exact Fishbone uses with Part number and Part Name at the start of each dropdown option. Saved and draft mini-BOM rows display both Part number and Part Name together, with Quantity remaining separately editable.
- Component part numbers resolve only to exact `fishbone_part_assignments` in the category's section. One match resolves automatically. Multiple uses require a choice of exact Fishbone use. A catalog part without a use offers placement; an unknown number opens the existing create-and-place pattern for the required Part number, Part Name, revision, Fishbone quantity, and notes. These writes retain their existing Parts and Fishbone audit categories.
- Assembly-to-model applicability is inferred exclusively from saved `assembly_grid_model_mappings`. An active official model applies to an assembly exactly when its model/category cell maps to that assembly. Legacy `manufacturing_assembly_feature_rules` rows are not shown in Assembly Details and do not expand, restrict, or otherwise change the mapped-model set.

#### Save, deletion, audit, history, and navigation

Typing, pasting, and adding existing Fishbone uses to a mini-BOM modify only the component draft. Contributors may add multiple mini-BOM components consecutively before saving; each addition remains visible in the draft and is persisted only when they choose **Save & Refresh**. The shared orange Unsaved changes indicator, Undo, and blue **Save & Refresh** footer appear immediately below the grid. Save validates the complete unfiltered draft and uses one connection for category changes, Installed-section propagation, minimal assembly creation, mappings, and mini-BOM changes so partial application is impossible. Successful saves record Current editor attribution, reset the component draft, show a toast, and rerun. Creating a missing catalog part and Fishbone use remains an explicit immediate dialog action matching the existing Process at a Glance pattern.

Task 09 has the narrow Components v2 deletion-entry exception documented in `DESIGN_SYSTEM.md`. Clearing mappings, deleting categories, and removing mini-BOM rows may begin from the custom grid instead of Streamlit's native toolbar, but every operation uses a non-dismissible relationship-aware Streamlit confirmation dialog, validates the complete action, records audit history, resets state, shows a toast, and reruns. Category and mapping dialogs explicitly state that underlying assembly records and their mini-BOMs, rules, images, nesting, and files remain. Component deletion states that the Fishbone use and Parts Catalog record remain. Reassignment from one assembly number to another is an edit, not a deletion, and needs no confirmation.

Use audit categories `Assembly grid categories`, `Assembly grid mappings`, and `Assembly grid feature visibility`, while retaining the existing `Assemblies catalog`, `Assembly mini-BOM`, `Assembly images`, `Parts`, and `Fishbone part assignments` categories for their owning records. Legacy `Assembly feature rules` audit rows remain stored but are not an active Assembly Details history tab because that editor is no longer visible. Show one bottom **History** expander with tabs for the applicable active categories.

The existing `app_pages/assemblies.py` route remains registered but becomes the grid screen and primary Product structure destination, preventing current Fishbone Details links from targeting an unregistered page. The navigation label, page title, captions, README, project status, Overview copy, Fishbone action copy, and page smoke checks must be updated together. Selecting an assembly number opens one shared detail view above the full assembly catalog and deletion workspace; its first and default tab is **Images**, followed by **Mini-BOM**. It reuses the Task 04 store functions for catalog fields, images, mini-BOM, nesting, Make / buy, and full assembly deletion. The former Feature rules tab is not rendered. Do not duplicate those workflows.

#### Completed subassemblies in the Parts Catalog — approved September 4, 2026

Every manufacturing assembly is also a handled part after it is built. Add nullable `manufacturing_assemblies.catalog_part_id TEXT REFERENCES parts(id) ON DELETE RESTRICT` and a unique partial index on `(project_id, catalog_part_id)` for non-null links. The stable foreign key, rather than matching mutable number text at read time, connects exactly one assembly to exactly one Parts Catalog row. Both records remain project-wide.

Creating a new assembly number through Assembly grid **Save & Refresh** creates and links its Parts Catalog row in the same transaction. The generated row uses the assembly number as **Part number**, the category Display name as **Part Name**, quantity `1`, revision `0`, source `Assembly grid`, no image, and no explicit `part_scenario_activity` rows so it follows the established default-active behavior in every scenario. If the project already contains the same Part number, the assembly links to that row and preserves every collaborator-authored catalog field. Existing unlinked assemblies are backfilled by the repeatable schema upgrade using the same reuse-or-create rule and retain their assembly name as the generated Part Name.

For a linked assembly part, model applicability is derived exclusively from the assembly's saved `assembly_grid_model_mappings`. The Parts Catalog displays the mapped active official models and does not create or evaluate `part_feature_rules` for that row. Normal and bulk feature-rule changes reject linked assembly parts with a plain-language explanation. Renaming an assembly renames its linked catalog part atomically when the destination Part number is unused. If the destination already belongs to another Parts Catalog row, the operation requires the existing non-dismissible assembly-number merge confirmation; confirmation links the surviving assembly to the destination part, preserves the destination part's authoritative catalog fields and downstream relationships, preserves the superseded source part as an independent catalog record when it already has downstream relationships, and otherwise removes only that now-unreferenced generated source part. The disclosure reports both outcomes before writing.

Deleting an assembly never deletes its linked Parts Catalog row or that part's Fishbone, Process, image, feature, or scenario-activity relationships. Deleting a Parts Catalog row referenced by a current assembly is blocked by `ON DELETE RESTRICT`; the Parts deletion dialog identifies the assembly number and instructs the contributor to delete or merge the assembly first. Assembly creation, link/reuse, rename, merge, and backfill return audit-ready details. Interactive saves record both their Assembly grid or Assemblies catalog event and a `Parts` event; the one-time upgrade backfill records a `Parts` / `Assembly catalog backfill` event per affected project.

#### Nested subassemblies and multi-section grid — approved September 4, 2026

A completed manufacturing assembly may be consumed as a component of another manufacturing assembly. The operational nesting relationship is the existing mini-BOM path `parent manufacturing_assemblies.id` -> `manufacturing_assembly_components.fishbone_assignment_id` -> `fishbone_part_assignments.part_id` -> `manufacturing_assemblies.catalog_part_id` for the child. This relationship is project-wide, quantity-bearing, and many-to-many: one completed child assembly may be reused by multiple parent assemblies. The legacy `manufacturing_assemblies.parent_id` field remains an optional catalog-grouping relationship and is not automatically synchronized from mini-BOM containment.

No new persisted table or field is required. Adding a child assembly through the Assembly grid creates only an in-memory draft. On **Save & Refresh**, the app reuses an existing Fishbone use for that child's linked catalog part in the parent assembly's Built section, or creates that use and its mini-BOM component atomically when none exists. Imported evidence is not modified or treated as approval. Audit details identify automatically created Fishbone uses and the parent/child assembly relationships.

Store validation rejects direct self-containment and every indirect containment cycle. For a mapped parent assembly, each nested child assembly must be mapped to every official model mapped to that parent; a child may support additional models. A parent assembly number shared by several models therefore retains one authoritative project-wide mini-BOM rather than receiving model-specific component lists. Validation names the parent, child, and missing official models before any write.

The Assembly grid Fishbone-section control is a multiselect with an **All active sections** choice. Selected sections render together as clearly labeled grid groups in Fishbone order. One shared visible-model filter and one shared active-feature-header filter apply to every displayed group. Categories remain owned by exactly one section, and ordinary part options remain limited to exact Fishbone uses in that category's Built section. Completed-subassembly options may originate in any displayed section. One **Save & Refresh** validates and writes category, mapping, visibility, automatically created Fishbone-use, and mini-BOM changes for every displayed section in one transaction; an error rolls back the complete multi-section operation. Categories, mappings, and preferences belonging to unselected sections or hidden models remain unchanged.

#### Required Task 03 section-deletion extension

Task 09 adds two section references to the four already handled by the combined Fishbone continuity workflow. `assembly_section_delete_impact()` and `delete_assembly_sections()` must treat all six reference types as requiring one valid same-project target outside the deletion set:

1. `yamazumi_areas.section_id`
2. `process_part_groups.section_id`
3. `manufacturing_assemblies.built_section_id`
4. `manufacturing_assemblies.installed_section_id`
5. `assembly_grid_categories.section_id`
6. `assembly_grid_categories.installed_section_id`

Impact results separately report category Built-reference and Installed-reference counts, their combined reference count, affected category details, and the number of `assembly_grid_feature_visibility` rows that will be removed. A category that references the deletion set through both fields contributes two references, matching assembly reference counting. Feature-visibility preferences are disclosed but do not require continuity: they belong to the deleted source section, are removed with it, and are never merged into the target's independent display preferences.

The existing required target picker remains the single destination for all six reference types. Target validation retains the cross-scenario Yamazumi uniqueness checks and additionally evaluates the final category set that would exist under the target. It rejects case-insensitive, trimmed `ebom_name` or `display_name` collisions between an incoming category and a target category or among categories arriving from multiple deleted sections. Every collision error must state the rejected target section, the incoming category, the exact field that collided (**Official EBOM category name** or **Display name**), the conflicting value, and the existing or other incoming category holding that value, then instruct the contributor to choose a different target section. No inline rename flow is added.

Confirmed deletion re-queries all six reference types inside the transaction, validates the target, and atomically re-points Yamazumi areas, Process at a Glance part requirements, assembly Built sections, assembly Installed sections, category Built sections, and category Installed sections before deleting Fishbone uses and sections. Category and assembly references receive the same target, preserving mapping scope and continuous Installed-section synchronization at commit. The returned result and Fishbone framework audit details include category Built/Installed re-point counts and the feature-visibility removal count.

The combined non-dismissible disclosure dialog lists both category reference counts and the feature-visibility preferences that will be removed. Its target guidance names all six continuity reference types, and **Delete sections** remains disabled until the target passes both Yamazumi and category-collision validation.

Fishbone saved-state Undo must expand with the deletion workflow. `fishbone_plan_snapshot()` captures `assembly_grid_categories`, `assembly_grid_model_mappings`, and `assembly_grid_feature_visibility`. `restore_fishbone_plan_snapshot()` temporarily removes mappings and categories to release their section restrictions, rebuilds the Fishbone framework and existing linked records, then restores categories, mappings, and visibility preferences with their stable UUIDs in the same transaction. This prevents Undo from failing on `ON DELETE RESTRICT` or losing Task 09 planning data.

#### One-time local prototype reset

At implementation go-ahead, the live database was first backed up beneath ignored `data/backups/`, validated with SQLite `quick_check`, and then cleared of current `manufacturing_assemblies` rows and their dependent components, feature rules, images, and owned assembly-image files in one validated transaction. Existing foreign-key effects on dormant policies, material options, and target-assembly links were included even though their current counts were zero. Parts Catalog records, Fishbone uses and sections, models, features, and all non-assembly uploads were preserved. One `Assemblies catalog` / `Prototype data reset` audit event was recorded per affected project with deleted counts and the timestamp. The Task 04 tables were not dropped or rebuilt. The new Task 09 tables began empty, so every section grid starts empty rather than deriving mappings or categories from pre-reset assembly data.

- **Out of scope:** Process at a Glance assembly integration, output-assembly selection changes, a graphical complexity/decision tree, feature-to-section applicability, restoration of the withdrawn Task 02 mechanism, Task 06 revert changes, scenario-policy activation, or automatic conversion of `manufacturing_assembly_feature_rules` into direct mappings.

### Task 08 — Duplicate-model warning, assembly make/buy classification, and shared part-number colors

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** September 1, 2026
- **Review status:** **Approved and implemented on `Nicole_tabular_assembly_editing_complexity`, September 2, 2026.**
- **Purpose:** Add a project-wide, save-time potential-duplicate warning to Model definitions; add one project-wide Make / buy classification to each real assembly-number record; and make repeated real part numbers visually recognizable in the existing mini-BOM editor. This task adds no new screen and does not create the deferred cross-model or cross-assembly comparison view.
- **Connections:** Duplicate detection uses only `project_models`, `complexity_features`, and `model_feature_values` from the current Model definitions Complexity Tree. Make / buy is stored directly on `manufacturing_assemblies`. Mini-BOM colors derive the real part number through `manufacturing_assembly_components.fishbone_assignment_id` -> `fishbone_part_assignments.part_id` -> `parts.part_number`. No behavior in this task reads or writes Fishbone, Assemblies, or downstream data while checking models, and no behavior reads or writes `assembly_scenario_policies`.
- **Relationship to the critical thread:** The duplicate warning protects the project-wide Model definitions portion of the critical thread before downstream structure may exist. The Make / buy value extends the existing project-wide assembly identity already bridged from Parts Catalog and Fishbone through explicit mini-BOM components. Part-number coloring is a presentation-only view of those existing links and does not copy, replace, approve, or reinterpret any planning record.
- **Scope:** All three additions are project-wide. Duplicate detection excludes inactive `project_models` rows from the comparison set entirely and compares the currently active Complexity Tree features presented at save time. `manufacturing_assemblies.make_buy` applies to the same real assembly identity in every planning scenario. Colors are derived from project-wide real part numbers and carry no scenario state. Model definitions and Assemblies retain their **Project-wide** scope badges.

#### Duplicate-model detection

No new table or field is required. When a contributor clicks **Save & Refresh** for the Complexity Tree, the app evaluates the complete edited table before the database write:

1. Exclude every inactive model from the comparison set entirely.
2. For each unordered pair of remaining active models, normalize null, `NaN`, empty, and whitespace-only feature cells as unassigned.
3. Compare only currently active features that have a nonblank value on both models in that pair. A feature blank on either model is ignored and is never treated as a matching value.
4. If the pair has zero mutually assigned features, do not flag it.
5. If every mutually assigned feature value matches exactly, flag the pair as a potential duplicate. One mismatch among the mutually assigned features means the pair is not flagged.

The calculation uses only the edited Model definitions data and has no Fishbone, Assemblies, Parts Catalog, scenario, or downstream dependency. It is a soft warning, never validation: a save-time dialog lists each flagged pair using **Common name** and **Official model number**, offers a return to the table, and permits **Save anyway**. Closing or returning from the dialog does not save; choosing **Save anyway** performs the ordinary atomic Complexity Tree save. The warning result is not persisted, does not create a new audit event, and has no consequence after the save. The successful save continues using the existing Complexity Tree audit and History workflow.

#### New project-wide `manufacturing_assemblies.make_buy`

Add exactly one column to the existing assembly master:

| Column | Definition | Purpose |
| --- | --- | --- |
| `make_buy` | `TEXT NOT NULL DEFAULT '' CHECK (make_buy IN ('', 'Make', 'Buy'))` | Stores the project-wide Make / buy classification for one real assembly number. The empty string exists only to preserve unclassified records created before Task 08; it is not a third business status. |

The safe in-place schema upgrade adds the column with its empty default and performs no backfill. Existing assembly records remain blank and unclassified; the app must not infer or default them to Make or Buy. New assembly records require an explicit `Make` or `Buy` selection. An existing blank record may remain blank through unrelated catalog work and receives a value only when a contributor deliberately edits its Make / buy field. Catalog validation accepts only the compatibility blank, `Make`, or `Buy`, validates the complete operation before writing, and persists the field atomically through the isolated project-wide assembly-catalog writer.

This decision supersedes the earlier decision that parked make/buy under `assembly_scenario_policies`. `manufacturing_assemblies.make_buy` is now the sole active and authoritative Make / buy value. The dormant `assembly_scenario_policies.sourcing_decision` column and its table remain completely untouched, unread by active workflows, unsynchronized, un-migrated, and non-authoritative. A future owner-reviewed scenario-policy proposal must explicitly reconcile that legacy dormant column; this task does not do so. The hidden `manufacturing_assemblies.pits_reference` and `planning_reason` fields remain stored, hidden, and unmodified and are not repurposed for Make / buy.

The Assembly catalog adds a controlled **Make / buy** column beside the assembly identity fields and a corresponding filter and filtered-export column. A `Buy` assembly may have zero, one, or many explicit mini-BOM components. The existing component store already accepts an empty mini-BOM, so no component schema or validation exception is added. When a selected `Buy` assembly has no components, the UI shows the neutral explanation **No components listed. A Buy assembly may intentionally have an empty mini-BOM.** A selected `Make` assembly with no components shows **No components listed yet.** The editable table remains available in both cases, and a populated Buy mini-BOM is not warned against or blocked.

#### Shared part-number color-coding

No color table, field, preference, or persisted mapping is added. In this task, color appears only on a new disabled **Part number** column in the selected assembly's mini-BOM editor. The displayed value is derived from the existing Fishbone-use-to-Part relationship. A shared deterministic hash-based helper maps the exact trimmed real `parts.part_number` to a contrast-safe background and text color, so the same part number receives the same visual color across assemblies and reruns without hardcoding colors to known parts. Native `pandas.Styler` coloring applies only to this noneditable column; no general CSS or custom component is introduced.

Do not add part-number coloring to the Assembly catalog table or the Fishbone inline assembly list in this task. Those views do not currently contain assembly-component part-number comparisons, and extending them would change their approved purpose. The fuller cross-model/cross-assembly comparison view represented by the original spreadsheet example is explicitly deferred as a separate, unscoped future proposal; it may reuse the deterministic color helper after passing its own gate.

#### Applicable standards

- Keep the exact **Save & Refresh** action and shared editable-table footer for both existing editors. Duplicate detection runs from the Complexity Tree action before its write; Make / buy saves with the complete Assembly catalog operation.
- Record Make / buy changes under the existing `Assemblies catalog` / `Save & Refresh` audit category with the assembly ID/number and old/new value in JSON details. Expose a readable Make / buy change summary in the existing bottom History expander's **Catalog** tab so the persisted change is not hidden only in JSON. Do not create a separate History section.
- Retain the Assemblies **Project-wide** scope badge. Use **Make / buy** as the UI label and `Make` and `Buy` as its controlled values.
- Use this help text for the field: **Make means the assembly is produced internally. Buy means it is obtained as a complete assembly. This classification applies across every planning scenario.**
- No new deletion workflow or dependent-record disclosure is required for the scalar Make / buy field. It is removed with its owning assembly through the already-approved assembly deletion workflow.
- Preserve filtered-out catalog rows, stable assembly identifiers, Current editor attribution, editor reset/rerun behavior, full-operation validation, and atomic store-layer writes. The duplicate warning and color assignment are computation/UI-only and require no new audit records.

### Assemblies catalog (real, pre-existing assembly numbers)

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** August 27, 2026
- **Review status:** **Approved and implemented on `Nicole_Assemblies_Addition`, August 27, 2026.**
- **Purpose:** Add a project-wide catalog of real, pre-existing assembly numbers. A Fishbone section and an assembly number remain separate entities: one section may be the built or installed location for many assembly numbers, and each assembly number owns an authoritative, explicitly edited mini-BOM rather than a BOM computed from feature rules.
- **Connections:** Reuse `manufacturing_assemblies` as the authoritative assembly-number record. Every catalog assembly has a built-section reference and an installed-section reference to `assembly_sections`; the two references may be identical. Mini-BOM rows reference exact `fishbone_part_assignments` occurrences and reach Parts Catalog records through those occurrences. Task 09 supersedes the original active assembly-feature-rule workflow: direct assembly-grid model mappings now determine model applicability, while stored assembly feature rules remain compatibility data and do not reuse or modify `part_feature_rules`. The locked `work_element_material_groups` and `work_element_material_options` tables are not used. Existing free-text Process output-assembly fields and all Process selection behavior remain out of scope.
- **Relationship to the critical thread:** The catalog forms an explicit project-wide bridge from Model definitions and approved Fishbone structure toward future Process planning. The current model path is `project_models` -> `assembly_grid_model_mappings` -> `manufacturing_assemblies`; the component path remains `parts` -> `fishbone_part_assignments` -> assembly mini-BOM components -> `manufacturing_assemblies` -> built/installed `assembly_sections`. A future Process task may offer an assembly only to steps tied to its installed section; this phase stores the required distinction but does not add that Process UI or relationship.
- **Scope:** Project-wide, matching Parts Catalog, Fishbone structure, and `part_feature_rules`. No new catalog, mini-BOM, feature-rule, or image row carries `scenario_id`. The new Assemblies page must use the **Project-wide** scope badge. The lightweight assembly list on the Scenario-aware Parts to fishbone page still reads project-wide assembly data.
- **Reuse and isolation:** Extend and reuse `manufacturing_assemblies`; do not create a second assembly master. Add normalized child tables for mini-BOM components, feature rules, and supplemental images. New catalog reads and writes must use isolated project-only store functions that do not accept `scenario_id`, join `assembly_scenario_policies`, or write scenario policies. The existing dormant `manufacturing_assemblies(project_id, scenario_id)`, `replace_manufacturing_assemblies(...)`, `bulk_update_assembly_policy(...)`, and scenario-cloning policy logic remain untouched and unreferenced by the new page. Existing `pits_reference` and `planning_reason` values remain stored but hidden and are not written by the new workflow; Task 08 did not repurpose them when it added the separate authoritative `make_buy` field.

#### Extended `manufacturing_assemblies`

Retain every existing column and add the following catalog fields:

| Column | Definition | Purpose |
| --- | --- | --- |
| `built_section_id` | `TEXT REFERENCES assembly_sections(id) ON DELETE RESTRICT` | Identifies the section where the assembly is built and whose placed Fishbone uses are eligible for its mini-BOM. Nullable at the database level for compatibility with the dormant writer, but required by every new isolated catalog save. |
| `installed_section_id` | `TEXT REFERENCES assembly_sections(id) ON DELETE RESTRICT` | Identifies the section where the completed assembly is installed and supports future Process-step eligibility. Nullable at the database level for compatibility with the dormant writer, but required by every new isolated catalog save. |
| `catalog_part_id` | `TEXT REFERENCES parts(id) ON DELETE RESTRICT` | Links the assembly to the Parts Catalog row that represents the completed subassembly as handled material. Nullable only for upgrade and legacy-writer compatibility; active assembly writers populate it. |
| `image_path` | `TEXT DEFAULT ''` | Stores the primary assembly-image path, mirroring the primary-image-on-master-record pattern used by Parts Catalog. |
| `created_at` | `TEXT` | Stores the UTC creation timestamp. Existing rows are backfilled from `updated_at`; new isolated catalog writes always supply it. |

`assembly_number` remains the stable, required real-world identifier and stays unique within a project. The app never generates an assembly number. `name` remains its editable friendly name. As superseded by the September 4 nested-subassembly decision above, `parent_id` remains an optional one-parent catalog grouping retained for compatibility and deletion-tree organization; quantity-bearing operational nesting is derived from mini-BOM containment and may have multiple parents. Catalog-grouping saves still validate same-project parents, reject self-parenting and cycles, and show the approved soft warning when a grouped child's installed section differs from its parent's built section. Skipping an assembly-number tier requires no flag.

#### New `manufacturing_assembly_components`

| Column | Definition | Purpose |
| --- | --- | --- |
| `id` | `TEXT PRIMARY KEY` | Stable string UUID for editing, deletion, and audit details. |
| `project_id` | `TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE` | Carries and validates the project boundary. |
| `assembly_id` | `TEXT NOT NULL REFERENCES manufacturing_assemblies(id) ON DELETE CASCADE` | Identifies the assembly whose authoritative mini-BOM owns the row. |
| `fishbone_assignment_id` | `TEXT NOT NULL REFERENCES fishbone_part_assignments(id) ON DELETE CASCADE` | References one exact placed Fishbone part-use. Deleting that use automatically removes this component row. |
| `quantity` | `REAL NOT NULL CHECK(quantity > 0)` | Stores the explicit positive component quantity for this assembly. |
| `created_at` | `TEXT NOT NULL` | UTC creation timestamp. |
| `updated_at` | `TEXT NOT NULL` | UTC latest-change timestamp. |

Enforce `UNIQUE(assembly_id, fishbone_assignment_id)`. Store validation must confirm that the assembly and assignment belong to `project_id` and that, when the component is added or edited, the assignment is currently placed in the assembly's built section. A newly added component defaults to the Fishbone use's current quantity at that moment. Its saved quantity then becomes independent: later Fishbone quantity changes do not update the mini-BOM, and mini-BOM quantity changes do not update Fishbone. The same Fishbone use may appear in any number of different assembly mini-BOMs with a different quantity in each.

If an assembly's own `built_section_id` is changed, every Fishbone use referenced by that assembly's current mini-BOM is moved to the new section in the same atomic transaction. This relocation is unconditional, including when another assembly also references the same use. Parts in the old section that are not in this assembly's mini-BOM remain untouched. Any other assembly whose shared mini-BOM reference no longer matches its built section retains the component row and receives a visible mismatch warning for deliberate review; the row is not silently changed or removed. The same mismatch detection applies if a collaborator separately moves a referenced Fishbone use.

Deleting one or more Fishbone uses must first show exactly which assembly numbers and mini-BOM component rows will be affected. Confirmation proceeds without blocking, and `ON DELETE CASCADE` removes those component rows while leaving the assembly records intact. Section-deletion impact calculations must likewise include mini-BOM rows that will disappear when uses inside the deleted section are removed.

#### Completed existing quantity change

`fishbone_part_assignments.quantity` was safely converted from `INTEGER` to `REAL NOT NULL DEFAULT 1 CHECK(quantity > 0)` after the project owner approved the usage audit. Fishbone and mini-BOM quantities now accept positive decimal values such as `1.5` inches of tape or `0.02` pints of lubricant; zero, negative, nonnumeric, NaN, and infinite values are rejected by the store layer. Fishbone and Process displays use shared clean-number formatting, and history change detection rounds to nine decimal places to avoid false changes from floating-point noise.

#### Legacy `manufacturing_assembly_feature_rules` compatibility table

| Column | Definition | Purpose |
| --- | --- | --- |
| `id` | `TEXT PRIMARY KEY` | Stable string UUID for editing, deletion, warning resolution, and audit details. |
| `project_id` | `TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE` | Carries and validates the project boundary. |
| `assembly_id` | `TEXT NOT NULL REFERENCES manufacturing_assemblies(id) ON DELETE CASCADE` | Identifies the assembly-number owner. |
| `feature_id` | `TEXT NOT NULL REFERENCES complexity_features(id) ON DELETE RESTRICT` | References one generic Model definitions feature and prevents silent feature deletion while a rule exists. |
| `value` | `TEXT NOT NULL` | Stores one choice from the referenced feature's `allowed_values`; the store layer validates it because choices are JSON values rather than foreign-key rows. |
| `created_at` | `TEXT NOT NULL` | UTC creation timestamp. |
| `updated_at` | `TEXT NOT NULL` | UTC latest-change timestamp. |

The original Task 04 implementation enforces `UNIQUE(assembly_id, feature_id)` and its isolated compatibility writer continues validating legacy rows. Task 09 supersedes the active behavior: the table has no visible editor or History tab, stale or current rows do not participate in applicability, and `assembly_model_applicability()` returns the active official models explicitly connected through `assembly_grid_model_mappings`. Existing rows remain untouched so old databases, snapshots, deletion-impact counts, and Undo restoration remain safe.

#### New `manufacturing_assembly_images`

| Column | Definition | Purpose |
| --- | --- | --- |
| `id` | `TEXT PRIMARY KEY` | Stable supplemental-image UUID. |
| `project_id` | `TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE` | Carries and validates the project boundary. |
| `assembly_id` | `TEXT NOT NULL REFERENCES manufacturing_assemblies(id) ON DELETE CASCADE` | Attaches the image to exactly one assembly number. |
| `image_path` | `TEXT NOT NULL` | Stores the validated uploaded-file path. |
| `caption` | `TEXT DEFAULT ''` | Optional free-text caption; it is not a named image slot or image type. |
| `created_at` | `TEXT NOT NULL` | UTC creation timestamp and stable display ordering. |

The master row's `image_path` holds one primary image; this child table holds unlimited supplemental images. Both primary and supplemental images support validated PNG, JPG/JPEG, and WEBP uploads plus direct screenshot paste. No `image_type`, exploded-view slot, finished-view slot, grouping-level image, or other labeled slot is introduced. Parts Catalog's current image implementation remains unchanged. Deleting an image or assembly removes its owned upload files using the same safe upload-directory checks as Parts Catalog.

#### Section references, replacement, and assembly nesting/deletion

- Fishbone section deletion evaluates the selected sections and every descendant included in the deletion. The current Task 03/04 workflow requires one same-project target outside the deletion set when it finds a linked `yamazumi_areas` row, `process_part_groups` row, or `manufacturing_assemblies` Built/Installed reference. The confirmed Task 09 extension adds `assembly_grid_categories.section_id` and `assembly_grid_categories.installed_section_id`, producing six continuity reference types under the same required target picker. The dialog separately discloses each count plus source-section feature-visibility preferences that will be removed, and keeps **Delete sections** disabled until a valid target is selected.
- Target validation preserves one target-linked Yamazumi area per planning scenario by merging affected source areas into the target section's existing area when one exists. If the target has no area in that scenario, one affected area becomes the survivor. Pitches, work elements, and work-region definitions move with their stable IDs; identical work-region names reuse the target definition. Scenario-wide pitch-address validation remains the final safeguard. The Task 09 extension still rejects final target-category collisions on trimmed, case-insensitive `ebom_name` or `display_name`. The error identifies the rejected target, incoming category, exact colliding field and value, and conflicting category, and instructs the contributor to choose a different target. Categories are never renamed inline.
- Confirmed deletion performs one atomic transaction: merge or re-point affected Yamazumi areas; re-point Process at a Glance, assembly Built/Installed, and Task 09 category Built/Installed references; delete source-section feature-visibility preferences; delete remaining Fishbone uses in the deleted sections; and delete the sections and descendants. A Built-section assembly re-point retains Task 04 behavior by relocating every Fishbone use referenced by that assembly's mini-BOM before remaining uses are removed. Those relocated uses survive under the target; every other removed placement returns its Parts Catalog record to **Not placed**. Fishbone saved-state Undo captures and restores Task 09 categories, mappings, and visibility preferences with the existing framework snapshot.
- Parent-nesting validation compares a child's installed section with its parent's built section. A mismatch opens one save-time warning dialog describing every mismatch. It is never a validation block: dismissing or declining the warning leaves the selected parent valid and the save may proceed with that choice.
- Direct assembly deletion uses the Universal Deletion Standard and one upfront dialog showing the complete affected descendant tree. For each child depth/level, the contributor selects one action for that whole level: **Move to grandparent**, **Delete entirely**, or **Become unassigned**. Every level is shown in the same dialog, including levels below a group marked Delete entirely; each deeper level still receives its own explicit destination choice rather than inheriting an unseen cascade decision.
- **Move to grandparent** assigns that level's surviving assemblies to the next surviving parent level while retaining their built section, installed section, mini-BOM, rules, and images. **Become unassigned** clears `parent_id`, `built_section_id`, and `installed_section_id`, removing the assemblies from catalog nesting and Fishbone built/installed lists without deleting their records; their retained mini-BOM rows are visibly mismatched until deliberately reassigned. **Delete entirely** removes the chosen assembly rows and their owned mini-BOM rows, feature rules, images, and uploaded files after all deeper-level choices have been validated.
- The upfront dialog must disclose all affected catalog records, mini-BOM rows, rule rows, image rows/files, child levels, and existing dormant `assembly_scenario_policies`, `work_element_material_options`, and target-assembly links. Dormant references remain uneditable in this phase, but their actual foreign-key cascade or unassignment effects must never be omitted from the confirmation. The complete multi-level action validates before one atomic database write; no sequential per-level pop-ups or partial application is allowed.

#### Store-layer functions

Add isolated, project-bound store functions with no scenario-policy coupling:

- `assembly_catalog_rows(project_id)`
- `save_assembly_catalog_rows(project_id, rows)`
- `assembly_catalog_delete_impact(project_id, assembly_ids)`
- `delete_assembly_catalog_rows(project_id, assembly_ids, level_actions)`
- `assembly_bom_components(project_id, assembly_id)`
- `save_assembly_bom_components(project_id, assembly_id, rows)`
- `assembly_feature_rules(project_id, assembly_id)` — legacy compatibility read
- `save_assembly_feature_rules(project_id, assembly_id, rows)` — legacy compatibility writer; not called by active UI
- `assembly_model_applicability(project_id, assembly_id)` — derives active models from direct grid mappings
- `assembly_images(project_id, assembly_id)`
- `set_assembly_image(project_id, assembly_id, uploaded_file)`
- `add_assembly_image(project_id, assembly_id, uploaded_file, caption='')`
- `delete_assembly_images(project_id, assembly_id, image_ids)`
- `assemblies_for_section(project_id, section_id)`
- `fishbone_assignment_assembly_impact(project_id, assignment_ids)`
- `assembly_section_reference_impact(project_id, section_ids)`
- `repoint_assembly_section_references(project_id, replacements, connection=None)`
- `assembly_section_delete_impact(project_id, section_ids)`
- `assembly_section_delete_target_validation(project_id, section_ids, target_section_id, active_scenario_id=None)`
- `delete_assembly_sections(project_id, section_ids, target_section_id=None, active_scenario_id=None)`

All writes validate project ownership, complete input sets, required fields, uniqueness, parent cycles, positive quantities, section/component consistency, file types, and stale-rule restrictions before changing data. Multi-table operations use one connection so catalog changes, mini-BOM relocation, re-pointing, and deletion remain atomic. Expected failures raise user-readable `ValueError` messages.

#### UI and applicable standards

- Add a new **Assemblies** page and navigation item under Product structure. As superseded by Task 09, the route now provides the Assembly grid plus catalog fields, built/installed sections, parent nesting, primary/supplemental images, mini-BOM, and the warning/deletion workflows above. Images are the default first Assembly Details tab, Mini-BOM is second, and feature rules are hidden. `pits_reference`, `planning_reason`, and every scenario-policy field stay hidden.
- The main catalog table shows Assembly number, Assembly name, Built section, Installed section, Parent assembly, Active, Notes, and Details. It supports filters, direct blank-row entry and multi-row paste, external sorting, native row selection, filtered export, validation, Undo, and the standard **Save & Refresh** footer.
- The selected assembly's mini-BOM editor offers only exact Fishbone uses currently in its built section for new rows, displays clear part-number/use context, and stores its independent decimal quantity. Image controls support upload and screenshot paste for both primary and supplemental images. The former feature-rule editor is retained only in legacy code/storage compatibility and is not rendered.
- Parts to fishbone shows only a lightweight read-only list for the selected section. An assembly appears for both relationships, labeled **Built here** and/or **Installed here**; when both references point to the selected section, both relationships are shown. Each row displays the assembly number and a Details action that navigates to the shared Assemblies page and selects that same underlying record. No assembly editing is added to Fishbone.
- Follow every locked `DESIGN_SYSTEM.md` standard: `page_title_with_scope()` with a Project-wide badge and standard hover text; native table selection/select-all; native confirmed deletion; direct row creation; filters and sorting above tables; orange Unsaved changes, Undo, and blue **Save & Refresh** immediately below each editable table; editor resets and reruns; Current editor attribution; `record_audit_event()` for every save, deletion, image action, re-pointing, and bulk action; and a bottom History expander with tabs when multiple assembly workflow categories are shown. Use stable UUIDs internally, friendly assembly/section labels in the UI, plain-language help for built versus installed sections, Material Symbols, native bordered containers, and no new general CSS.

- **Out of scope:** Process at a Glance assembly selection, output-assembly-milestone linking, handling/sub-touch chains, exploded-BOM comparison, supplier/cost/buffer and other scenario-policy behavior, and multi-touch/sub-touch support. Task 08 implemented one project-wide `manufacturing_assemblies.make_buy` value without activating or consulting scenario policies. Do not modify or build UI against `assembly_scenario_policies`, `work_element_material_groups`, or `work_element_material_options` except to disclose their existing foreign-key effects during an approved assembly deletion.

### Section-level qualifying-condition feature rules (OR across features) — Withdrawn

- **Status:** **Withdrawn — reverted before merge by project owner decision, August 27, 2026.** This section is retained only as a decision record. The table, store behavior, Fishbone UI, filter integration, and feature-specific tests described below are not part of the active application or schema and must not be restored without a new approved proposal.
- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** August 25, 2026
- **Purpose:** Add a separate, additive set of qualifying conditions to a Fishbone section. Each condition is exactly one manufacturing feature plus one allowed choice. Multiple conditions attached to the same section combine with OR. Existing `part_feature_rules` remain unchanged and continue using their current same-feature-alternatives/different-features-AND behavior.
- **Connections:** Conditions belong to `assembly_sections` and reference `complexity_features`. The Phase 1 Fishbone filter compares the selected feature/choice identity directly with section conditions and existing part rules; it does not require resolving a complete official model through `model_feature_values`. A condition affects only `fishbone_part_assignments` whose `section_id` directly references that exact section. Conditions do not flow from parent sections into nested subassemblies, and this feature must not query, modify, or evaluate the blocked `fishbone_nodes` MBOM-review staging table.
- **Relationship to the critical thread:** The new rows sit between project-wide Model definitions and the project-wide Fishbone framework: `complexity_features` -> `assembly_section_feature_conditions` -> `assembly_sections` -> `fishbone_part_assignments` -> `parts` / existing `part_feature_rules`. Conditions are evaluated dynamically rather than copied into each Fishbone-use row, so every directly placed use inherits its section's current rule without per-use tagging or duplicated persisted applicability.
- **Scope:** Project-wide. The Parts to fishbone page remains Scenario-aware because scenario-specific part activity controls which uses are visible, but the inline qualifying-condition subsection must carry its own **Project-wide** scope indicator. Changes affect the section in every scenario.
- **Storage:** Add the normalized table `assembly_section_feature_conditions`. A separate table is required because one section can own zero or more independently editable feature/choice pairs and because reusing `part_feature_rules` would mix two different owners and logical operators. Do not add a JSON condition column to `assembly_sections` and do not modify the schema or interpretation of `part_feature_rules`.

  | Column | Definition | Purpose |
  | --- | --- | --- |
  | `id` | `TEXT PRIMARY KEY` | Stable string UUID for editing, deletion, and audit details. |
  | `project_id` | `TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE` | Carries and validates the project boundary. |
  | `section_id` | `TEXT NOT NULL REFERENCES assembly_sections(id) ON DELETE CASCADE` | Makes one exact Fishbone section the condition owner. Deleting that section deletes its condition rows. |
  | `feature_id` | `TEXT NOT NULL REFERENCES complexity_features(id) ON DELETE RESTRICT` | References a generic Model definitions feature. `ON DELETE RESTRICT` is an intentional, owner-approved deviation from the original cascade proposal: a referenced feature cannot be deleted until its saved section conditions are deliberately resolved, preventing silent deletion or hiding of condition data. |
  | `value` | `TEXT NOT NULL` | Stores one choice from the referenced feature's current `allowed_values`. Choices are currently JSON values on `complexity_features`, so the store layer must validate this value rather than relying on a choice-table foreign key. |
  | `created_at` | `TEXT NOT NULL` | UTC creation timestamp. |
  | `updated_at` | `TEXT NOT NULL` | UTC latest-change timestamp. |

  Enforce `UNIQUE(section_id, feature_id, value)` so the same condition cannot be attached to one section twice. Store-layer validation must confirm that the section and feature belong to `project_id`. New or edited conditions must use a currently available feature/choice pair.
- **Evaluation logic:** The existing **View fishbone for features** control remains a simple feature/choice membership lookup and does not require selecting or resolving a complete official model. For each selected feature/choice, a section passes when it has no conditions or any saved condition references the selected pair. A part passes when it has no part-level rule or its existing rule set references the selected pair. A Fishbone use appears only when both the section lookup and part lookup pass. Multiple selected filter choices retain the control's existing any-selected membership behavior. Existing `part_feature_rules` storage and full model-applicability behavior must not be modified, replaced, or reinterpreted. Only the Parts to fishbone visual and its existing feature filter consume the combined lookup in this phase; Excel export and every other project-wide or downstream view are deferred.
- **Stale-condition preservation and evaluation:** Deactivating a referenced feature or removing a referenced choice must not delete or hide its saved condition. The store layer and inline UI must retain it and visibly flag it in the summary, for example, **Warning: references a removed choice — review and update**. While unresolved, that individual stale condition evaluates **fail open** and imposes no model restriction. Because section conditions combine with OR, the presence of a stale condition keeps the section gate open for every model until a collaborator corrects or removes it. The warning is the only signal: stale conditions do not block filtering, stop other model matching, or stall unrelated page work. This follows the approved default-open convention and prevents stale references from silently hiding real Fishbone uses.
- **UI:** On Parts to fishbone, selecting a Fishbone section reveals an inline condition editor beneath that section. Its approved horizontal builder presents a Feature dropdown, a dependent Choice dropdown containing only that feature's current allowed values, and **Add condition**. Additions remain unsaved until the resulting condition list's standard **Save & Refresh** action. The editor shows a live plain-language summary from the unsaved draft, such as **This section applies to models where: Brand = Acme OR Product Line = Commercial**. No standalone rules-management screen or per-row dialog is added. Any collaborator may edit these conditions; this is not IE-exclusive ownership.
- **Applicable standards:** Follow every locked table standard in `DESIGN_SYSTEM.md`: direct entry where supported, native row selection, external sorting when row creation disables native sorting, orange unsaved warning, Undo, and the blue **Save & Refresh** footer; validation before atomic store-layer writes; editor reset and rerun; Current editor attribution; `record_audit_event()` for saves and deletions; and the page's bottom History expander. Native deletion must use a confirmed workflow. The section-deletion confirmation must disclose the exact number of qualifying-condition rows that will be cascade-deleted with the section.
- **Phase boundary:** This phase does not modify or build against the dormant Phase 2 Assemblies catalog (`manufacturing_assemblies` or `assembly_scenario_policies`) and does not extend effective applicability into Phase 3 Process at a Glance integration, exports, or other screens.
- **Decision history:** Nicole Ervin approved Phase 1 implementation on August 26, 2026, then withdrew it before merge on August 27, 2026. The independent preservation of the original **View fishbone for features** behavior and the separate Fishbone section-deletion Yamazumi/Process re-pointing correction are not part of this withdrawal.

## Quality module active tables

### New Module Proposal Gate record — shared Equipment catalogs

- **Purpose and connections:** Provides one project-wide identity for installed equipment used by Functional Reviews. Scenario placements optionally connect an equipment record to one Yamazumi Pitch and to one or more `work_elements.id` Process Functions at that Pitch. Installed Torque tools may link many-to-many to project-wide Torque `quality_requirements`; requirement-level Torque specifications remain in `quality_requirement_torque_details`.
- **Critical-thread relationship:** Equipment may exist unplaced. A critical-thread relationship begins only through a scenario placement and hidden `work_elements.id`; Equipment name, Type, Station / Pitch text, and Op ID are never relationship keys.
- **Scope:** Equipment Types, assets, Functional Review associations, images, and Torque-requirement links are project-wide. Placement and Process links are scenario-specific. Scenario cloning reuses each project asset and creates fresh placement/Process-link identities remapped to the cloned Pitch and Work Elements.
- **Applicable standards:** Stable hidden IDs, direct entry, filters, external sorting, filtered export, Undo, **Save & Refresh**, Current editor attribution, universal audit events, relationship-aware confirmed deletion, one bottom History area, canonical terminology, and Scenario-aware boundary guidance apply.
- **Approval status:** Nicole Ervin approved the shared Equipment catalog, Functional Review tabs, first-release Torque relationships, and deferred type-specific extension strategy on September 25, 2026. The uploaded line map, station hotspots, hover/click station details, equipment-layout images, and currently undefined specialized fields remain deferred.

### `equipment_types` and `equipment_type_function_links`

- **Purpose:** Stores reusable Equipment Type labels and the Functional Reviews in which each type chart appears.
- **Scope and fields:** Project-wide stable UUID, case-insensitively unique Label, timestamps, and normalized applicability links for Quality, Ergonomics, Safety, Materials, or future Assembly. No Active field is stored.
- **Initialization:** Each project is seeded idempotently with Torque tool, ESD equipment, Vision equipment, Scan/Compare equipment, Test equipment, and Conveyor. The first five initially apply to Quality; Conveyor is retained for the future Assembly Equipment tab.
- **Deletion:** Confirmed deletion is blocked while any equipment asset uses the type. Removing a Functional Review applicability is blocked while that review still uses the type.

### `equipment_assets` and `equipment_function_links`

- **Purpose:** Stores one shared physical-equipment identity that can appear in several Functional Reviews without duplicating shared information.
- **Stored fields:** Stable UUID, project, Equipment Type, case-insensitively unique Equipment name, Description, Manufacturer, Model, Notes, one owned primary-image path, timestamps, and normalized Functional Review associations. There is no asset/serial identifier and no Active field.
- **Lifecycle:** Removing a Functional Review association preserves the shared asset and every other relationship. Permanent deletion is available only from the top-level Equipment page and removes disclosed placements, Process links, Torque links, associations, and the owned image in one relationship-aware workflow.

### `equipment_placements` and `equipment_process_links`

- **Purpose:** Places shared equipment in a planning scenario and optionally links it to Process Functions.
- **Rules:** One equipment asset has at most one placement per scenario and may be Unassigned. A placement stores at most one Yamazumi Pitch; every linked `work_elements.id` must belong to that project, scenario, and Pitch. If all linked work moves to one new Pitch, the UI offers a confirmed move. Split-Pitch links require manual reconciliation and are never guessed, duplicated, or silently unlinked.
- **Cloning:** Scenario cloning creates fresh placement and Process-link IDs, remaps Pitch and Work Element relationships, and continues referencing the same project-wide equipment asset.

### `equipment_torque_requirement_links`

- **Purpose:** Links installed Torque tool assets many-to-many with project-wide Torque Quality requirements.
- **Display and validation:** The Equipment UI reads the requirement's saved target, tolerances, unit, and current requirement-level Tool type, Tool orientation, and Screw bit type. A Process Function without the linked requirement published to that exact step produces a warning but does not block saving. Existing Control Plan Torque measurement derivation remains sourced from the published Quality assignment and requirement-level Torque details.
- **Boundary:** A `quality_requirement_torque_details` row describes the requirement and never creates or proves the existence of a physical installed tool.

### New Module Proposal Gate record — guided PFMEA patterns

1. **Connected entities:** PFMEA Entries, Effects, Causes, Recommended Actions, project-wide Quality requirement definitions, manual Prevention/Detection catalogs, and scenario-specific Process Functions.
2. **Critical-thread relationship:** Catalog patterns remain non-relational project guidance until applied. The staged PFMEA graph then connects to the critical thread only through the selected scenario-owned `work_elements.id`.
3. **Scope:** The reusable catalog is project-wide; every generated PFMEA graph and resolved published Quality control remains scenario-specific.
4. **Why new tables are required:** Existing normalized PFMEA tables are scenario-owned reviewed records and cannot safely double as reusable templates. Separate normalized pattern header, graph-child, and source-reference tables preserve reusable structure without sharing live PFMEA identities or ratings.
5. **Applicable standards:** Stable hidden UUIDs, project/scenario boundary validation, native confirmed deletion, filtered export, explicit Undo and **Save & Refresh**, atomic writes, Current editor audit attribution, the existing bottom PFMEA History group, project-wide scope badges, help text, and canonical terminology all apply. Pattern application itself is session-only and is audited only when the generated PFMEA draft is saved.

**Approval:** Nicole Ervin approved implementation of this project-wide catalog and guided scenario-specific staging workflow on September 17, 2026.

### `quality_requirements`

- **Purpose:** Stores the reusable Quality requirements repository, including Type, Description, Unique identifier, Pass/fail behavior, Target value, Tolerances, and Unit. Repository edits remain project reference data until an explicit push synchronizes them to linked Process requirements.
- **Key relationships:** Belongs to `projects` and is the project-wide parent of `quality_requirement_assignments` and, for requirements whose Type is Torque, the optional one-to-one `quality_requirement_torque_details` record. A definition may also be referenced as a reusable Prevention or Detection suggestion by a project-wide PFMEA pattern. Unique identifiers are case-insensitively unique within a project. A repository requirement cannot be deleted while Process assignments, Torque tool details, or PFMEA pattern sources still reference it.
- **Scope:** Project-wide.

### `quality_requirement_types`

- **Purpose:** Stores the reusable controlled Type labels offered by the project-wide Quality requirements repository. The catalog retains stable hidden UUIDs while `quality_requirements.requirement_type` remains the approved text-backed value.
- **Key relationships:** Belongs to `projects` and matches `quality_requirements.requirement_type` case-insensitively by Label; no new foreign-key column is added to `quality_requirements`. Labels are case-insensitively unique within a project. Every project is seeded idempotently with Dimensional, Present and fully seated, Torque, Vision system, and its exact pre-existing in-use Type values.
- **Scope:** Project-wide. Active entries may be assigned to new or changed requirements. An inactive or unmatched value remains visible on an unchanged saved requirement but cannot be newly assigned.
- **Rename, deactivation, and deletion:** Torque is permanent and cannot be renamed, deactivated, or deleted. Other entries may be deactivated while in use, preserving and visibly flagging existing requirement values. An in-use rename requires explicit confirmation, atomically updates matching repository requirement text and timestamps, and leaves published Process-step assignment snapshots unchanged until the existing explicit push. Deletion is confirmed and restricted while any Quality requirement uses the entry.
- **Approval status:** Nicole Ervin, project owner, approved the controlled Type catalog, confirmed in-use rename cascade, permanent Torque entry, and text-backed relationship on September 4, 2026.

### `quality_requirement_assignments`

- **Purpose:** Attaches a published copy of a repository Quality requirement to a specific Process at a Glance step. The copied requirement values remain unchanged during an ordinary repository save and are updated only by the explicit repository push workflow.
- **Key relationships:** Belongs to `projects` and `planning_scenarios`, references `work_elements`, and references `quality_requirements`. Project and scenario boundaries are validated against the selected Process step. Deleting a Process step or scenario deletes its assignments; deleting the referenced repository requirement is restricted until its assignments are removed. Scenario cloning copies assignments and remaps them to the cloned `work_elements` records while retaining their project-wide repository links.
- **Scope:** Scenario-specific through the referenced Process at a Glance step, with published content sourced from the project-wide repository.

### `quality_requirement_torque_details`

- **Purpose:** Stores the project-wide Torque tool details for a Quality requirement whose Type is Torque, including Tool type, Tool orientation, and Screw bit type.
- **Key relationships:** Belongs to `projects` and references exactly one `quality_requirements` row through a unique `quality_requirement_id`, creating an optional one-to-one relationship. The parent requirement must belong to the same project and have Type set to Torque. Its indirect connection to the critical thread is `quality_requirements` → `quality_requirement_assignments` → `work_elements`.
- **Scope:** Project-wide, matching the parent Quality requirement. Tool type is limited to Air tool, Electric clutch tool, or DC tool. Tool orientation is limited to Fixtured, Pistol, In-line, or Right angle. Screw bit type is free-entry text with project suggestions sourced from previously saved values.
- **Deletion and type changes:** Deleting the detail record preserves the parent Quality requirement and every Process-step assignment. The parent requirement cannot be deleted or changed away from Type Torque until its detail record is removed through the confirmed workflow.

### `pfmea_patterns`

- **Purpose:** Stores the project-wide catalog of reviewed PFMEA starting patterns. Each pattern has a required case-insensitively unique Label and Potential Failure Mode, optional Notes and suggested Classification, an Active state, stable UUID, and timestamps. It intentionally stores no Severity, Occurrence, Detection, RPN, Responsibility, completion evidence, or resulting ratings.
- **Connections and scope:** Belongs to `projects`. A pattern has no scenario or Process relationship while it remains in the catalog. Applying it to a selected scenario-specific Process Function creates fresh session-only PFMEA graph identities linked through that target `work_elements.id`; only the ordinary PFMEA **Save & Refresh** persists those records. Generated PFMEA rows retain no pattern lineage.
- **Lifecycle:** Patterns are filtered, exported, edited, activated/deactivated, captured from one saved PFMEA entry, and deleted through the approved project-wide manager. Pattern writes are atomic and editor-attributed in PFMEA History. Deleting a pattern cascades only its template children and never changes PFMEA graphs previously created from it.

### `pfmea_pattern_effects`, `pfmea_pattern_causes`, and `pfmea_pattern_actions`

- **Purpose:** Store the ordered reusable analysis graph below one `pfmea_patterns` row: Effect text, Cause text, and recommended Action text. These tables deliberately omit all initial and resulting ratings, responsibility, target date, and Actions Taken.
- **Key relationships:** Each row belongs to one pattern. Pattern Actions may reference one pattern Cause. Stable UUIDs and integer sequence preserve graph identity and collaborator order inside the catalog.
- **Scope:** Project-wide through the parent pattern. Applying a pattern creates new scenario-specific PFMEA Entry, Effect, Cause, Action, and risk-row identities rather than reusing these catalog IDs.

### `pfmea_pattern_prevention_sources` and `pfmea_pattern_detection_sources`

- **Purpose:** Store ordered Cause-level control suggestions for a PFMEA pattern. Each source is exactly one project-wide Quality requirement definition or one manual option from the corresponding Prevention/Detection catalog.
- **Resolution:** Quality-definition IDs are resolved only when the target Process Function has a published `quality_requirement_assignments` row for that exact definition, project, scenario, and `work_elements.id`. No assignment is created or remapped. Active correct-catalog manual options resolve directly. Unpublished Quality sources and inactive/unavailable manual sources are disclosed in the preview and omitted.
- **Relationships and deletion:** Partial unique indexes prevent duplicate Cause/source suggestions. Referenced Quality definitions and manual options cannot be deleted until the pattern reference is removed. Deleting the parent pattern cascades these rows. Labels remain live presentation values; internal IDs never render.
- **Scope:** Project-wide through the parent pattern. Resolved selections become scenario-specific only after the staged PFMEA graph is saved.

### `pfmea_entries`

- **Purpose:** Stores one scenario-specific Potential Failure Mode for a Process at a Glance step, its reviewed short-code Classification (blank, `S`, `R`, `E`, `P`, `P-`, `Q`, `E-`, `M`, or `PM`), an optional read-only `legacy_class_code`, read-only Process Function snapshots, and source fingerprints used to flag later upstream changes without replacing reviewed PFMEA evidence. The code meanings are Critical to Product Safety, Regulatory, Engineering CTQ, Process CTQ, Process CTQ done at qualification, Quality Specific, Engineering CTQ at qualification, Maintain Control, and Preventative Maintenance, respectively.
- **Key relationships:** Belongs to `projects` and `planning_scenarios`, and references one `work_elements` row. It is the parent of `pfmea_effects`, `pfmea_causes`, the structured Prevention/Detection selections, `pfmea_risk_rows`, and `pfmea_actions`. A cloned scenario receives independent PFMEA IDs and retains `source_pfmea_entry_id` lineage to the source entry.
- **Scope:** Scenario-specific. The referenced Process step must belong to the same project and scenario. A Process step with PFMEA entries cannot be deleted until those entries are removed through the confirmed PFMEA workflow.

### `pfmea_effects`

- **Purpose:** Stores one or more Potential Effects for a PFMEA entry, with a collaborator-entered whole-number Severity from 1 through 10 and sequence.
- **Key relationships:** Belongs to one `pfmea_entries` row. Deleting an Effect through the confirmed workflow also removes its derived Effect-Cause `pfmea_risk_rows` records.
- **Scope:** Scenario-specific through the parent PFMEA entry. The module does not define or persist a company Severity scale.

### `pfmea_causes`

- **Purpose:** Stores one or more Potential Causes for a PFMEA entry, with optional collaborator-entered whole-number Occurrence and Detection ratings from 1 through 10 and sequence. `control_source_review_required` marks source changes or removals for review. Detection-source changes additionally set `detection_review_required` without changing the Detection rating.
- **Key relationships:** Belongs to one `pfmea_entries` row and is parent of its structured Prevention/Detection selections, applicable `pfmea_risk_rows`, and optional cause-level `pfmea_actions`.
- **Scope:** Scenario-specific through the parent PFMEA entry. The module does not define or persist company Occurrence or Detection scales. Detection may be entered without a selected Detection control.

### `pfmea_prevention_options` and `pfmea_detection_options`

- **Purpose:** Store reusable manual phrases for Prevention and Detection controls in separate catalogs. Each row has a required Label and Active state; labels are case-insensitively unique within its project and catalog.
- **Key relationships:** Belongs to `projects` and may be referenced by the corresponding scenario-specific selection table or project-wide PFMEA pattern-source table. Deactivation preserves existing PFMEA selections but prevents new selection and prevents pattern application from using that suggestion. Confirmed deletion cascades dependent saved selections and flags their Causes for review, but is blocked while a PFMEA pattern still references the option.
- **Scope:** Project-wide. Scenario cloning continues to reference the same manual option IDs.

### `pfmea_prevention_selections` and `pfmea_detection_selections`

- **Purpose:** Store ordered, structured Cause-level Current Process Controls. Each selection is either one published `quality_requirement_assignments` record or one manual option from the corresponding project catalog; check constraints require exactly one valid source.
- **Key relationships:** Belongs to one scenario-specific `pfmea_entries` row and `pfmea_causes` row. A Quality source must belong to the same project/scenario and linked `work_elements.id`; a manual source must belong to the same project and correct catalog. Partial unique indexes prevent duplicate Cause/source selections within one control list, while the same Quality assignment may appear once in each of the Prevention and Detection lists.
- **Scope:** Scenario-specific. Stable selection IDs and sequence preserve collaborator order. Scenario cloning creates new selection IDs, remaps PFMEA parents and Quality assignment IDs, and retains project-wide manual option IDs.
- **Source review and deletion:** `source_updated_at_snapshot` records the source version acknowledged at Save & Refresh. Live source labels are displayed; source updates set Cause review flags. A Quality unlink or catalog-option deletion removes only dependent selections transactionally, preserves Quality definitions/PFMEA ratings, and flags affected Causes. Detection-source changes also require Detection-rating review.
- **Legacy migration:** On the first PFMEA opening for a project with legacy `pfmea_controls` rows, a nonblank Current editor is required. The rows and their text are atomically discarded, affected Causes are flagged, and exactly one project-scoped PFMEA audit event records counts without recording discarded text. The obsolete table is dropped after no project retains legacy rows. Quality requirements and assignments are preserved.

### `pfmea_risk_rows`

- **Purpose:** Stores the calculated initial RPN for each Effect-Cause combination as historical save evidence. RPN is recorded as Severity × Occurrence × Detection when all three ratings exist and remains blank otherwise.
- **Key relationships:** Belongs to one PFMEA entry and references one `pfmea_effects` row and one `pfmea_causes` row. It is derived and refreshed atomically whenever the applicable flat line is saved. The separate **Recalculate RPN** action refreshes the same calculation from unsaved editor values without persistence and preserves each stable flat-line identity without appending duplicate saved rows.
- **Scope:** Scenario-specific through the parent PFMEA entry. No threshold, rating lookup, or risk classification is inferred from RPN.

### `pfmea_actions`

- **Purpose:** Stores one or more Recommended Actions for a PFMEA failure mode or a specific cause, including Responsibility, Target Completion Date, Actions Taken, Resulting Severity, Resulting Occurrence, Resulting Detection, and the persisted calculated Resulting RPN.
- **Key relationships:** Belongs to one `pfmea_entries` row and may reference one of that entry's `pfmea_causes` rows. Resulting ratings are whole-number values from 1 through 10. Resulting RPN is recalculated and overwritten on every PFMEA line-item save when all three resulting ratings exist; **Recalculate RPN** refreshes the unsaved display without persistence.
- **Scope:** Scenario-specific through the parent PFMEA entry. These actions do not automatically create future Control Method or Reaction Plan content.

### `control_plan_items`

- **Purpose:** Stores collaborator-authored fields and lifecycle state for the scenario-specific Manufacturing Control Plan working-draft body. A live projection creates one characteristic line for each classified PFMEA entry and applicable published Quality definition explicitly selected as a Prevention control, Detection control, or both; duplicate Prevention/Detection use creates one line. A classified PFMEA entry with no qualifying Quality source receives one visibly incomplete PFMEA-only fallback line.
- **Key relationships:** Belongs to `projects`, `planning_scenarios`, and one authoritative `pfmea_entries` parent. A Quality-sourced item may reference a live `quality_requirement_assignments` row and its `quality_requirements` definition. It also retains the Quality-definition identity plus minimal Unique identifier and Description snapshots so a confirmed Quality unlink can clear the live assignment reference without discarding MCP-owned content. PFMEA deletion cascade-deletes dependent working-draft items after disclosing the impact.
- **Scope:** Scenario-specific through the parent PFMEA entry and Process step. Scenario cloning creates fresh Control Plan item IDs, remaps PFMEA and live Quality-assignment references, and preserves manual fields, Characteristic type, Characteristic suffix overrides, exclusion, source-review state, and orphan snapshots.
- **Stored fields:** Stable UUID; project, scenario, PFMEA, and optional Quality relationships; source kind (`quality` or `pfmea_only`); source snapshots; nullable numeric `pr_number`; nullable positive whole-number `characteristic_suffix`; Characteristic type stored in the existing `characteristic_placement` field as blank, `Product / Part`, or `Process`; Machine / fixture; Sample size; Sample frequency; Who; Control method; Decision rule / corrective action and reference documents; excluded state; acknowledged source fingerprint; source-review state; characteristic `sequence`; and timestamps. No Equipment reference is stored. `pr_number` and `characteristic_suffix` are document display values, not relationships, identities, sort keys, or Process sequence.
- **Process and characteristic numbering:** Every persisted item belonging to the same hidden `work_elements.id` operation in one scenario stores the same nullable `pr_number`. The table displays Pr. Nº only on that operation's first currently visible line. Editing it synchronizes visible and filter-hidden characteristic lines in the complete scenario draft; conflicting values for one operation fail visibly without a partial write. **Renumber Pr. Nº by Op ID** stages `1.0`, `2.0`, `3.0`, and so forth across every active qualifying operation in the complete live Op ID order, including filter-hidden rows. It preserves suffix overrides and unrelated draft edits, writes nothing until **Save & Refresh**, and records the renumbered operation count in the normal single Control Plan save event. Excluded and source-ineligible retained items are not renumbered. The existing `sequence` continues to order characteristic lines. A blank Characteristic suffix receives the lowest available positive integer in stable characteristic order after reserving manual overrides. Suffixes are label segments rather than decimal arithmetic, so `10.9` is followed by `10.10`, and Pr. Nº `97.5` with suffix `1` displays `97.5.1`. Changing Pr. Nº rebuilds labels without changing suffixes or row order. Duplicate manual suffixes within one operation require the same non-dismissible Cancel or **Save anyway** review used for duplicate Control Plan numbers.
- **Suggestions and migration:** Newly qualifying unnumbered operations receive non-persistent suggestions in the same live PFMEA Process order used by the Process Function picker. That shared order keeps Fishbone traversal primary, then naturally compares a conforming Pitch address by separately decoded numeric sub-line, case-insensitive work-area letters, numeric work-area suffix, and numeric position before applying Yamazumi element/stack and stable-ID tie-breakers. A nonconforming Pitch remains selectable and follows conforming addresses in its Fishbone group, using the curated Yamazumi Pitch sequence as its deterministic fallback. With no occupied values suggestions begin at `10.0` and increment by `10.0`; gaps between increasing neighbors are divided evenly at one-decimal precision; leading gaps divide the interval from `0.0`; trailing rows append by `10.0`. Equal, reversed, occupied, or insufficient one-decimal gaps fall back after the scenario maximum. Persisted excluded and source-ineligible items reserve their numbers. Existing items receive one idempotent project-scoped, editor-attributed atomic backfill from their former `process_sequence_snapshot.0` display, synchronized per operation across scenarios and recorded once in Control Plan History. The snapshot remains historical evidence and migration input rather than the live suggestion-order source.
- **Derived and grouped display:** **Station / Pitch** repeats the current `work_elements.station` value on every characteristic line through the existing hidden Process-step relationship; a blank value displays as Unassigned. The pinned read-only **Op ID** column repeats the full live derived identifier, including the Yamazumi stack position suffix, on every characteristic line and is included in filtered export. Op ID is presentation/order context resolved through hidden `work_elements.id`; it is never stored on a Control Plan item or used as a relationship. A difference from the PFMEA `process_pitch_snapshot` raises the existing non-blocking source-review flag without changing PFMEA or Control Plan data. Operation continues to use the PFMEA Process Function snapshot, and CL uses the current PFMEA short code. Lines are grouped contiguously by hidden `work_elements.id` in Process order; Pr. Nº and Operation are blanked after the first currently visible line. Repeated Machine / fixture text is blanked only when every visible value for the operation is identical. Streamlit does not merge cells, and all blanking is limited to rendered/exported copies so stored values remain intact. The UI labels the existing placement field **Characteristic type**, displays `Product / Part` as **Product**, and flags Not assigned lines while leaving both characteristic columns blank. Quality lines use published assignment Description, Target value, Tolerances, Unit, and Type. Torque evaluation text also uses current project-wide Torque tool details.
- **Lifecycle:** Opening the tab writes no working-draft item or suggestion. Save & Refresh persists the editable MCP fields, synchronized Process numbers, suffix overrides, and current source fingerprints atomically. Duplicate Process numbers across different operations or duplicate manual suffixes within one operation produce a non-dismissible warning; Cancel retains the complete draft, while Save anyway performs the ordinary single audited save. Later source changes remain live in the working-draft display and raise a non-blocking review flag. Confirmed native deletion sets excluded state and preserves content; the review area supports audited restore. Source-ineligible items remain retained there. Orphaned Quality items require explicit relinking to the same project, scenario, Process step, and Quality definition after that assignment again qualifies as a PFMEA control; they are never reconnected automatically. Process numbers and suffix overrides survive exclusion, orphaning, restoration, relinking, source changes, and scenario cloning.
- **Derived Process Flow Map:** The read-only Phase 10 view projects every current scenario Process step through hidden `work_elements.id` and the shared live Op ID order, including steps with no qualifying Control Plan characteristic. Fishbone hierarchy supplies structural lane grouping; `yamazumi_pitches.feeds_into_pitch_id` alone supplies exact physical feed joins, with unresolved feeders displayed rather than inferred. Active, non-excluded Control Plan projections supply Product, Process, and unassigned characteristic nodes plus read-only detail evidence. Pr. Nº is display context only. Filters, pan, zoom, Fit, full screen, tooltips, and detail viewing write no data and create no audit event. Internal identities remain opaque and never render. Structured reject routing and document/Word export remain deferred.
- **Approval status:** Nicole Ervin, project owner, approved this MCP working-draft body implementation on September 8, 2026, collaborator-curated Process numbering on September 9, 2026, and the read-only interactive Process Flow Map on September 16, 2026. Issued/released status, document headers, Purpose, Scope, Parts, revision/approval workflow, and Word export remain deferred.

## Approved derived views

### Phase 3 — inline pitch-level visual summary

- **Approved by:** Nicole Ervin, project owner
- **Date approved:** September 11, 2026, confirming the September 10 Phase 3 proposal
- **Purpose:** Replace the retired per-step Process Details dialog with a read-only, inline 16:9 pitch summary beneath the scenario-specific Process at a Glance table. Selecting **Details** on a Work Element opens the five-element page containing that step, using browser-session pitch and page state only.
- **Connections and scope:** Resolve the stable pitch exclusively through `work_elements.id` ← `yamazumi_elements.process_element_id` → `yamazumi_elements.pitch_id` → `yamazumi_pitches.id`, validating the active project and planning scenario. Use `assembly_section_walk_order(project_id)` and authoritative `yamazumi_elements.sequence` for deterministic presentation. The view reads existing Process part pairings, Parts Catalog images, model applicability, qualifying Ergonomics risk reviews, published Torque requirement assignments/details, and live-derived Op IDs.
- **Storage:** No new table, field, cached identifier, audit event, or backfill is introduced. `selected_pitch_id` and `pitch_page_num` are temporary `st.session_state` values. Pages contain exactly five Work Elements except the final partial page.
- **Presentation:** Each page contains up to five vertically stacked cards with Pitch, Op ID, Work Element, paired-part images or a same-sized **No Parts Paired** placeholder, a Yamazumi time segment, Models, and an extensible footer tag row. Qualifying Open/Pending Red or Favorable Red reviews display **Ergo Risk**. Published Torque assignments display target, tolerance, and unit. Every page includes **Generated on [date] — Scenario: [name]** as point-in-time evidence for live-derived Op IDs.
- **Motion color compatibility:** Existing storage has no persisted VA/NVAN/NVA or Waste field. A Work Element whose active classified part uses are exclusively Consume displays green **Value-Added (VA)**; exclusively Handle displays orange **Non-Value-Added but Necessary (NVAN)**. Missing, compatibility-null, mixed, or part-less classifications display neutral gray **Unclassified**. The view must not infer or display red Waste until a separately approved persisted source supports that meaning.
- **Applicable standards:** This is a read-only derived view, so Save & Refresh, Undo, deletion, audit writes, and new History behavior do not apply. Reuse the shared Details action, canonical labels, Material Symbols, scenario boundary behavior, live Op ID help, safe HTML escaping, and existing bottom Process History section.

## Future ideas — not yet proposed

### In-house fabrication tagging for Fishbone sections

In-house fabrication tagging for Fishbone sections: a future idea to mark a Subassembly-type Fishbone section as representing an in-house fabrication process (e.g., stamped metal, injection molding), for Quality's PFMEA and Control Plan tracking. Confirmed approach: an orthogonal flag added to an existing Subassembly section (not a new `section_type` value). The section remains structurally an ordinary Subassembly in every respect — walk order, nesting, parent/child rules, and all existing behavior are unaffected. The flag only changes its display designator in the Op ID naming scheme (an `F` instead of `S`) and will drive future Quality-tracked fields once scoped. Requires Quality's input on what specific data should be tracked (for example, tooling, material lot, process parameters) before a real proposal can be written and before the New Module Proposal Gate can be completed. Not yet approved, not yet scoped, no implementation should begin from this note alone.

## Proposed modules — pending owner review

### PITS BOM-tab structure import (parent-child occurrences and quantities)

- **Proposed by:** Project owner
- **Date recorded:** September 24, 2026
- **Purpose:** Extend the existing preferred Tracker+Models PITS import into one combined import step that also reads the BOM worksheet's Level 1-11 staggered hierarchy columns, so Industrial Engineers no longer have to manually rebuild product structure and quantities in Fishbone and Assembly Grid for every new program.
- **Connections and relationship to the critical thread:** The combined import connects PITS source evidence from the Tracker, Models, and BOM worksheets to project-wide Parts Catalog records and a new staged parent-child occurrence layer. After human review, an occurrence may be matched or confirmed to a real, already-existing `assembly_sections` row and represented as an approved `fishbone_part_assignments` use. This preserves the Product Architecture/PITS evidence -> Parts Catalog -> Fishbone -> scenario-specific Yamazumi -> scenario-specific Process at a Glance critical thread. Escalated differences also connect to Questions and concerns for discussion and resolution.
- **Scope:** The imported source structure, staging queue, Parts Catalog relationships, Fishbone sections, and approved Fishbone uses are project-wide. This proposal does not introduce scenario-owned source or staging records; existing downstream scenario-visibility rules remain unchanged.
- **Single combined import step:** Uploading a PITS workbook parses Tracker+Models using the existing behavior, unchanged, and parses the BOM worksheet's Level 1-11 hierarchy in the same import pass.
- **Hierarchy parsing:** For each BOM row, depth is the leftmost populated Level column among columns D through N (Level 1 through Level 11). Its parent is the nearest preceding row at one shallower depth, resolved with the same stack-based traversal approach already used by the existing legacy Level 1-11 parser.
- **Stable occurrence identity:** Each position in the imported tree is identified by the pair `(parent PITS tracker number from Column A, child PITS tracker number from Column A)`. This pair has been confirmed stable across re-uploads, and a child tracker number has been confirmed not to repeat beneath the same exact parent.
- **Duplicate-pair reconciliation:** If a workbook nevertheless contains a repeated parent-child pair, the duplicate does not block the combined import. One staged occurrence is retained under the stable identity, all conflicting BOM row numbers are displayed in its validation flag and review queue, and the occurrence cannot be approved until a later PITS re-import contains only one source row for that pair. The uniqueness constraint remains unchanged and no row-number-based identity is invented.
- **Catalog identity versus occurrence identity:** A tracker number continues to identify only which catalog part a source row represents. It must never be reused as the identity of an occurrence because the same tracker number may legitimately occur under many different parents, such as for a common fastener. The existing `fishbone_nodes` model enforces one row per project and `pits_id` and therefore cannot represent these repeated structural occurrences.
- **Staging and approval:** Every newly discovered occurrence is automatically added to a **Needs review** staging queue and is never silently approved as a real Fishbone use. A BOM-tab assembly-level row can become usable for real, quantity-tracked Fishbone uses only after an Industrial Engineer manually matches or confirms it to a real, already-existing `assembly_sections` row. The import never creates assembly sections automatically.
- **Authoritative quantity:** PITS BOM quantity is the single source of truth for fishbone_part_assignments.quantity. On every import, the approved quantity is automatically updated to match the latest PITS BOM value with no manual review step required, because a quantity discrepancy can only be corrected at the source (the design engineer updating PITS), not by the Industrial Engineer inside this application.
- **Traceability label:** Whenever an import changes an approved quantity, the affected Fishbone use displays a passive, non-blocking "Updated from PITS on [date]" label for traceability. This label is informational only, requires no acknowledgement or dismissal, and does not block or alter any other workflow.
- **Structural review remains manual:** the "Needs review" staging queue, manual matching to assembly_sections, and the "differs from PITS" flag continue to apply only to structural changes (new occurrences, occurrences no longer found, an occurrence appearing under a different parent) - never to quantity value changes, which are now automatic.
- **Escalation for quantity disagreements happens outside the software:** if an Industrial Engineer believes a PITS quantity is wrong, the application does not provide a quantity-override or dispute mechanism. The resolution path is a conversation with the design engineer to correct PITS at the source, reflected automatically on the next import.
- **Review UI:** Importing a new file opens one non-dismissible review window listing every suspected addition, change, and removal. All rows are selected by default, following Select All behavior, and the Industrial Engineer may deselect individual rows before accepting. Each row also provides a separate **Escalate** action.
- **Escalation behavior:** Escalating a row creates a linked Questions and concerns record while preserving the normal **differs from PITS** flag on the affected record at the same time. The flag remains visible on the record, and the concern exists separately for discussion and resolution; escalation neither replaces nor suppresses the flag.
- **Storage decision and persisted state:** `pits_bom_imports` records completed snapshots; `pits_bom_occurrences` stores the stable parent-child review row; `pits_bom_occurrence_revisions` preserves distinct structural source versions; and `pits_bom_occurrence_concerns` preserves escalation links. `fishbone_part_assignments.pits_sync_status` displays `Not linked`, `In sync`, `Quantity differs`, or `No longer found`. These tables remain distinct from `fishbone_nodes` so the same tracker number can participate in multiple parent-child relationships.
- **Applicable standards:** Source evidence remains distinct from collaborator-approved planning decisions. Review acceptance is explicit, assembly sections are never auto-created, approved uses and quantities are never silently overwritten or removed, and escalation preserves both the source-difference state and the separately linked concern. The implemented Import/Export review queue uses native selection, non-dismissible confirmation, Current editor audit attribution, PITS BOM History, and relationship-aware deletion safeguards consistent with `DESIGN_SYSTEM.md`.
- **Deferred interaction:** Whether or how this scoped workflow will eventually reconcile with the dormant MBOM-review confirmation workflow remains **BLOCKED / TBD**. The occurrence workflow does not read, write, replace, or extend `fishbone_nodes`.
- **Approval status:** Approved by the project owner and implemented on September 24, 2026. The active Import/Export Projects path parses Tracker, Models, and BOM with one workbook reader, previews every hierarchy issue with its exact Excel row and available Tracker, part, description, Level, expected-parent, and quantity context, imports the snapshot atomically, opens the default-selected non-dismissible review dialog, provides the persistent per-occurrence approval/rejection/escalation queue, and records PITS BOM structure History.

### View-Only PITS Model Tree (CAD Browser Reference)

- **Proposed by:** Nicole Ervin, project owner
- **Date recorded:** September 28, 2026
- **Purpose:** Provide a dedicated view-only Model Tree screen inspired by CAD model browsers (e.g., Autodesk/Creo viewer reference), derived directly from the imported PITS BOM tab structure and using its recorded Levels (Level 1–11 via `proposed_depth` and tracker parentage) to build an expandable visual tree. It is interactive by official model, showing the product architecture hierarchy and flagging gap discrepancies—specifically highlighting parts on the tree that are missing from the Parts Catalog and/or missing from the Fishbone diagram (not placed into any Fishbone section).
- **Navigation placement & coexistence:** Placed as a separate page named "Model Tree" in the "Product structure" navigation group, keeping the existing "Assembly grid" page intact and active.
- **Answers to New Module Proposal Gate Questions:**
  1. *Connected entities:* Connects to `project_models` (Model selection), `pits_bom_occurrences` (raw Level 1–11 PITS hierarchy, tracker numbers, and quantities), `parts` (Parts Catalog master data and model applicability), and `fishbone_part_assignments` (Fishbone framework placement and sections).
  2. *Critical thread relationship:* Connects raw Product Architecture/PITS evidence (`pits_bom_occurrences`) to the Parts Catalog (`parts`) and Fishbone diagram (`fishbone_part_assignments`). It functions as an inspection and reconciliation tool to identify parts in the engineering BOM that have not yet been onboarded into the Parts Catalog or assigned to any Fishbone section.
  3. *Scope:* Project-wide, consistent with the project-wide scope of PITS BOM evidence, Parts Catalog, and Fishbone framework structure.
  4. *Table requirement:* No new database table required. Reads directly from existing tables: `pits_bom_occurrences`, `parts`, `fishbone_part_assignments`, `assembly_sections`, and `project_models`.
  5. *Applicable DESIGN_SYSTEM.md standards:* Scope badge `page_title_with_scope("Model Tree", scope="project")`; Canonical terminology ("Official model number", "Parts Catalog", "Fishbone section"); view-only layout with split Model Browser tree on the left and Properties inspector panel on the right matching the CAD viewer reference; no edit/save/delete buttons required.
- **Core capabilities:**
  1. *Official model filter:* Select an official model to display only the tree branches and parts applicable to that specific model according to PITS BOM data.
  2. *CAD browser tree layout (Left panel):* Expandable/collapsible hierarchy tree with search (`Search Model Browser`), node depth indentation matching PITS Levels, Level indicator, part number, description, and status badges.
  3. *Reconciliation flags on tree nodes:*
     - `:material/error:` `Missing from Parts Catalog` (if part number does not exist in `parts`).
     - `:material/warning:` `Missing from Fishbone` (if part exists in `parts`, but has 0 `fishbone_part_assignments` for the project).
     - `:material/check_circle:` `Placed: [Section Name]` (if placed into Fishbone).
  4. *Properties inspector panel (Right panel):* When a tree node is clicked, displays its metadata: Part number, Description, Level, PITS Tracker Number, PITS Quantity, Catalog status (Make/Buy, Technology Engineer, etc.), and Fishbone placement details (Section, Use / installation location).
  5. *Summary metrics header:* Displays total nodes in model tree, count placed in Fishbone, count missing from Fishbone, and count missing from Parts Catalog.
- **Status:** Implemented on September 28, 2026; pending project-owner manual verification.

### Parts Catalog cross-functional fields and PITS Tracker mapping

- **Proposed by:** Nicole Ervin, project owner
- **Date recorded:** September 28, 2026
- **Purpose and connection:** Extend each project-wide `parts` record with cross-functional collaborator roles and metadata imported from PITS Tracker tab: Subsystem (Col F, new column), Design Maturity (Col G, mapped from and renaming Revision), Design Engineer (Col I, mapped from former Technology Engineer), PPM (Col J), Buyer / GCL (Col K), PMQE / AQE (Col L), AME / Tooling Engineer (Col M), and Part Code (Col N). In addition, rename Official Windchill Part Name to Factory Nickname. These fields add critical collaborator ownership and catalog context at the Parts stage of the Product Architecture/PITS evidence -> Parts Catalog -> Fishbone -> Yamazumi -> Process at a Glance critical thread.
- **Answers to New Module Proposal Gate Questions:**
  1. *Connected entities:* Connects directly to `parts` (Parts Catalog) and `pits_records` (PITS Tracker source evidence).
  2. *Critical thread relationship:* Direct 1:1 attribute on `parts` and `pits_records` linked by `part_id` / `pits_id`, extending the Parts stage of the critical thread.
  3. *Scope:* Project-wide, consistent with the project-wide scope of `parts` and PITS Tracker source records.
  4. *Table requirement:* Existing table `parts` (and `pits_records`) serves it directly. Schema additions:
     - `subsystem TEXT NOT NULL DEFAULT ''` (Column F: "Subsystem", new column in Parts Catalog)
     - `design_maturity TEXT NOT NULL DEFAULT ''` (Column G: "Design Maturity", mapped to and renaming "Revision" in Parts Catalog, with backward-compatible alias to `revision`)
     - `design_engineer TEXT NOT NULL DEFAULT ''` (mapped from Column I: "Design Engineer", with backward-compatible alias to `technology_engineer`)
     - `factory_nickname TEXT NOT NULL DEFAULT ''` (renamed from "Official Windchill Part Name", with backward-compatible alias to `official_windchill_part_name`)
     - `ppm TEXT NOT NULL DEFAULT ''` (Column J: "PPM")
     - `buyer_gcl TEXT NOT NULL DEFAULT ''` (Column K: "Buyer / GCL")
     - `pmqe_aqe TEXT NOT NULL DEFAULT ''` (Column L: "PMQE / AQE")
     - `ame_tooling_engineer TEXT NOT NULL DEFAULT ''` (Column M: "AME / Tooling Engineer")
     - `part_code TEXT NOT NULL DEFAULT ''` (Column N: "Part Code". Codes: NP = New Part, New Tool; NPNT = New Part, No Tooling; ASM = Assembly; CP = Current Production; CP Other = CP different site)
  5. *Applicable DESIGN_SYSTEM.md standards:* Standard Parts Catalog table editor with atomic Save & Refresh, Undo, filter/search/Excel export, audit logging with Current editor attribution in Parts category, and sentence-case headers.
- **Status:** Proposed by project owner on September 28, 2026; pending implementation and verification.

### Parts Catalog engineering fields

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** September 17, 2026
- **Purpose and connection:** Extend each existing project-wide `parts` record with Technology Engineer, PITS ID, Source Code, Official Windchill Part Name, and Make vs Buy. The fields add reviewed catalog context at the Parts stage of the Product Architecture/PITS evidence -> Parts Catalog -> Fishbone -> Yamazumi -> Process at a Glance critical thread without replacing imported evidence or downstream planning decisions.
- **Scope and storage:** Store all five fields directly on `parts`; no new table or relationship is introduced. Existing and newly migrated records default to blank. PITS ID remains stored in the legacy `pits_tracker_number` column as trimmed text, preserves leading zeros, and is unique among nonblank values within a project. Source Code accepts blank or `1` through `8`. Make vs Buy accepts blank, `Make`, or `Buy`. Technology Engineer and Official Windchill Part Name are trimmed optional text.
- **Applicable standards:** Edit the fields through the existing scenario-aware Parts Catalog table and its atomic **Save & Refresh** and Undo workflow. Include them in filters, search, and filtered Excel export. Record changed old/new values with Current editor attribution in the existing `Parts` audit category and retain the bottom Parts history. The existing relationship-aware deletion workflow and scenario-specific Active field are unchanged.
- **Approval status:** Approved by the project owner on September 17, 2026; implemented on `NE_Parts_Catalog_Updates`.

### Takt display-unit preferences

- **Proposed by:** Codex
- **Date proposed:** September 15, 2026
- **Connections:** `projects.takt_time_unit` controls the project-default takt presentation and the default for newly created scenarios. `planning_scenarios.takt_time_unit` controls each scenario's takt presentation across Overview, the application sidebar, Yamazumi areas and boards, Pin Map, Functional Ergonomics, and other downstream takt displays. The critical thread remains Project → Planning scenario → Yamazumi → Process at a Glance.
- **Scope:** The project preference is project-wide and each scenario preference is scenario-specific. New scenarios inherit the project preference; cloned scenarios copy their source scenario's preference. The preferences remain independent, and Yamazumi work-duration units remain controlled separately by `planning_scenarios.yamazumi_time_unit`.
- **Storage decision:** Add validated `takt_time_unit` fields to `projects` and `planning_scenarios`, accepting only `seconds`, `minutes`, or `hours`. Existing and migrated rows default to `seconds`. Canonical `takt_time_s` and `takt_override_s` values remain seconds and are never rewritten merely because a display preference changes.
- **Applicable standards:** Place an explicit unit selector beside takt inputs, show units wherever takt is displayed, convert to seconds before validation and persistence, preserve the real duration for unit-only changes, record changes through the existing Projects or Planning scenarios audit categories with Current editor attribution, and retain their existing History surfaces. No deletion behavior is introduced.
- **Approval status:** Approved by the project owner on September 15, 2026; implemented.

### Whole-project transfer

- **Proposed by:** Codex
- **Date proposed:** September 15, 2026
- **Purpose:** Transfer a complete project between separate local PAAG installations.
- **Connections:** Every project-wide table and every planning scenario's owned records under one `project_id`.
- **Relationship to the critical thread:** Export the complete project graph as one unit and remap IDs during import using the same approach as scenario cloning, preserving Product Architecture → Parts → Fishbone → Yamazumi → Process at a Glance → Pin Map.
- **Scope:** Project-wide. Every export package includes all planning scenarios belonging to the project.
- **V1 import operations:** Support only **Create new** and **Replace**. **Create new** always generates a new project and freshly remaps every imported ID, so imported records cannot collide with existing local data. **Replace** requires the contributor to explicitly select an existing project to overwrite and then complete the standard non-dismissible confirmation workflow. Merge and conflict-resolution behavior for duplicate projects, records, IDs, or uploaded files is explicitly deferred to a future version and must not be implemented in V1.
- **Replace-target safety:** A non-current project is any project other than the one open in the contributor's active browser session. The currently open project must never be pre-selected as a Replace target. Selecting that project requires an additional explicit step before the standard replacement confirmation so it cannot be overwritten accidentally.
- **Storage decision:** Add one structured project-transfer table that records manifest contents, package version, source and target project identity, per-table record counts, timestamp, Current editor attribution, and any conflicts detected during import. Do not modify any existing business table. Every export and import must also call `record_audit_event()` to write a standard entry to the existing `audit_log`, using a dedicated project-transfer audit category separate from the PITS and Parts import categories. These records are complementary: `audit_log` satisfies the locked Universal Audit Trail Standard, while the structured transfer row supports future transfer-history reporting.
- **Applicable standards:** Retain the **Project-wide** scope badge; show explicit **Creates a new project** or **Replaces an existing project** impact text before import; require the standard non-dismissible confirmation before replacement; record Current editor attribution in both audit records; and expose the dedicated project-transfer audit category in the page's bottom History section.
- **Approval status:** Approved by the project owner on September 15, 2026; V1 export and import are implemented. Export uses the registry-driven `.paagproject` package, bundled owned uploads, and complementary audit records. Import revalidates the package at confirmation, remaps the complete graph and uploads for Create new or confirmed Replace, applies database changes atomically, and records structured and universal audit history. The V1 operation, Replace-target safety, deferred merge, and complementary audit-record clarifications were approved by the project owner on September 15, 2026.

### Scenario-saved Yamazumi time units

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** September 15, 2026
- **Connections:** `planning_scenarios.yamazumi_time_unit` controls presentation for the scenario's existing Yamazumi areas, pitches, and elements; the critical-thread relationship remains Planning scenario → Yamazumi → Process at a Glance.
- **Scope:** Scenario-specific and Yamazumi-only for work durations. Takt presentation is governed independently by the approved takt display-unit preferences.
- **Storage decision:** Add one field to `planning_scenarios`; existing canonical seconds fields cannot represent a durable presentation preference without conflating units and quantities.
- **Applicable standards:** Use the scenario badge and one explicit Save & Refresh action shared with the selected area's takt override and optional legacy/import pairing. Validate and persist the complete settings change atomically with Current editor audit attribution, Yamazumi History, and concise help. The preference has no deletion workflow.
- **Approval status:** Approved by the project owner on September 15, 2026; implemented.

### Guided Yamazumi pitch initialization

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** September 15, 2026
- **Connections:** `projects.yamazumi_line_code` supplies the two-character project-wide default used when creating addresses for scenario-owned `yamazumi_pitches`; linked `yamazumi_areas.section_id` supplies the Fishbone section used for the editable middle-code suggestion. The critical thread remains Project → Fishbone → scenario Yamazumi → Process at a Glance.
- **Scope:** The line code is project-wide so every scenario starts from the same naming default. Generated pitches and their addresses remain scenario-specific through their Yamazumi area.
- **Storage decision:** Add one field to `projects` because a stable suggestion must exist before any pitch address exists and cannot be reliably inferred from an empty project. Fishbone section codes and numeric suffixes remain derived suggestions and are not persisted separately from `yamazumi_pitches.pitch_number`.
- **Applicable standards:** Use native non-dismissible dialog behavior with an explicit Cancel action, store validation, Current editor audit attribution, Yamazumi History, stable session-state keys, and concise help. The setting and generated addresses introduce no deletion workflow.
- **Approval status:** Approved by the project owner on September 15, 2026; implemented. The convention is advisory and never renames or rejects existing nonconforming pitch addresses.

### Automatic Op ID sequencing

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** September 11, 2026
- **Purpose:** Compute a human-readable, traceable **Op ID** for each Process at a Glance Work Element wherever people need to reference that work. The live label is displayed in the main Process at a Glance table and as context in the PFMEA Process Function selector and high-risk view; the separately planned Phase 3 inline pitch-level visual summary may reuse it later. The Op ID is derived at display time and is never persisted, following the existing derived-view approach used by Pin Map and the Process Ergonomics risk tag.
- **Connections:** The calculation connects scenario-specific `work_elements`, `yamazumi_elements`, `yamazumi_pitches`, and `yamazumi_areas` to the project-wide `assembly_sections` Fishbone framework. The stable Process-to-Yamazumi path is `work_elements.id` ← `yamazumi_elements.process_element_id` → `yamazumi_elements.pitch_id` → `yamazumi_pitches.id`. `yamazumi_pitches.pitch_number`, synchronized into the legacy `work_elements.station` field during reconciliation, supplies the human-readable pitch address. `yamazumi_areas.section_id` supplies the optional Fishbone-section relationship. The shared `assembly_section_walk_order(project_id)` function supplies deterministic Fishbone walk order and hierarchy depth.
- **Relationship to the critical thread:** Op ID is a read-only derived label over the existing critical thread: project-wide Fishbone structure → scenario-specific Yamazumi area and pitch → reconciled Yamazumi element → Process at a Glance Work Element. It does not create, replace, approve, or modify any Fishbone, Yamazumi, or Process planning decision.
- **Scope:** Scenario-specific. `work_elements`, `yamazumi_elements`, `yamazumi_pitches`, and `yamazumi_areas` belong to the active planning scenario. Project-wide `assembly_sections` rows are read-only structural input. The calculation must validate the active project and scenario throughout and must never resolve a Process step, Yamazumi element, pitch, or area from another planning scenario.
- **Storage:** No new table, field, cached value, or backfill is introduced. Op IDs are computed fresh whenever displayed. The shared store-layer batch implementation returns display values for multiple `work_elements` rows and supplies the non-persisted physical sort position used by both the PFMEA Process Function picker and Control Plan Pr. Nº suggestions. Complete options use Fishbone traversal first, followed by the separately decoded Pitch-address components (numeric sub-line, case-insensitive work-area letters, numeric work-area suffix, and numeric position), then Yamazumi element/stack order and a stable-ID tie-breaker. This natural comparison keeps values such as `WA2` before `WA10`. Nonconforming Pitch addresses sort after conforming addresses within their Fishbone group and use curated Yamazumi Pitch sequence as a deterministic fallback; incomplete source states sort after complete options. The address text remains unchanged for display. The single-record helper delegates to the same calculation. No consumer stores the Op ID or uses it as a relationship.
- **Format:** A complete Op ID has the form `M{n}S{n}{depth-or-branch-designator}.{pitch address}.{stack position}`, for example `M1S1b.01-ML1-004.4`. A Work Element attached directly to a Main spine section omits the entire `S{n}{...}` portion.
- **Mainline prefix:** Use `assembly_section_walk_order(project_id)` and count only rows whose `assembly_sections.section_type` is `Main spine`, in walk order, starting at `1`. The resulting `M1`, `M2`, and subsequent values are computed positions. They are not derived from the raw `assembly_sections.sequence` value because stored sequence values are spaced and are not guaranteed to be clean or contiguous.
- **Subassembly lineage and depth:** When the linked `yamazumi_areas.section_id` identifies a Subassembly section, walk its `assembly_sections.parent_id` ancestry to its Main spine ancestor. Each top-level Subassembly child feeding directly into that Main spine establishes a lineage numbered `S1`, `S2`, `S3`, and so on in sibling `(sequence, name)` order. The top-level Subassembly receives depth letter `a`; each successively nested non-branching level receives `b`, `c`, and subsequent letters.
- **Branch-point rule:** When one section at a given depth has multiple Subassembly children, those sibling branches use the approved compound designator rather than creating new top-level lineage numbers or receiving an ambiguous shared letter. For example, multiple branches beneath the section carrying `b` are identified as `b1`, `b2`, and so on in `(sequence, name)` order. The same numeric-discriminator rule applies recursively wherever another branch occurs. No new ordering or tie-breaker field is introduced.
- **Pitch address:** Use the current linked `yamazumi_pitches.pitch_number` value as-is. This is the same human-readable address synchronized into and displayed as the Process at a Glance Pitch value. Address text is not used as the stable database relationship.
- **Stack position:** Resolve the scenario's linked `yamazumi_elements` row through `yamazumi_elements.process_element_id`. Within its current `pitch_id`, sort in the authoritative centerline-outward `yamazumi_elements.sequence` order and count positions starting at `1`. Use that clean ordinal position rather than the raw spaced sequence values `10`, `20`, `30`, and so on.
- **Incomplete source states:** A complete Op ID requires one scenario-valid linked Yamazumi element, its current pitch, a Yamazumi area linked through `yamazumi_areas.section_id`, and a Fishbone ancestry that resolves to a Main spine section. If the area has no Fishbone link, display **Fishbone link required** instead of a partial or guessed Op ID. A Process step without a uniquely linked Yamazumi element or current pitch likewise cannot receive a complete Op ID; its display must clearly identify the missing Yamazumi relationship rather than matching `work_elements.station` text heuristically.
- **Feeds-into distinction:** `yamazumi_pitches.feeds_into_pitch_id` represents Yamazumi physical feed routing. `assembly_sections.parent_id` represents Fishbone structural hierarchy. They are separate graphs and are not guaranteed to correspond. Op ID lineage and depth come exclusively from the Fishbone hierarchy; the calculation must not traverse or infer structural lineage from `feeds_into_pitch_id`. The existing feeds-into relationship remains available to future routing consumers but does not determine this Op ID's `M` or `S` designators.
- **Print and export drift:** Because Op IDs are live-derived, they may change after Fishbone reordering or reparenting, Yamazumi-area section reassignment, pitch reassignment, or stack reordering. Any future printed or exported presentation containing Op IDs must include a visible **Generated on [date]** stamp so the document is understood as a point-in-time snapshot. Print and export implementation remains deferred to `PAAG_ROADMAP.md` Phase 7.
- **Future compatibility:** The calculation deliberately derives its result from the existing Fishbone and Yamazumi graph relationships rather than storing a flattened identifier. A separately proposed future Fishbone/Yamazumi flow visualization may reuse the same walk and relationship data as graph nodes and edges. This proposal does not approve, scope, or implement such a visualization.
- **Applicable standards:** Op ID is read-only and introduces no Save & Refresh, Undo, deletion, audit-write, or History behavior of its own. Use the canonical labels **Op ID**, **Pitch**, **Work Element**, **Fishbone section**, and **Yamazumi area** consistently. Wherever Op ID is displayed, provide plain-language help explaining that it identifies the Work Element's current Fishbone lineage, Pitch, and centerline-outward stack position and may change when the Fishbone structure or Yamazumi assignments change.
- **Out of scope:** Persisting or manually editing Op IDs, using raw database UUIDs as human-facing Op IDs, changing persisted Fishbone or Yamazumi ordering, traversing `feeds_into_pitch_id` for Op ID lineage, print/export implementation, and building a Fishbone/Yamazumi flow visualization. The approved Yamazumi board pitch presentation order may use physical feed routing without treating it as Fishbone lineage.
- **Approval status:** **Approved by the project owner and implemented on September 11, 2026.** The Process-table simplification and PFMEA Op ID context amendment was approved the same day: Process keeps Op ID as its first visible column, and PFMEA shows `Op ID — Work Element` while retaining hidden `work_elements.id` as its sole Process relationship. The later approved pitch-level visual summary may expose stored Pitch context without changing the Op ID relationship.

### Yamazumi element persisted stack order

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** September 10, 2026
- **Review status:** **Approved by the project owner on September 10, 2026; implementation has not begun.**
- **Purpose:** Make the position of Yamazumi work elements within a pitch an explicit, deterministic, persisted planning decision and allow contributors to reorder that stack using the existing balancing-board drag gesture.
- **Connections:** This behavior uses the existing scenario-specific `yamazumi_elements` records. `yamazumi_elements.pitch_id` identifies the owning `yamazumi_pitches` stack, while `yamazumi_elements.area_id` retains the Yamazumi-area and planning-scenario boundary. A `NULL` `pitch_id` remains the established Unassigned destination.
- **Storage:** No new database field is required. The existing `yamazumi_elements.sequence INTEGER NOT NULL DEFAULT 10` field becomes the authoritative position within a pitch stack. Adding a separate stack-position field would duplicate order already persisted and consumed by the current board renderer.
- **Centerline-distance rule:** Sequence represents increasing physical distance from the horizontal assembly-flow centerline. The element nearest the centerline receives sequence `10`; elements progressively farther from the centerline receive `20`, `30`, and so on. For a north-side pitch, sequence `10` is physically at the bottom of the stack. For a south-side pitch, sequence `10` is physically at the top of the stack.
- **Existing renderer orientation:** The current renderer already satisfies the centerline-distance rule. It sorts elements by ascending `sequence`, reverses that ordered list for north-side pitches, and leaves it unreversed for south-side pitches. This places the lowest sequence at the centerline-facing edge on both sides. The asymmetric reversal must be retained; no north/south orientation change is required by this proposal.
- **Model variants:** One `yamazumi_elements` row may appear in several model-variant stacks through `model_variants`. Its single saved `sequence` applies consistently wherever that same element appears. This proposal does not introduce independent per-variant copies or ordering records.
- **Spaced numbering and atomic renumbering:** Saved stack position follows the spaced-integer convention used by `assembly_sections.sequence` and `reorder_assembly_section()`. Each complete affected pitch stack is renumbered `10, 20, 30, ...`, beginning at the centerline and proceeding outward. Renumbering occurs only during **Save & Refresh**, as one complete atomic pass over every affected stack. Individual drag events do not calculate or persist intermediate sequence values.
- **Unsaved board draft and Undo:** Dragging an element changes only the browser-session board draft. The board immediately reflects the temporary order and destination, but neither `pitch_id` nor `sequence` is persisted until **Save & Refresh**. **Undo** discards the complete unsaved board draft and restores every affected stack and pitch assignment to its last-saved state in one action. No multi-step undo/redo history is introduced.
- **Shared drag gesture:** The existing drag-and-drop gesture is extended rather than replaced. Dropping an element at another location within its current pitch reorders it within that stack. Dropping it into another pitch stages the established cross-pitch reassignment at the indicated stack location. Drop location determines which outcome applies. Both paths use the same component event and shared destination validation.
- **Destination restrictions:** The always-present **Unassigned** card remains an allowed destination represented by `yamazumi_elements.pitch_id = NULL`. Open and Blocked pitches remain invalid destinations; only Active pitches may accept work. The existing centralized pitch-eligibility rule applies equally to within-pitch reordering and cross-pitch movement.
- **Save validation:** Before writing, validate the complete resulting draft for the affected Yamazumi area, including stable element ownership, valid same-area pitch destinations, Active destination status, and one deterministic sequence for every affected pitch stack. Apply all `pitch_id` and `sequence` changes in one transaction so a failed operation leaves every stack unchanged.
- **Audit and history:** A successful **Save & Refresh** records Current editor attribution through `record_audit_event()`. Audit details identify each affected pitch by stable ID and friendly address/name and record its resulting centerline-outward element order, including stable element IDs and descriptions. Moves to or from Unassigned are included. Display these events in the existing bottom Yamazumi **History** expander.
- **Scope:** Scenario-specific through `yamazumi_elements.area_id` → `yamazumi_areas.scenario_id`. A save must not read, renumber, or modify another planning scenario's elements.
- **Future sequencing dependency:** The saved centerline-outward stack order is the Tier 3 input for the separately proposed automatic human-readable Op ID/sequencing feature, following Tier 1 Fishbone walk order and Tier 2 feeds-into/pitch order. This proposal does not calculate, persist, display, or backfill an Op ID.
- **Out of scope:** Automatic Op ID generation, Fishbone traversal, feeds-into ordering, per-model duplicate element records, and multi-step undo/redo.

### Pin Map

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** August 24, 2026
- **Purpose:** Provide a scenario-specific visual representation of the production line, with linked Process at a Glance work displayed above each Yamazumi workstation or pitch.
- **Connections:** Connects the active `planning_scenarios` record to `yamazumi_areas`, `yamazumi_pitches`, `yamazumi_elements`, and `work_elements`.
- **Relationship to the critical thread:** A pitch is linked through `yamazumi_elements.pitch_id`; explicitly reconciled Process work is linked through the existing soft link from `yamazumi_elements.process_element_id` to `work_elements.id`. Every query also validates the active project and scenario boundaries.
- **Scope:** Scenario-specific. Switching scenarios changes the complete map and its linked work.
- **Storage:** No new table or field is required for the initial read-only view. It derives its layout and content from existing Yamazumi and Process at a Glance records. Any future persisted coordinates, annotations, or Pin Map-only settings require a new owner-reviewed proposal.
- **Applicable standards:** All locked standards in `DESIGN_SYSTEM.md` apply. The initial view includes the scenario boundary badge, explanatory help text, filters, filtered Excel export, and a bottom History section. Save, deletion, row-selection, and audit-write requirements do not activate because this view does not edit or persist data.
- **Approval status:** Nicole Ervin approved implementation of this read-only derived view. Persisted Pin Map data remains pending owner review.

### Functional Reviews

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** August 21, 2026
- **Purpose:** Originally added project-wide navigation shells for Equipment, Ergonomics, Quality, Materials, and Safety functional reviews. Quality, Ergonomics, and Safety later received the separate approved scopes documented in their authoritative schema sections.
- **Potential connections:** Future review records may connect to Parts, Fishbone sections, Yamazumi records, Process at a Glance steps, planning scenarios, or other approved critical-thread entities.
- **Relationship to the critical thread:** Exact relationships and foreign keys are intentionally not defined in this shell phase. The project owner approved navigation-only, non-persistent shells before those relationships are designed. No persisted review fields may be added until each relationship is approved.
- **Scope:** The Functional Reviews navigation group remains shared navigation. Quality, Ergonomics, Safety, and Materials now expose peer Equipment tabs backed by the approved shared Equipment tables above. Quality follows its separately approved scenario-aware scope; Ergonomics and Safety follow their scenario-specific review scopes. The Materials Review content remains a browser-session shell, while its Equipment tab is persistent and scenario-aware.
- **Storage:** The original shell phase added no database storage. Its Review-shell boundary remains true only for Materials review content; Equipment storage and relationships now follow the approved shared Equipment schema above.
- **Applicable standards:** All locked standards in `DESIGN_SYSTEM.md` apply, including table row selection, deletion safety, Save & Refresh, audit logging for persisted changes, History placement, Scenario Boundary badges, help text, canonical terminology, stable identifiers, and imperial units where relevant.
- **Approval status:** Nicole Ervin approved the original shell exception and later approved shared Equipment storage and Functional Review Equipment tabs on September 25, 2026. Type-specific fields beyond Torque remain pending definition.

### Quality requirements

- **Proposed by:** Nicole Ervin, project owner
- **Date proposed:** August 27, 2026
- **Purpose:** Add a reusable Quality requirements repository for dimensional specifications, present-and-fully-seated checks, torque specifications, vision-system validations, and other quality requirements. Allow collaborators to attach repository requirements to specific Process at a Glance steps so the published requirements support process planning, structured PFMEA control selection, and the implemented Control Plan working draft.
- **Connections:** Connects project-wide Quality requirement definitions to scenario-specific `work_elements` records. A Process step may receive one or more requirements, and the same repository definition may be attached to multiple steps, including separate screw operations that share one torque definition. A Torque requirement may also own one project-wide `quality_requirement_torque_details` record. Fishbone section or subassembly context is inherited through the selected Process step rather than stored as a separate direct Quality requirement connection.
- **Relationship to the critical thread:** Each attached requirement links directly to its Process at a Glance step through `work_elements.id`. The repository definition remains reusable project reference data, while every attachment validates the Process step's project and planning-scenario boundaries. A collaborator may explicitly select a published assignment as a Cause-level PFMEA Prevention control, Detection control, or both; nothing is auto-classified. These references do not change upstream Fishbone, Yamazumi, or Process decisions.
- **Scope:** Quality requirement definitions are project-wide and shared across planning scenarios. Attachments are associated with scenario-specific Process steps through `work_elements`, but their published requirement content remains synchronized with the shared project repository. Scenario cloning must preserve the applicable attachments for the cloned Process steps.
- **Storage:** New storage is required because one Process step may have multiple typed Quality requirements and one reusable repository definition may serve multiple Process steps; the existing `work_elements` requirement fields cannot represent that relationship. The design requires a project-wide repository table, the text-backed `quality_requirement_types` controlled catalog, and a Process-step attachment table. Each requirement contains Type, Description, Unique identifier, Pass/fail, Target value, Tolerances, and Unit, in addition to the standard internal identifier, project relationship, and audit timestamps. Torque-only tool information is stored separately in the one-to-one `quality_requirement_torque_details` table instead of adding sparse columns to `quality_requirements`. Tool type and Tool orientation use the approved controlled choices; Screw bit type accepts free-entry text and offers previously saved project values. The implemented Quality-page interaction creates a linked Process requirement record when a collaborator attaches a saved repository requirement and removes that assignment only through the confirmed unlink workflow. Unlink discloses and transactionally removes dependent structured PFMEA selections, flags affected Causes, preserves ratings/Quality definitions, and records both Quality and PFMEA audit evidence. The separate read-only linked-requirements view shows every assignment across the active project while retaining each assignment's scenario ownership. Repository edits, including a confirmed Type-catalog rename cascade, do not update linked Process requirements during an ordinary save; a separate explicit push action publishes the saved repository values to every linked Process step so propagation is deliberate and predictable.
- **Applicable standards:** All locked standards in `DESIGN_SYSTEM.md` apply, including native table row selection, relationship-safe deletion confirmation, direct row entry, **Save & Refresh**, audit logging for every persisted change and synchronization action, bottom History sections, project-wide and scenario-specific boundary indicators where applicable, plain-language help text, canonical terminology, stable identifiers, and imperial storage and display for linear dimensional values. The repository's explicit push action is separate from **Save & Refresh**, must preview or explain all affected linked Process requirements, validate the complete synchronization before writing, apply it atomically, record Current editor attribution and affected rows in history, and never propagate an unsaved repository edit.
- **Approval status:** Nicole Ervin approved the documented schema and data-access implementation on August 27, 2026, and subsequently approved the project-wide editable repository page with deliberate publication to existing linked Process requirements. On August 31, 2026, Nicole Ervin approved creating and removing scenario-specific Process-step assignments and the Torque-only tool-details panel. On September 2, 2026, Nicole approved explicit use of published assignments as structured Cause-level PFMEA controls and the relationship-aware unlink cascade. On September 8, 2026, she approved their use as sources for the scenario-specific MCP working draft. The project-wide linked-requirements view remains read-only.

### Process FMEA

- **Proposed by:** Nicole Ervin, project owner
- **Date approved:** August 31, 2026
- **Purpose:** Add a traditional AIAG-format Process FMEA workflow within the Quality page. The visible editor and its normal filtered export follow the approved 19-column flat line-item body of `FRM-GEA-QYS-033 PFMEA Template.xlsx`; retained Legacy Classification evidence remains stored but hidden from both presentations. Normalized storage continues to permit multiple Potential Effects, Potential Causes, Current Process Controls, and Recommended Actions. A separate read-only high-risk view filters saved lines when either RPN or Resulting RPN exceeds a collaborator-entered positive threshold, displays Item # followed by the current Process Function label plus both RPN values, and sorts by the higher value descending.
- **Connections:** Connects each `pfmea_entries` record to a scenario-specific `work_elements.id`. Item # continues to display the linked step's Pitch (`work_elements.station`). Process Function/Requirements displays the live derived **Op ID** followed by the same Work Element label as Process at a Glance: the linked `yamazumi_elements.description` when present, otherwise `work_elements.operation`. The friendly label is presentation context only; PFMEA persistence, validation, cloning, and source review continue using the hidden `work_elements.id`. Complete picker options follow Fishbone traversal, Yamazumi Pitch order, and centerline-outward element order; incomplete Op IDs remain selectable after complete options. Cause-level Prevention and Detection lists are explicit structured references to applicable published Quality assignments or project-wide manual catalog options; no source is auto-classified.
- **Relationship to the critical thread:** PFMEA enters after scenario-specific Process at a Glance. It does not rewrite Fishbone, Yamazumi, Process, or Quality decisions. Process source fingerprints surface a non-blocking upstream-change flag; only a separate confirmed review action accepts current Process source values. Quality/catalog changes show live labels and mark affected Causes for review without silently changing Detection ratings.
- **Scope:** Scenario-specific. The Quality page is Scenario-aware because the Requirements repository and manual control catalogs are project-wide while PFMEA entries and selections belong to the active scenario. Scenario cloning copies the PFMEA graph with new entry/Cause/selection IDs, remapped Work Element and Quality assignment links, reused project-wide manual options, preserved selection order/review state, and source-entry lineage.
- **Storage:** `pfmea_entries` stores the failure mode, approved short Classification code, optional legacy Classification evidence, Process snapshots, and source fingerprints. The idempotent project migration converts exact `Safety` and `Product Safety` values to `S`; exact `Critical Quality` is retained in `legacy_class_code` while active `class_code` becomes blank for deliberate reclassification. It preserves stable IDs and children and records one editor-attributed atomic audit event. `pfmea_effects` stores Effects/Severity; `pfmea_causes` stores Causes, optional Occurrence/Detection, and source/Detection review flags. `pfmea_prevention_options` and `pfmea_detection_options` store project-wide manual choices. `pfmea_prevention_selections` and `pfmea_detection_selections` store ordered scenario-specific source identities and acknowledged source versions. The project-wide normalized PFMEA pattern catalog stores reusable analysis and ordered Quality-definition/manual-control suggestions without ratings or completion evidence. **Add PFMEA lines** previews and stages a blank graph or pattern for one or more live Process Functions using fresh temporary graph identities; it writes nothing until the existing atomic PFMEA **Save & Refresh**. The flat table appears immediately after its filters and displays controls as read-only friendly multiselect tags. Recalculate RPN, filtered export, and the Classification legend are grouped directly beneath the grid. The completion assistant follows that group, remains advisory, and persists no status. Collaborators edit controls in the visible selected-Cause panel below the assistant and use its session-only Copy Prevention, Copy Detection, Copy both, and Paste actions for validated replacement. Ordinary editable PFMEA cells retain native clipboard behavior. Existing duplication, RPN, high-risk, validation, and hidden-identity behavior remains unchanged.
- **Applicable standards:** All locked standards in `DESIGN_SYSTEM.md` apply, including native selection, direct entry, relationship-safe confirmed deletion, hidden stable IDs, filters, filtered export, Undo, **Save & Refresh**, audit logging with Editor attribution, scenario boundary explanation, canonical terminology, and one bottom History expander with Requirements, PFMEA, and Control Plan history tabs.
- **Approval status:** Nicole Ervin approved this schema and Phase 2 editable PFMEA module on August 31, 2026, the workbook-aligned flat presentation on September 1, 2026, the structured Cause-level Prevention/Detection selection model on September 2, 2026, and the nine-code Classification model and its legacy migration on September 8, 2026. The project-wide guided PFMEA pattern catalog, no-rating policy, deliberate preview/staging workflow, and advisory completion assistant were approved on September 17, 2026. The scenario-specific MCP working draft is separately approved and implemented; PFMEA/Control Plan issued approval workflows and scoring definitions remain deferred.

## Known naming debt — approved for future correction, not yet changed

The following items are genuine naming debt rather than intentional stable-identifier/friendly-display-name pairs or ordinary copy variation. They are approved future corrections, but no schema, stored value, query, page, or export change is being made now.

| Current database name or stored identifier | Display label it should eventually match | Why this is real naming debt |
| --- | --- | --- |
| `work_elements.station` | **Pitch** | Process at a Glance, Yamazumi, and Pin Map use Pitch terminology for the physical work position; `station` remains the legacy persisted name. |
| `work_elements.operation` | **Work Element** | The visible Process workflow and Pin Map treat the work element as the primary concept, while `operation` remains as the legacy persisted name. |
| `parts.description` | **Part Name** | Every active workflow consistently presents this value as Part Name, with no remaining intentional alternative meaning for the catalog field. |
| `pits_records.description` | **Part Name** | Active PITS previews present the source value as Part Name; `description` is retained legacy/source terminology rather than a deliberate friendly-name pairing. Any correction remains subject to the blocked PITS-format migration. |
| `fishbone_nodes.description` | **Part Name** | MBOM-review candidates use the same part-name concept and are displayed as Part Name; the generic stored name is inherited naming debt. Any correction remains subject to the blocked PITS/MBOM-review migration. |
| `audit_log.table_name` stored values | Permanent canonical workflow display labels, including **Process at a Glance** instead of legacy values such as **Process plan** | Historical events contain free-text workflow names and Process currently applies a one-off display replacement. The permanent solution is a documented, shared display-mapping rule, not silent mutation of stored history. |

Any future database rename must update every query, page, validation path, import/export mapping, and workbook reference in one coordinated task. Historical `audit_log` values must never be rewritten. Only their display mapping may be normalized going forward so the original audit evidence remains intact.

## Dormant tables — do not modify without approval

The following tables are implemented in the schema and data layer but are not currently editable from any active application screen. Do not rename, remove, repurpose, extend, or build new UI around them without explicit project-owner approval. The scenario-owned records in this dormant model are copied during scenario cloning; project-wide manufacturing assemblies are reused by the cloned scenario rather than duplicated.

`manufacturing_assemblies` is now an active catalog table documented above. Task 08 implemented its project-wide `make_buy` field as the sole active Make / buy value. Its `pits_reference` and `planning_reason` fields, the legacy scenario-coupled reader/writer, and every supplier/cost/buffer or other scenario-policy behavior remain parked and must not be exposed or modified by the active Assemblies workflow.

### `assembly_scenario_policies`

- **Purpose:** Dormant legacy structure intended to hold scenario-specific supplier, build-area, buffer, storage, and minimum/target/maximum quantity decisions for a manufacturing assembly. Its existing `sourcing_decision` column is retained untouched but is non-authoritative; Task 08 assigns sole active Make / buy authority to `manufacturing_assemblies.make_buy`.
- **Relationships and cloning:** Junction between `planning_scenarios` and `manufacturing_assemblies`; policy rows are copied when a planning scenario is cloned.
- **Current status — NOT YET DESIGNED:** No active screen reads or edits this table. Task 08 does not read, write, synchronize, migrate, or expose `sourcing_decision`. Future supplier, cost, buffer/storage, and other scenario-policy behavior is not finalized. Any future proposal must explicitly reconcile the legacy dormant sourcing field without treating it as authoritative. Do not build UI, features, or duplicate logic against this table without a scoping discussion and explicit project-owner approval.

### `work_element_material_groups`

- **Purpose:** Intended to define a material requirement directly on a Yamazumi work element, optionally identifying a target manufacturing assembly and a part-selection rule.
- **Relationships and cloning:** Belongs to `projects` and `planning_scenarios`, references `yamazumi_elements`, optionally references `manufacturing_assemblies`, and is parent of `work_element_material_options`. Rows are copied when a planning scenario is cloned.
- **Current status — LOCKED:** No active screen edits this table. The active Process at a Glance workflow instead uses `process_part_groups`. This table is frozen with no active plan to revisit it; do not modify, extend, or build new features against it. Continue carrying its rows forward during scenario cloning.

### `work_element_material_options`

- **Purpose:** Intended to list either catalog parts or manufacturing assemblies as options under a Yamazumi-level material group.
- **Relationships and cloning:** Belongs to `work_element_material_groups` and must reference exactly one of `parts` or `manufacturing_assemblies`. Rows are copied with their parent material groups when a planning scenario is cloned.
- **Current status — LOCKED:** No active screen edits this table. The active Process at a Glance workflow instead uses `process_part_options`. This table is frozen with no active plan to revisit it; do not modify, extend, or build new features against it. Continue carrying its rows forward during scenario cloning.

## Hidden review stage

`pits_records`, `pits_record_revisions`, and `fishbone_nodes` support a Manufacturing BOM confirmation stage between imported Product Architecture evidence and the approved Parts Catalog. New or changed PITS records preserve their source revisions and create or flag `fishbone_nodes` review candidates. Confirmed candidates can then be synchronized into `parts` without allowing an upstream import to silently overwrite collaborator-reviewed planning decisions.

The database and data-access functions for this review stage exist, but none of the active navigation screens currently exposes the complete review and confirmation workflow.

**Current status — BLOCKED / TBD:** This stage is intentionally on hold until the PITS spreadsheet import is migrated to a better format. Do not build an MBOM review screen or duplicate, bypass, replace, or extend this logic until that migration is complete and the project owner confirms the workflow is ready to revisit.

The approved PITS BOM-tab occurrence workflow is a narrowly scoped exception and an independent working alternative for source parent-child structure. It uses `pits_bom_imports`, `pits_bom_occurrences`, `pits_bom_occurrence_revisions`, and `pits_bom_occurrence_concerns`; it does not read, write, synchronize, expose, replace, or extend `fishbone_nodes`. Reconciliation between the two review models remains blocked pending a separate owner decision.

## Critical thread — do not break

```text
PITS / BOM evidence
    ├── PITS records + source revision history
    ├── Model definitions
    └── MBOM-review candidates (fishbone_nodes)
                    ↓ Collaborator confirmation/synchronization
Parts Catalog ── feature applicability ── model/feature architecture
      ↓
Fishbone sections + placed part occurrences
      ├── explicit project-wide assembly mini-BOMs + assembly applicability
      ↓ section link
Scenario-specific Yamazumi areas → pitches → work elements
      ↓ explicit reconciliation
Scenario-specific Process at a Glance steps
      ├── scenario-specific Safety requirements (derived Safety tag)
      ├── scenario-specific PFMEA classifications (derived CTQ tag)
      ↓
Process part groups → paired catalog parts from a fishbone section
      ↓
Scenario-specific Pin Map (derived visual view)
      ↓
Quality requirements repository -> scenario-specific assignments linked to Process steps
      ↓
Scenario-specific Process FMEA
      ↓
Scenario-specific Manufacturing Control Plan working draft
      ↓
Future issued-document generation and approval (not implemented)
```
