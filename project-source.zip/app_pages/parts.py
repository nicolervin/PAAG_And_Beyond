import hashlib
import json
from pathlib import Path
from uuid import uuid4

import pandas as pd
import streamlit as st

from utils.clipboard_image import as_uploaded_file, clipboard_image, decode_clipboard_image
from utils.store import (
    PART_MAKE_BUY_VALUES,
    PART_SOURCE_CODES,
    add_part_image,
    assembly_bom_components,
    pits_assembly_mini_bom,
    audit_history,
    complexity_features,
    delete_project_part,
    part_delete_impact,
    get_planning_scenario,
    part_feature_rules,
    part_images,
    part_scenario_activity,
    project_models,
    project_table,
    record_audit_event,
    set_part_image,
    update_part_feature_rules,
    update_part_rows,
)
from utils.scope_ui import page_title_with_scope
from utils.table_filters import (
    apply_pending_table_editor_reset,
    filter_table,
    merge_filtered_edits,
    request_table_editor_reset,
)
from utils.table_ui import (
    dataframe_to_excel,
    drop_untouched_new_rows,
    editable_table_footer,
    editable_table_heading,
    native_selected_rows,
    required_field_errors,
    selectable_dataframe,
    selected_rows_action_bar,
    stage_native_delete_confirmation,
    standard_details_column_config,
    direct_entry_editor_rows,
    table_has_unsaved_changes,
)


@st.cache_data(show_spinner=False)
def _cached_parts_dataframe_to_excel(
    data_hash: str,
    _dataframe: pd.DataFrame,
    sheet_name: str = "Parts",
) -> bytes:
    del data_hash
    return dataframe_to_excel(_dataframe, sheet_name)


def _hash_filtered_export(dataframe: pd.DataFrame) -> str:
    serialized = dataframe.to_json(orient="split", date_format="iso").encode("utf-8")
    return hashlib.sha256(serialized).hexdigest()


project_id = st.session_state.get("project_id")
scenario_id = st.session_state.get("scenario_id")
parts_editor_key = f"parts_catalog_editor_v7_{scenario_id}"
parts_draft_key = f"parts_catalog_draft_{project_id}_{scenario_id}"
page_title_with_scope(
    "Parts Catalog",
    scope="scenario-aware",
    help_text=(
        "The Parts Catalog itself is shared across every scenario. Whether a part is marked "
        "Active applies only to the currently selected scenario."
    ),
)
st.caption(
    "Connect official part numbers to CAD screenshots, revisions, model applicability, and the "
    "parts active in this planning scenario."
)
if not project_id or not scenario_id:
    st.stop()
scenario = get_planning_scenario(project_id, scenario_id)
if not scenario:
    st.error("The active planning scenario no longer exists.")
    st.stop()
st.caption(f"Active scenario: Rev {scenario['revision_label']} · {scenario['name']}")
parts_editor_key = apply_pending_table_editor_reset(parts_editor_key)

parts = project_table("parts", project_id, "part_number")
models = project_models(project_id)
features = complexity_features(project_id)
active_features = features.loc[features["active"].fillna(1).astype(bool)].copy() if not features.empty else features
rules = part_feature_rules(project_id)
activity_by_part = part_scenario_activity(project_id, scenario_id)
if models.empty:
    active_model_numbers = []
    model_labels = {}
else:
    active_models = models.loc[models["active"].fillna(1).astype(bool)].copy()
    active_model_numbers = active_models["model_number"].fillna("").astype(str).tolist()
    model_labels = {
        str(row["model_number"]): (
            str(row["display_name"]).strip() or "Common name not defined"
        )
        for _, row in models.iterrows()
    }


def split_model_applicability(value) -> list[str]:
    text = "" if value is None else str(value).strip()
    if not text or text.lower() == "all":
        return ["All models"]
    if text in model_labels:
        return [text]

    # Official model identifiers can contain commas. Parse against the complete
    # set of defined identifiers before falling back to legacy comma splitting.
    candidates = sorted(model_labels, key=len, reverse=True)

    def parse_remaining(remaining: str) -> list[str] | None:
        for model_number in candidates:
            if remaining == model_number:
                return [model_number]
            prefix = f"{model_number}, "
            if remaining.startswith(prefix):
                parsed_tail = parse_remaining(remaining[len(prefix):])
                if parsed_tail is not None:
                    return [model_number, *parsed_tail]
        return None

    parsed = parse_remaining(text)
    return parsed if parsed is not None else [text]


feature_option_labels: dict[str, str] = {"All models": "All models"}
for _, feature in active_features.iterrows():
    for choice in json.loads(feature["allowed_values"] or "[]"):
        token = f"{feature['id']}::{choice}"
        feature_option_labels[token] = f"{feature['category']} · {feature['name']} = {choice}"
feature_token_by_label = {label: token for token, label in feature_option_labels.items()}
feature_options = list(feature_token_by_label)
rules_by_part: dict[str, list[str]] = {}
if not rules.empty:
    for part_id, part_rules in rules.groupby("part_id", sort=False):
        rules_by_part[str(part_id)] = [
            feature_option_labels.get(
                f"{row['feature_id']}::{row['value']}",
                f"{row['category']} · {row['feature_name']} = {row['value']}",
            )
            for _, row in part_rules.iterrows()
        ]


def readable_feature_applicability(part_id: str, legacy_value) -> str:
    selected = rules_by_part.get(str(part_id), [])
    if selected:
        return "; ".join(selected)
    if str(legacy_value or "").strip().casefold() in {"all", "all models"}:
        return "All models"
    return "Needs feature tagging"


editable_table_heading("All parts")
st.caption(
    "Edit catalog fields directly, then save. Select View details on a row to open its "
    "photos, full information, and completed-subassembly mini-BOM below."
)
editable_columns = [
    "id", "part_number", "description", "subsystem", "design_maturity",
    "factory_nickname", "official_windchill_part_name",
    "design_engineer", "technology_engineer", "ppm", "buyer_gcl", "pmqe_aqe",
    "ame_tooling_engineer", "part_code", "pits_tracker_number", "source_code", "make_buy",
    "quantity", "revision", "model_applicability", "notes", "source", "image_path",
    "updated_at", "assembly_id", "assembly_number",
]
parts_for_editing = parts.reindex(columns=editable_columns).copy()
parts_for_editing["subsystem"] = parts_for_editing["subsystem"].fillna("").astype("string")
parts_for_editing["design_maturity"] = parts_for_editing["design_maturity"].fillna(
    parts_for_editing["revision"]
).fillna("").astype("string")
parts_for_editing["factory_nickname"] = parts_for_editing["factory_nickname"].fillna(
    parts_for_editing["official_windchill_part_name"]
).fillna("").astype("string")
parts_for_editing["design_engineer"] = parts_for_editing["design_engineer"].fillna(
    parts_for_editing["technology_engineer"]
).fillna("").astype("string")
for col in ("ppm", "buyer_gcl", "pmqe_aqe", "ame_tooling_engineer", "part_code"):
    parts_for_editing[col] = parts_for_editing[col].fillna("").astype("string")
linked_assembly_by_part = {
    str(row["id"]): str(row.get("assembly_number") or "")
    for _, row in parts_for_editing.iterrows()
    if str(row.get("assembly_id") or "").strip()
}


def assembly_grid_applicability_status(part_id: str, value) -> str:
    if part_id not in linked_assembly_by_part:
        return readable_feature_applicability(part_id, value)
    model_numbers = split_model_applicability(value) if str(value or "").strip() else []
    return (
        f"Assembly grid · {', '.join(model_numbers)}"
        if model_numbers else "Assembly grid · No active mapped models"
    )
parts_for_editing["active"] = parts_for_editing["id"].apply(
    lambda part_id: activity_by_part.get(str(part_id), True)
).astype(bool)
parts_for_editing["feature_applicability"] = parts_for_editing.apply(
    lambda row: (
        rules_by_part.get(str(row["id"]), [])
        or (["All models"] if str(row["model_applicability"] or "").strip().casefold() in {"all", "all models"} else [])
    ),
    axis=1,
)
parts_for_editing["applicability_status"] = parts_for_editing.apply(
    lambda row: assembly_grid_applicability_status(
        str(row["id"]), row["model_applicability"]
    ),
    axis=1,
)
parts_for_editing["source_code"] = parts_for_editing["source_code"].apply(
    lambda value: ""
    if value is None or pd.isna(value)
    else str(int(value))
    if isinstance(value, float) and value.is_integer()
    else str(value).strip()
).astype("string")
parts_for_editing["view_details"] = ":material/visibility: View details"
parts_for_editing["photo_status"] = parts_for_editing["image_path"].apply(
    lambda value: "✅ Added" if str(value or "").strip() else "❌ Missing"
)
updated_values = pd.to_datetime(parts_for_editing["updated_at"], errors="coerce", utc=True)
parts_for_editing["updated_display"] = updated_values.dt.strftime(
    "%b %d, %Y %H:%M"
).fillna("")


def merge_parts_editor_draft(source: pd.DataFrame) -> pd.DataFrame:
    """Overlay the prior visible editor draft onto the full Parts Catalog view."""
    state = st.session_state.get(parts_editor_key, {}) or {}
    previous_visible = pd.DataFrame(
        st.session_state.get(f"{parts_draft_key}_visible", [])
    )
    if previous_visible.empty or "id" not in previous_visible.columns:
        return source
    draft = previous_visible.copy()
    for raw_position, changes in (state.get("edited_rows") or {}).items():
        position = int(raw_position)
        if 0 <= position < len(draft):
            for column, value in (changes or {}).items():
                if column in draft.columns:
                    draft.at[draft.index[position], column] = value
    if not state.get("edited_rows"):
        return source
    source_by_id = source.copy()
    draft_by_id = draft.set_index(draft["id"].astype(str))
    for row_index, row in source_by_id.iterrows():
        part_id = str(row.get("id") or "")
        if part_id in draft_by_id.index:
            for column in source_by_id.columns:
                if column in draft_by_id.columns:
                    source_by_id.at[row_index, column] = draft_by_id.at[part_id, column]
    return source_by_id


parts_for_editing = merge_parts_editor_draft(parts_for_editing)
parts_full_for_editing = parts_for_editing.copy()
with st.expander("Filter columns", icon=":material/filter_list:", expanded=True):
    parts_for_editing = filter_table(
        parts_for_editing,
        key="part_catalog_filters",
        dropdown_columns=[
            "active", "source", "design_maturity", "subsystem", "source_code", "make_buy",
            "factory_nickname", "design_engineer", "ppm", "buyer_gcl",
            "pmqe_aqe", "ame_tooling_engineer", "part_code", "photo_status", "applicability_status",
        ],
        search_columns=[
            "part_number", "description", "subsystem", "design_maturity", "factory_nickname",
            "design_engineer", "ppm", "buyer_gcl", "pmqe_aqe",
            "ame_tooling_engineer", "part_code", "pits_tracker_number",
            "source_code", "make_buy", "photo_status", "applicability_status",
            "notes", "source",
        ],
        labels={
            "active": "Active in scenario",
            "photo_status": "Photo status",
            "part_number": "Part number",
            "description": "Part Name",
            "subsystem": "Subsystem",
            "design_maturity": "Design Maturity",
            "factory_nickname": "Factory Nickname",
            "design_engineer": "Design Engineer",
            "ppm": "PPM",
            "buyer_gcl": "Buyer / GCL",
            "pmqe_aqe": "PMQE / AQE",
            "ame_tooling_engineer": "AME / Tooling Engineer",
            "part_code": "Part Code",
            "source_code": "Source Code",
            "make_buy": "Make vs Buy",
            "technology_engineer": "Technology Engineer",
            "pits_tracker_number": "PITS ID",
            "applicability_status": "Feature applicability",
        },
        reset_widget_keys=[parts_editor_key],
        multi_value_columns=["feature_applicability"],
    )
    clear_filter_actions = st.container(horizontal=True, horizontal_alignment="right")
    if clear_filter_actions.button(
        "Clear filters",
        icon=":material/filter_alt_off:",
        key="clear_part_catalog_filters",
    ):
        st.session_state.pop("part_catalog_filters_keyword", None)
        for filter_column in [
            "active", "photo_status", "part_number", "description", "subsystem", "design_maturity", "revision",
            "factory_nickname", "design_engineer", "ppm", "buyer_gcl",
            "pmqe_aqe", "ame_tooling_engineer", "part_code", "source_code",
            "make_buy", "pits_tracker_number", "feature_applicability", "notes", "source", "updated_at",
        ]:
            st.session_state.pop(f"part_catalog_filters_{filter_column}", None)
        st.rerun()
selected_part_key = f"parts_selected_id_{project_id}"


def open_part_details() -> None:
    click = st.session_state.get("parts_view_details")
    if click and 0 <= click["row"] < len(parts_for_editing):
        st.session_state[selected_part_key] = str(parts_editor_rows.iloc[click["row"]]["id"])


parts_editor_rows = direct_entry_editor_rows(
    parts_for_editing,
    editor_key=parts_editor_key,
    sort_columns=[
        "active", "photo_status", "part_number", "description",
        "subsystem", "design_maturity",
        "factory_nickname", "design_engineer", "ppm", "buyer_gcl",
        "pmqe_aqe", "ame_tooling_engineer", "part_code", "pits_tracker_number",
        "source_code", "make_buy", "feature_applicability",
        "applicability_status", "notes", "source", "updated_at",
    ],
    labels={
        "photo_status": "Photo status", "part_number": "Part number",
        "description": "Part name", "subsystem": "Subsystem", "design_maturity": "Design Maturity",
        "factory_nickname": "Factory Nickname",
        "design_engineer": "Design Engineer", "ppm": "PPM",
        "buyer_gcl": "Buyer / GCL", "pmqe_aqe": "PMQE / AQE",
        "ame_tooling_engineer": "AME / Tooling Engineer", "part_code": "Part Code",
        "feature_applicability": "Feature applicability",
        "applicability_status": "Applicability status", "updated_at": "Updated",
    },
)
parts_action_slot = st.empty()
edited_parts = st.data_editor(
    parts_editor_rows,
    key=parts_editor_key,
    hide_index=True,
    num_rows="dynamic",
    height=430,
    disabled=["id", "subsystem", "part_code", "model_applicability", "photo_status", "applicability_status", "source", "image_path", "updated_at", "updated_display", "assembly_id", "assembly_number"],
    column_order=[
        "view_details", "active", "photo_status", "part_number", "description",
        "subsystem", "design_maturity",
        "factory_nickname", "design_engineer", "ppm", "buyer_gcl",
        "pmqe_aqe", "ame_tooling_engineer", "part_code", "pits_tracker_number",
        "source_code", "make_buy", "feature_applicability",
        "applicability_status", "notes", "source", "updated_display",
    ],
    column_config={
        "id": None,
        "official_windchill_part_name": None,
        "technology_engineer": None,
        "assembly_id": None,
        "assembly_number": None,
        "view_details": standard_details_column_config(on_click=open_part_details, key="parts_view_details"),
        "active": st.column_config.CheckboxColumn(
            "Active",
            default=True,
            help=(
                "Turn off to keep this catalog record but hide it from downstream views in "
                "the active planning scenario."
            ),
        ),
        "photo_status": st.column_config.TextColumn(
            "Photo status",
            default="",
            help="A green check means a primary CAD image is attached; a red X means it is missing.",
        ),
        "part_number": st.column_config.TextColumn("Part number", required=True),
        "description": st.column_config.TextColumn("Part Name", width="large"),
        "subsystem": st.column_config.TextColumn(
            "Subsystem",
            width="medium",
            help="Read-only subsystem identifier from column F of the imported PITS Tracker row matched by PITS ID.",
        ),
        "design_maturity": st.column_config.TextColumn(
            "Design Maturity",
            default="",
            help="Design maturity / revision from PITS Tracker column G.",
        ),
        "factory_nickname": st.column_config.TextColumn(
            "Factory Nickname",
            width="large",
            help="The factory nickname or official Windchill name recorded from PITS.",
        ),
        "design_engineer": st.column_config.TextColumn(
            "Design Engineer",
            help="Design Engineer / Technology Engineer from PITS Tracker column I.",
        ),
        "ppm": st.column_config.TextColumn(
            "PPM",
            help="Part Project Manager from PITS Tracker column J.",
        ),
        "buyer_gcl": st.column_config.TextColumn(
            "Buyer / GCL",
            help="Buyer / Global Commodity Leader from PITS Tracker column K.",
        ),
        "pmqe_aqe": st.column_config.TextColumn(
            "PMQE / AQE",
            help="Plant Manufacturing Quality Engineer / Advanced Quality Engineer from PITS Tracker column L.",
        ),
        "ame_tooling_engineer": st.column_config.TextColumn(
            "AME / Tooling Engineer",
            help="Advanced Manufacturing Engineer / Tooling Engineer from PITS Tracker column M.",
        ),
        "part_code": st.column_config.TextColumn(
            "Part Code",
            help=(
                "Part Code from PITS Tracker column N.\n\n"
                "- NP = New Part, New Tool\n"
                "- NPNT = New Part, No Tooling\n"
                "- ASM = Assembly\n"
                "- CP = Current Production\n"
                "- CP Other = CP different site"
            ),
        ),
        "pits_tracker_number": st.column_config.TextColumn(
            "PITS ID",
            help="ID Number imported from column B of the PITS Tracker. It must be unique within the current project, and leading zeros are preserved.",
        ),
        "source_code": st.column_config.SelectboxColumn(
            "Source Code",
            options=["", *PART_SOURCE_CODES],
            default="",
            help=(
                "PITS source code from tracker column T.\n\n"
                "- 1 - Purchased Part\n"
                "- +1 - Purchased Asm\n"
                "- 2.4 - From AP3\n"
                "- 3 - Mfg Part\n"
                "- 5 - Asm (Disassembly no)\n"
                "- 6 - Asm (Disassembly yes)\n"
                "- 8 - Component of Purchased Asm"
            ),
        ),
        "make_buy": st.column_config.SelectboxColumn(
            "Make vs Buy", options=["", *PART_MAKE_BUY_VALUES], default=""
        ),
        "quantity": None,
        "revision": None,
        "model_applicability": None,
        "image_path": None,
        "feature_applicability": st.column_config.MultiselectColumn(
            "Feature applicability",
            options=feature_options,
            help="Choose All models alone, or feature choices. Within-feature choices are OR; across-feature choices are AND.",
            width="large",
            default=["All models"],
        ),
        "applicability_status": None,
        "notes": st.column_config.TextColumn("Notes", width="large"),
        "source": st.column_config.TextColumn("Source", default=""),
        "updated_at": None,
        "updated_display": st.column_config.TextColumn("Updated", default=""),
    },
)
st.session_state[parts_draft_key + "_visible"] = parts_editor_rows.to_dict("records")
parts_actions = editable_table_footer(
    editor_key=parts_editor_key,
    key_prefix="parts_catalog",
    native_row_selection=True,
)
save_part_table = parts_actions.save_and_refresh
if parts_actions.undo:
    st.session_state.pop(parts_draft_key + "_visible", None)
    request_table_editor_reset(parts_editor_key)
    st.toast("Discarded the unsaved Parts Catalog edits", icon=":material/undo:")
    st.rerun()
st.caption(
    "Type or paste new parts directly into the blank entry row, then save. Use View details to manage its Primary CAD image "
    "and additional views."
)

export_columns = [
    "active", "part_number", "description", "subsystem", "design_maturity", "factory_nickname",
    "design_engineer", "ppm", "buyer_gcl", "pmqe_aqe",
    "ame_tooling_engineer", "part_code", "pits_tracker_number",
    "source_code", "make_buy", "feature_applicability",
    "photo_status", "notes", "source", "updated_at",
]
export_dataframe = parts_for_editing.reindex(columns=export_columns)
export_hash = _hash_filtered_export(export_dataframe)
st.download_button(
    "Export filtered rows",
    data=_cached_parts_dataframe_to_excel(export_hash, export_dataframe, "Parts"),
    file_name="parts_filtered.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    icon=":material/download:",
)

selected_saved_parts = native_selected_rows(parts_editor_rows, editor_key=parts_editor_key)
bulk_controls = selected_rows_action_bar(
    parent=parts_action_slot,
)
bulk_applicability = bulk_controls.multiselect(
    "Feature applicability for selected parts",
    options=feature_options,
    placeholder="Choose All models or feature values",
    key="parts_bulk_feature_applicability",
)
apply_bulk_applicability = bulk_controls.button(
    f"Apply to selected ({len(selected_saved_parts)})",
    type="primary",
    icon=":material/checklist:",
    disabled=selected_saved_parts.empty,
)
request_delete_bulk_parts = not selected_saved_parts.empty

if apply_bulk_applicability:
    if table_has_unsaved_changes(parts_editor_key, native_row_selection=True):
        st.warning("Save or undo other table edits before applying a bulk feature change.")
    elif not bulk_applicability:
        st.warning("Choose All models or at least one feature value.")
    elif "All models" in bulk_applicability and len(bulk_applicability) > 1:
        st.warning("Choose All models by itself, or choose feature values.")
    else:
        try:
            update_part_feature_rules(
                project_id,
                {
                    str(part_id): [feature_token_by_label[label] for label in bulk_applicability]
                    for part_id in selected_saved_parts["id"]
                },
            )
            record_audit_event(
                project_id, "Parts", "Bulk feature edit", len(selected_saved_parts),
                st.session_state.get("current_editor", ""),
                {"feature_applicability": bulk_applicability},
            )
            request_table_editor_reset(parts_editor_key)
            st.toast(f"Updated feature applicability for {len(selected_saved_parts)} parts", icon=":material/check_circle:")
            st.rerun()
        except ValueError as exc:
            st.error(str(exc))

if request_delete_bulk_parts:
    if table_has_unsaved_changes(parts_editor_key, native_row_selection=True):
        st.warning("Save or undo other table edits before deleting selected parts.")
    else:
        st.session_state.parts_pending_bulk_delete = selected_saved_parts["id"].astype(str).tolist()
        stage_native_delete_confirmation(parts_editor_key)


@st.dialog("Delete selected parts?", dismissible=False)
def confirm_bulk_part_delete() -> None:
    pending_ids = st.session_state.get("parts_pending_bulk_delete", [])
    try:
        impact = part_delete_impact(project_id, pending_ids)
    except ValueError as exc:
        st.error(str(exc))
        return
    st.warning(
        f"This will permanently delete {len(pending_ids)} part(s), their photos, and their fishbone uses."
    )
    if impact["linked_assemblies"]:
        st.error(
            "These Parts Catalog rows represent current manufacturing assemblies and cannot "
            "be deleted here:"
        )
        for linked in impact["linked_assemblies"]:
            st.write(
                f"- Part number **{linked['assembly_number']}** is linked to assembly "
                f"**{linked['assembly_number']}** ({linked['assembly_name']})."
            )
        st.caption("Delete or merge the linked assembly first, then retry the Parts deletion.")
    actions = st.container(horizontal=True)
    if actions.button("Cancel", key="cancel_bulk_part_delete"):
        st.session_state.pop("parts_pending_bulk_delete", None)
        request_table_editor_reset(parts_editor_key)
        st.rerun()
    if actions.button(
        "Delete parts",
        type="primary",
        icon=":material/delete:",
        key="destructive_confirm_bulk_part_delete",
        disabled=bool(impact["linked_assemblies"]),
    ):
        deleted_labels = [
            delete_project_part(project_id, str(part_id))
            for part_id in pending_ids
        ]
        deleted_ids = set(pending_ids)
        if st.session_state.get(selected_part_key) in deleted_ids:
            st.session_state.pop(selected_part_key, None)
        record_audit_event(
            project_id, "Parts", "Bulk delete", len(deleted_labels),
            st.session_state.get("current_editor", ""), {"part_numbers": deleted_labels},
        )
        st.session_state.pop("parts_pending_bulk_delete", None)
        request_table_editor_reset(parts_editor_key)
        st.toast(f"Deleted {len(deleted_labels)} selected parts and their fishbone uses", icon=":material/delete:")
        st.rerun()


if st.session_state.get("parts_pending_bulk_delete"):
    confirm_bulk_part_delete()

if save_part_table:
    try:
        if not selected_saved_parts.empty:
            raise ValueError("Clear the selected rows before saving table edits. Selection is reserved for bulk actions.")
        edited_parts = drop_untouched_new_rows(
            edited_parts, identifying_columns=["part_number"]
        )
        edited_parts = merge_filtered_edits(
            parts_full_for_editing,
            parts_for_editing,
            edited_parts,
        )
        validation_errors = required_field_errors(edited_parts, {"part_number": "Part number"})
        if validation_errors:
            raise ValueError(" ".join(validation_errors))
        invalid_all = edited_parts["feature_applicability"].apply(
            lambda selected: "All models" in (selected or []) and len(selected or []) > 1
        )
        if invalid_all.any():
            raise ValueError("Choose All models by itself, or choose feature values.")
        missing_rule = edited_parts.apply(
            lambda row: (
                str(row.get("id") or "") not in linked_assembly_by_part
                and not (row.get("feature_applicability") or [])
            ),
            axis=1,
        )
        if missing_rule.any():
            raise ValueError("Every part needs All models or at least one feature choice.")
        parts_to_save = edited_parts.drop(
            columns=["view_details", "active", "photo_status", "feature_applicability", "applicability_status", "updated_display", "assembly_id", "assembly_number"]
        ).copy()
        new_row_mask = parts_to_save["id"].isna() | parts_to_save["id"].astype(str).str.strip().eq("")
        parts_to_save.loc[new_row_mask, "id"] = [str(uuid4()) for _ in range(int(new_row_mask.sum()))]
        edited_parts = edited_parts.copy()
        edited_parts.loc[new_row_mask, "id"] = parts_to_save.loc[new_row_mask, "id"]
        parts_to_save.loc[new_row_mask, "quantity"] = 1
        parts_to_save.loc[new_row_mask, "model_applicability"] = "All"
        parts_to_save.loc[new_row_mask, "source"] = "Manual"
        parts_to_save["revision"] = parts_to_save["design_maturity"]
        parts_to_save["technology_engineer"] = parts_to_save["design_engineer"]
        parts_to_save["official_windchill_part_name"] = parts_to_save["factory_nickname"]
        tracked_fields = {
            "subsystem": "Subsystem",
            "design_maturity": "Design Maturity",
            "factory_nickname": "Factory Nickname",
            "design_engineer": "Design Engineer",
            "ppm": "PPM",
            "buyer_gcl": "Buyer / GCL",
            "pmqe_aqe": "PMQE / AQE",
            "ame_tooling_engineer": "AME / Tooling Engineer",
            "part_code": "Part Code",
            "pits_tracker_number": "PITS ID",
            "source_code": "Source Code",
            "make_buy": "Make vs Buy",
        }
        saved_parts_by_id = (
            parts.set_index(parts["id"].astype(str)).to_dict("index")
            if not parts.empty else {}
        )
        field_changes = []
        for _, row in parts_to_save.iterrows():
            part_id = str(row["id"])
            previous = saved_parts_by_id.get(part_id)
            changed_fields = {}
            for field, label in tracked_fields.items():
                new_value = "" if pd.isna(row.get(field)) else str(row.get(field)).strip()
                old_value = "" if previous is None else str(previous.get(field) or "").strip()
                if previous is None or new_value != old_value:
                    changed_fields[label] = {
                        "old_value": None if previous is None else old_value,
                        "new_value": new_value,
                    }
            if changed_fields:
                field_changes.append(
                    {
                        "part_id": part_id,
                        "part_number": str(row["part_number"]).strip(),
                        "fields": changed_fields,
                    }
                )
        count = update_part_rows(
            project_id,
            parts_to_save,
            scenario_id=scenario_id,
            activity_by_part={
                str(row["id"]): (
                    True
                    if row.get("active") is None or pd.isna(row.get("active"))
                    else bool(row.get("active"))
                )
                for _, row in edited_parts.iterrows()
            },
        )
        update_part_feature_rules(
            project_id,
            {
                str(row["id"]): [
                    feature_token_by_label[label]
                    for label in (row["feature_applicability"] or [])
                    if label in feature_token_by_label
                ]
                for _, row in edited_parts.iterrows()
            },
        )
        record_audit_event(
            project_id,
            "Parts",
            "Save & Refresh",
            count,
            st.session_state.get("current_editor", ""),
            {"scenario_id": scenario_id, "catalog_field_changes": field_changes},
        )
        st.session_state.pop(parts_draft_key + "_visible", None)
        request_table_editor_reset(parts_editor_key)
        st.toast(f"Saved {count} parts", icon=":material/check_circle:")
        st.rerun()
    except ValueError as exc:
        st.error(str(exc))

def render_parts_history() -> None:
    """Render Parts history at the bottom of the current page state."""
    with st.expander("Parts history", icon=":material/history:"):
        history = audit_history(project_id, "Parts", limit=50)
        if history.empty:
            st.caption("No standardized Parts Catalog changes have been recorded yet.")
        else:
            selectable_dataframe(
                history.drop(columns=["details"], errors="ignore"),
                key=f"parts_history_table_{project_id}",
                hide_index=True,
                column_config={
                    "action": "Action",
                    "row_count": "Rows",
                    "editor_name": "Editor",
                    "created_at": st.column_config.DatetimeColumn(
                        "When", format="MMM DD, YYYY HH:mm"
                    ),
                },
            )

if parts.empty:
    st.info("Type or paste the first part into the blank entry row, then select Save & Refresh.")
    render_parts_history()
    st.stop()

valid_part_ids = set(parts["id"].astype(str))
if st.session_state.get(selected_part_key) not in valid_part_ids:
    st.session_state[selected_part_key] = str(parts.iloc[0]["id"])
part = parts.loc[parts["id"].astype(str) == st.session_state[selected_part_key]].iloc[0].to_dict()
part_name = str(part.get("description") or "").strip()
part_details_title = f"Part Details · {part['part_number']}"
if part_name:
    part_details_title += f" {part_name}"
st.subheader(part_details_title)
image_col, details_col = st.columns([2, 3])
with image_col.container(border=True):
    st.subheader("Primary CAD image")
    image_path = Path(part["image_path"]) if part.get("image_path") else None
    if image_path and image_path.exists():
        st.image(str(image_path), caption=part["part_number"])
    else:
        st.caption("No image attached.")
    uploaded = st.file_uploader("Attach screenshot or rendered view", type=["png", "jpg", "jpeg", "webp"], key=f"image_{part['id']}")
    if uploaded and st.button("Save image", type="primary", icon=":material/upload:"):
        set_part_image(part["id"], uploaded)
        record_audit_event(
            project_id,
            "Parts",
            "Save image",
            1,
            st.session_state.get("current_editor", ""),
            {
                "part_id": str(part["id"]),
                "part_number": str(part["part_number"]),
                "primary_cad_image_replaced_via": "upload",
            },
        )
        st.toast("Image attached", icon=":material/check_circle:")
        st.rerun()

    st.caption(
        "Or press Win+Shift+S, select a region, and paste it here. "
        "It saves immediately as the Primary CAD image."
    )
    primary_clipboard_key = f"clipboard_primary_{part['id']}"
    primary_pending_key = f"pending_primary_{part['id']}"
    st.session_state.pop(primary_pending_key, None)
    pasted = clipboard_image(key=primary_clipboard_key)
    pasted_payload = getattr(pasted, "image", None)
    if pasted_payload:
        try:
            primary_image = decode_clipboard_image(pasted_payload)
            set_part_image(part["id"], as_uploaded_file(primary_image))
            record_audit_event(
                project_id,
                "Parts",
                "Paste Primary CAD image",
                1,
                st.session_state.get("current_editor", ""),
                {"part_id": str(part["id"])},
            )
            st.toast(
                "Screenshot saved as the Primary CAD image",
                icon=":material/check_circle:",
            )
            st.rerun()
        except (OSError, ValueError) as exc:
            st.error(str(exc))

    st.subheader("Additional views")
    images = part_images(part["id"])
    for supplemental in images:
        supplemental_path = Path(supplemental["image_path"])
        if supplemental_path.exists():
            st.image(str(supplemental_path), caption=supplemental["caption"] or supplemental["image_type"])
    with st.form(f"supplemental_{part['id']}"):
        extra = st.file_uploader("Add an exploded or supplemental view", type=["png", "jpg", "jpeg", "webp"])
        image_type = st.selectbox("View type", ["Exploded assembly", "Alternate CAD view", "Prototype photo", "Quality detail", "Other"])
        caption = st.text_input("Caption")
        if st.form_submit_button("Add view", icon=":material/add_photo_alternate:"):
            if not extra:
                st.error("Choose an image first.")
            else:
                add_part_image(part["id"], extra, image_type, caption)
                record_audit_event(
                    project_id,
                    "Parts",
                    "Add view",
                    1,
                    st.session_state.get("current_editor", ""),
                    {
                        "part_id": str(part["id"]),
                        "part_number": str(part["part_number"]),
                        "supplemental_view_type_added": image_type,
                    },
                )
                st.toast("Additional view added", icon=":material/check_circle:")
                st.rerun()

with details_col.container(border=True):
    st.subheader(part["part_number"])
    st.write(part["description"] or "No part name")
    detail_cols = st.columns(2)
    detail_cols[0].metric("Design Maturity", part.get("design_maturity") or part.get("revision") or "—")
    detail_cols[1].metric("Source", part["source"])
    st.markdown(
        f"**Feature applicability:** "
        f"{assembly_grid_applicability_status(str(part['id']), part['model_applicability'])}"
    )
    col_meta1, col_meta2 = st.columns(2)
    with col_meta1:
        st.write("**Subsystem:**", part.get("subsystem") or "—")
        st.write("**Factory Nickname:**", part.get("factory_nickname") or part.get("official_windchill_part_name") or "—")
        st.write("**Design Engineer:**", part.get("design_engineer") or part.get("technology_engineer") or "—")
        st.write("**Part Code:**", part.get("part_code") or "—")
        st.write("**PPM:**", part.get("ppm") or "—")
    with col_meta2:
        st.write("**Buyer / GCL:**", part.get("buyer_gcl") or "—")
        st.write("**PMQE / AQE:**", part.get("pmqe_aqe") or "—")
        st.write("**AME / Tooling:**", part.get("ame_tooling_engineer") or "—")
        st.write("**Source Code:**", part.get("source_code") or "—")
    if part["notes"]:
        st.write(part["notes"])

    raw_assembly_id = part.get("assembly_id")
    assembly_id = (
        ""
        if raw_assembly_id is None or pd.isna(raw_assembly_id)
        else str(raw_assembly_id).strip()
    )
    st.subheader("Mini-BOM")
    mini_bom = pits_assembly_mini_bom(
        project_id,
        part_id=str(part.get("id") or ""),
        part_number=str(part.get("part_number") or ""),
        pits_tracker_number=str(part.get("pits_tracker_number") or ""),
    )
    if not mini_bom.empty:
        st.caption(
            f"Indented PITS BOM tree ({len(mini_bom)} component{'s' if len(mini_bom) != 1 else ''}) "
            "contained within this assembly."
        )
        mini_bom_display = mini_bom[
            ["tree_part_number", "part_name", "quantity", "level", "tracker_number", "make_buy"]
        ].rename(
            columns={
                "tree_part_number": "Part number",
                "part_name": "Part name",
                "quantity": "Quantity",
                "level": "Level",
                "tracker_number": "PITS Tracker",
                "make_buy": "Make / Buy",
            }
        )
        st.dataframe(
            mini_bom_display,
            hide_index=True,
            width="stretch",
            column_config={
                "Part number": st.column_config.TextColumn(
                    "Part number", pinned=True
                ),
                "Part name": st.column_config.TextColumn("Part name"),
                "Quantity": st.column_config.NumberColumn(
                    "Quantity", format="%g"
                ),
                "Level": st.column_config.TextColumn("Level", width="small"),
                "PITS Tracker": st.column_config.TextColumn("PITS Tracker", width="small"),
                "Make / Buy": st.column_config.TextColumn("Make / Buy", width="small"),
            },
        )
    elif assembly_id:
        st.caption(
            "Read-only completed-subassembly structure. Edit it from Assembly grid "
            "Details → Mini-BOM."
        )
        legacy_bom = assembly_bom_components(project_id, assembly_id)
        if legacy_bom.empty:
            st.caption("No sub-components found for this assembly in PITS BOM.")
        else:
            mini_bom_view = legacy_bom[
                ["part_number", "part_name", "quantity", "use_description"]
            ].rename(
                columns={
                    "part_number": "Part number",
                    "part_name": "Part name",
                    "quantity": "Quantity",
                    "use_description": "Fishbone use",
                }
            )
            st.dataframe(
                mini_bom_view,
                hide_index=True,
                width="stretch",
                column_config={
                    "Part number": st.column_config.TextColumn(
                        "Part number", pinned=True
                    ),
                    "Part name": st.column_config.TextColumn("Part name"),
                    "Quantity": st.column_config.NumberColumn(
                        "Quantity", format="%g"
                    ),
                    "Fishbone use": st.column_config.TextColumn("Fishbone use"),
                },
            )
    else:
        st.caption("No sub-components found for this part in PITS BOM.")

render_parts_history()
