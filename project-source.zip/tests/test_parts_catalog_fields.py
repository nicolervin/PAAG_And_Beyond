from __future__ import annotations

from contextlib import closing
import sqlite3
import unittest
from pathlib import Path
from unittest.mock import patch
from uuid import uuid4

from utils import store
from utils.project_transfer import export_project_package, import_project_package


class PartsCatalogFieldTests(unittest.TestCase):
    def setUp(self) -> None:
        self.database_path = store.DATA_DIR / f"test_parts_catalog_fields_{uuid4()}.db"
        self.database_patch = patch.object(store, "DB_PATH", self.database_path)
        self.database_patch.start()
        store.init_db()
        self.project_id = str(store.query("SELECT id FROM projects LIMIT 1")[0]["id"])
        self.scenario_id = str(store.planning_scenarios(self.project_id)[0]["id"])

    def tearDown(self) -> None:
        self.database_patch.stop()
        for suffix in ("", "-wal", "-shm"):
            Path(f"{self.database_path}{suffix}").unlink(missing_ok=True)

    def edited_parts(self):
        return store.project_table("parts", self.project_id, "part_number").copy()

    def test_new_row_display_only_columns_have_blank_defaults(self) -> None:
        page_source = (store.ROOT / "app_pages" / "parts.py").read_text(
            encoding="utf-8"
        )
        self.assertIn('"Photo status",\n            default="",', page_source)
        self.assertIn('st.column_config.TextColumn("Source", default="")', page_source)
        self.assertIn(
            'st.column_config.TextColumn("Updated", default="")', page_source
        )
        self.assertIn('parts_to_save.loc[new_row_mask, "source"] = "Manual"', page_source)

    def test_legacy_parts_table_migrates_without_rewriting_existing_data(self) -> None:
        legacy_path = store.DATA_DIR / f"test_parts_catalog_legacy_{uuid4()}.db"
        try:
            with closing(sqlite3.connect(legacy_path)) as conn:
                conn.execute(
                    """CREATE TABLE parts (
                       id TEXT PRIMARY KEY, project_id TEXT NOT NULL,
                       part_number TEXT NOT NULL, description TEXT DEFAULT '',
                       quantity REAL DEFAULT 1, revision TEXT DEFAULT '0',
                       source TEXT DEFAULT 'Manual', image_path TEXT DEFAULT '',
                       model_applicability TEXT DEFAULT 'All', notes TEXT DEFAULT '',
                       weight_lb REAL, updated_at TEXT NOT NULL,
                       UNIQUE(project_id, part_number))"""
                )
                conn.execute(
                    """INSERT INTO parts
                       (id, project_id, part_number, description, updated_at)
                       VALUES ('legacy-part', 'legacy-project', 'LEGACY-1',
                               'Preserve me', '2026-09-17T00:00:00+00:00')"""
                )
                conn.commit()
            with patch.object(store, "DB_PATH", legacy_path):
                store.init_db()
                store.init_db()
                migrated = store.query(
                    """SELECT description, technology_engineer, pits_tracker_number,
                              source_code, official_windchill_part_name, make_buy
                       FROM parts WHERE id='legacy-part'"""
                )[0]
            self.assertEqual(migrated["description"], "Preserve me")
            self.assertEqual(
                {
                    migrated["technology_engineer"], migrated["pits_tracker_number"],
                    migrated["source_code"], migrated["official_windchill_part_name"],
                    migrated["make_buy"],
                },
                {""},
            )
        finally:
            for suffix in ("", "-wal", "-shm"):
                Path(f"{legacy_path}{suffix}").unlink(missing_ok=True)

    def test_schema_upgrade_is_repeatable_and_fields_round_trip(self) -> None:
        store.init_db()
        columns = {
            row["name"] for row in store.query("PRAGMA table_info(parts)")
        }
        self.assertTrue(
            {
                "technology_engineer",
                "pits_tracker_number",
                "source_code",
                "official_windchill_part_name",
                "make_buy",
            }.issubset(columns)
        )

        edited = self.edited_parts()
        edited.loc[0, "technology_engineer"] = "  Alex Engineer  "
        edited.loc[0, "pits_tracker_number"] = "  00127  "
        edited.loc[0, "source_code"] = "4"
        edited.loc[0, "official_windchill_part_name"] = "  Official housing  "
        edited.loc[0, "make_buy"] = "Buy"
        part_id = str(edited.loc[0, "id"])
        store.update_part_rows(
            self.project_id,
            edited,
            scenario_id=self.scenario_id,
            activity_by_part={str(row["id"]): True for _, row in edited.iterrows()},
        )

        saved = store.query(
            """SELECT technology_engineer, pits_tracker_number, source_code,
                      official_windchill_part_name, make_buy
               FROM parts WHERE id=?""",
            (part_id,),
        )[0]
        self.assertEqual(saved["technology_engineer"], "Alex Engineer")
        self.assertEqual(saved["pits_tracker_number"], "00127")
        self.assertEqual(saved["source_code"], "4")
        self.assertEqual(saved["official_windchill_part_name"], "Official housing")
        self.assertEqual(saved["make_buy"], "Buy")

        edited = self.edited_parts()
        selected = edited["id"].astype(str) == part_id
        for field in (
            "technology_engineer", "pits_tracker_number", "source_code",
            "official_windchill_part_name", "make_buy",
        ):
            edited.loc[selected, field] = ""
        store.update_part_rows(self.project_id, edited)
        cleared = store.query(
            "SELECT technology_engineer, pits_tracker_number, source_code, official_windchill_part_name, make_buy FROM parts WHERE id=?",
            (part_id,),
        )[0]
        self.assertEqual(set(cleared.values()), {""})

    def test_validation_rejects_duplicate_tracker_and_invalid_controlled_values(self) -> None:
        edited = self.edited_parts()
        edited.loc[0, "pits_tracker_number"] = "PITS-7"
        edited.loc[1, "pits_tracker_number"] = " PITS-7 "
        with self.assertRaisesRegex(ValueError, "Duplicate PITS IDs.*PITS-7"):
            store.update_part_rows(self.project_id, edited)

        edited = self.edited_parts()
        edited.loc[0, "pits_tracker_number"] = "HIDDEN-1"
        store.update_part_rows(self.project_id, edited)
        filtered = self.edited_parts().iloc[[1]].copy()
        filtered.loc[filtered.index[0], "pits_tracker_number"] = " HIDDEN-1 "
        with self.assertRaisesRegex(ValueError, "Duplicate PITS IDs.*HIDDEN-1"):
            store.update_part_rows(self.project_id, filtered)

        edited = self.edited_parts()
        edited.loc[0, "source_code"] = "9"
        with self.assertRaisesRegex(ValueError, "Source Code"):
            store.update_part_rows(self.project_id, edited)

        edited = self.edited_parts()
        edited.loc[0, "make_buy"] = "Outsource"
        with self.assertRaisesRegex(ValueError, "Make vs Buy"):
            store.update_part_rows(self.project_id, edited)

    def test_upsert_without_new_fields_preserves_reviewed_values(self) -> None:
        part = self.edited_parts().iloc[0]
        store.upsert_part(
            self.project_id,
            {
                "part_number": str(part["part_number"]),
                "description": "Reviewed",
                "technology_engineer": "Taylor",
                "pits_tracker_number": "0008",
                "source_code": "8",
                "official_windchill_part_name": "Windchill name",
                "make_buy": "Make",
            },
        )
        store.upsert_part(
            self.project_id,
            {"part_number": str(part["part_number"]), "description": "MBOM refresh"},
        )
        legacy_contract = self.edited_parts()[
            [
                "id", "part_number", "description", "quantity", "revision",
                "model_applicability", "notes",
            ]
        ].copy()
        store.update_part_rows(self.project_id, legacy_contract)
        saved = store.query("SELECT * FROM parts WHERE id=?", (str(part["id"]),))[0]
        self.assertEqual(saved["technology_engineer"], "Taylor")
        self.assertEqual(saved["pits_tracker_number"], "0008")
        self.assertEqual(saved["source_code"], "8")
        self.assertEqual(saved["official_windchill_part_name"], "Windchill name")
        self.assertEqual(saved["make_buy"], "Make")

    def test_project_transfer_round_trips_new_fields(self) -> None:
        part = self.edited_parts().iloc[0]
        store.upsert_part(
            self.project_id,
            {
                "part_number": str(part["part_number"]),
                "description": str(part["description"]),
                "technology_engineer": "Morgan",
                "pits_tracker_number": "0042",
                "source_code": "2",
                "official_windchill_part_name": "Transferred name",
                "make_buy": "Buy",
            },
        )
        package = export_project_package(self.project_id, "Test editor")
        imported = import_project_package(package["data"], "Create new", "Test editor")
        copied = store.query(
            """SELECT technology_engineer, pits_tracker_number, source_code,
                      official_windchill_part_name, make_buy
               FROM parts WHERE project_id=? AND part_number=?""",
            (imported["project_id"], str(part["part_number"])),
        )[0]
        self.assertEqual(
            copied,
            {
                "technology_engineer": "Morgan",
                "pits_tracker_number": "0042",
                "source_code": "2",
                "official_windchill_part_name": "Transferred name",
                "make_buy": "Buy",
            },
        )

    def test_tracker_cross_functional_fields_and_aliases_round_trip(self) -> None:
        columns = {row["name"] for row in store.query("PRAGMA table_info(parts)")}
        expected_fields = {
            "design_engineer", "technology_engineer",
            "factory_nickname", "official_windchill_part_name",
            "ppm", "buyer_gcl", "pmqe_aqe", "ame_tooling_engineer", "part_code",
            "subsystem", "design_maturity",
        }
        self.assertTrue(expected_fields.issubset(columns))

        part = self.edited_parts().iloc[0]
        part_id = str(part["id"])

        # Test updating with new names: design_engineer, factory_nickname, design_maturity, subsystem
        store.upsert_part(
            self.project_id,
            {
                "part_number": str(part["part_number"]),
                "design_engineer": "Jordan DE",
                "factory_nickname": "Door Bracket Assembly",
                "ppm": "PPM-Pat",
                "buyer_gcl": "Buyer-Chris",
                "pmqe_aqe": "AQE-Sam",
                "ame_tooling_engineer": "AME-Riley",
                "part_code": "P-1099",
                "subsystem": "Door Systems",
                "design_maturity": "Pilot",
            },
        )

        saved = store.query(
            """SELECT design_engineer, technology_engineer, factory_nickname,
                      official_windchill_part_name, ppm, buyer_gcl, pmqe_aqe,
                      ame_tooling_engineer, part_code, subsystem, design_maturity, revision
               FROM parts WHERE id=?""",
            (part_id,),
        )[0]
        self.assertEqual(saved["design_engineer"], "Jordan DE")
        self.assertEqual(saved["technology_engineer"], "Jordan DE")
        self.assertEqual(saved["factory_nickname"], "Door Bracket Assembly")
        self.assertEqual(saved["official_windchill_part_name"], "Door Bracket Assembly")
        self.assertEqual(saved["ppm"], "PPM-Pat")
        self.assertEqual(saved["buyer_gcl"], "Buyer-Chris")
        self.assertEqual(saved["pmqe_aqe"], "AQE-Sam")
        self.assertEqual(saved["ame_tooling_engineer"], "AME-Riley")
        self.assertEqual(saved["part_code"], "P-1099")
        self.assertEqual(saved["subsystem"], "Door Systems")
        self.assertEqual(saved["design_maturity"], "Pilot")
        self.assertEqual(saved["revision"], "Pilot")

        # Test updating with legacy name revision syncs to design_maturity
        store.upsert_part(
            self.project_id,
            {
                "part_number": str(part["part_number"]),
                "technology_engineer": "Legacy DE",
                "official_windchill_part_name": "Legacy Nickname",
                "revision": "Rev-C",
            },
        )
        synced = store.query(
            """SELECT design_engineer, technology_engineer, factory_nickname,
                      official_windchill_part_name, design_maturity, revision
               FROM parts WHERE id=?""",
            (part_id,),
        )[0]
        self.assertEqual(synced["design_engineer"], "Legacy DE")
        self.assertEqual(synced["technology_engineer"], "Legacy DE")
        self.assertEqual(synced["factory_nickname"], "Legacy Nickname")
        self.assertEqual(synced["official_windchill_part_name"], "Legacy Nickname")
        self.assertEqual(synced["design_maturity"], "Rev-C")
        self.assertEqual(synced["revision"], "Rev-C")

    def test_import_pits_id_snapshot_stores_cross_functional_fields(self) -> None:
        tracker_record = {
            "pits_id": "0099",
            "part_number": "PITS-TRACKER-001",
            "description": "Cross Functional Test Part",
            "quantity": 2,
            "revision": "B",
            "source_code": "3",
            "design_engineer": "Casey Design",
            "ppm": "Morgan PPM",
            "buyer_gcl": "Taylor Buyer",
            "pmqe_aqe": "Alex AQE",
            "ame_tooling_engineer": "Logan AME",
            "part_code": "PC-5501",
            "used_bom": "Yes",
            "status": "Active",
            "subsystem": "Doors",
            "design_maturity": "Proto",
            "comments": "Test comment",
            "workstation": "WS-1",
            "source_row": 2,
            "source_payload": {},
        }
        res = store.import_pits_id_snapshot(
            self.project_id,
            [tracker_record],
            models=[],
            editor_name="Test Importer",
            scenario_id=self.scenario_id,
        )
        self.assertGreaterEqual(res["new"], 1)

        saved = store.query(
            """SELECT design_engineer, technology_engineer, factory_nickname,
                      ppm, buyer_gcl, pmqe_aqe, ame_tooling_engineer, part_code,
                      subsystem, design_maturity, revision
               FROM parts WHERE project_id=? AND part_number=?""",
            (self.project_id, "PITS-TRACKER-001"),
        )[0]
        self.assertEqual(saved["design_engineer"], "Casey Design")
        self.assertEqual(saved["technology_engineer"], "Casey Design")
        self.assertEqual(saved["ppm"], "Morgan PPM")
        self.assertEqual(saved["buyer_gcl"], "Taylor Buyer")
        self.assertEqual(saved["pmqe_aqe"], "Alex AQE")
        self.assertEqual(saved["ame_tooling_engineer"], "Logan AME")
        self.assertEqual(saved["part_code"], "PC-5501")
        self.assertEqual(saved["subsystem"], "Doors")
        self.assertEqual(saved["design_maturity"], "Proto")
        self.assertEqual(saved["revision"], "B")

        # Test importing a record where only design_maturity is provided (maps to revision)
        dm_only_record = {
            "pits_id": "0100",
            "part_number": "PITS-TRACKER-002",
            "description": "Design Maturity Only Part",
            "quantity": 1,
            "source_code": "1",
            "used_bom": "Yes",
            "status": "Active",
            "subsystem": "Chassis",
            "design_maturity": "Production",
            "comments": "",
            "workstation": "Line 2",
            "source_row": 3,
            "source_payload": {},
        }
        store.import_pits_id_snapshot(
            self.project_id,
            [dm_only_record],
            models=[],
            editor_name="Test Importer",
            scenario_id=self.scenario_id,
        )
        saved2 = store.query(
            "SELECT subsystem, design_maturity, revision FROM parts WHERE project_id=? AND part_number=?",
            (self.project_id, "PITS-TRACKER-002"),
        )[0]
        self.assertEqual(saved2["subsystem"], "Chassis")
        self.assertEqual(saved2["design_maturity"], "Production")
        self.assertEqual(saved2["revision"], "Production")

    def test_pits_assembly_mini_bom_returns_indented_tree(self) -> None:
        parent_id = str(uuid4())
        c1_id = str(uuid4())
        c2_id = str(uuid4())
        c3_id = str(uuid4())
        sibling_id = str(uuid4())
        now = store.now_iso()

        with store.connection() as conn:
            conn.execute(
                """INSERT INTO parts (id, project_id, part_number, description, pits_tracker_number, updated_at)
                   VALUES (?, ?, 'ASM-100G01', 'Main Door Asm', '100', ?)""",
                (parent_id, self.project_id, now),
            )
            conn.execute(
                """INSERT INTO parts (id, project_id, part_number, description, pits_tracker_number, updated_at)
                   VALUES (?, ?, 'COMP-101', 'Door Gasket', '101', ?)""",
                (c1_id, self.project_id, now),
            )
            conn.execute(
                """INSERT INTO parts (id, project_id, part_number, description, pits_tracker_number, updated_at)
                   VALUES (?, ?, 'COMP-102G01', 'Handle Sub-Asm', '102', ?)""",
                (c2_id, self.project_id, now),
            )
            conn.execute(
                """INSERT INTO parts (id, project_id, part_number, description, pits_tracker_number, updated_at)
                   VALUES (?, ?, 'COMP-103', 'Handle Screw', '103', ?)""",
                (c3_id, self.project_id, now),
            )
            conn.execute(
                """INSERT INTO parts (id, project_id, part_number, description, pits_tracker_number, updated_at)
                   VALUES (?, ?, 'ASM-200G01', 'Sibling Top Unit', '200', ?)""",
                (sibling_id, self.project_id, now),
            )

        import_id = str(uuid4())
        store.execute(
            """INSERT INTO pits_bom_imports (
                id, project_id, import_sequence, workbook_name, workbook_sha256,
                bom_sheet_name, source_row_count, occurrence_count, issue_count,
                imported_by, imported_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (import_id, self.project_id, 1, "test.xlsx", "sha", "BOM", 5, 5, 0, "tester", now),
        )

        def add_occ(parent_trk: str, child_trk: str, child_pid: str | None, depth: int, qty: float, row_num: int):
            store.execute(
                """INSERT INTO pits_bom_occurrences (
                    id, project_id, parent_tracker_number, child_tracker_number, child_part_id,
                    proposed_depth, proposed_quantity, raw_quantity_text, source_row,
                    source_fingerprint, first_seen_import_id, last_seen_import_id,
                    first_seen_at, last_seen_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    str(uuid4()), self.project_id, parent_trk, child_trk, child_pid,
                    depth, qty, str(qty), row_num,
                    f"fp_{child_trk}", import_id, import_id,
                    now, now, now,
                ),
            )

        add_occ("", "100", parent_id, 2, 1.0, 10)
        add_occ("100", "101", c1_id, 3, 2.0, 11)
        add_occ("100", "102", c2_id, 3, 1.0, 12)
        add_occ("102", "103", c3_id, 4, 4.0, 13)
        add_occ("", "200", sibling_id, 2, 1.0, 14)

        mini_bom = store.pits_assembly_mini_bom(
            self.project_id,
            part_id=parent_id,
            part_number="ASM-100G01",
            pits_tracker_number="100",
        )
        self.assertEqual(len(mini_bom), 3)
        self.assertEqual(list(mini_bom["part_number"]), ["COMP-101", "COMP-102G01", "COMP-103"])
        self.assertEqual(list(mini_bom["level"]), ["L3", "L3", "L4"])
        self.assertEqual(list(mini_bom["quantity"]), [2.0, 1.0, 4.0])
        # Verify relative indentation: L3 is rel_depth 1 (plain), L4 is rel_depth 2 (indented with ↳)
        self.assertEqual(mini_bom.iloc[0]["tree_part_number"], "COMP-101")
        self.assertEqual(mini_bom.iloc[1]["tree_part_number"], "COMP-102G01")
        self.assertIn("↳", mini_bom.iloc[2]["tree_part_number"])
        self.assertIn("COMP-103", mini_bom.iloc[2]["tree_part_number"])

        # Sub-assembly COMP-102G01 should also have its own Mini-BOM containing COMP-103
        sub_bom = store.pits_assembly_mini_bom(
            self.project_id,
            part_id=c2_id,
            part_number="COMP-102G01",
            pits_tracker_number="102",
        )
        self.assertEqual(len(sub_bom), 1)
        self.assertEqual(sub_bom.iloc[0]["part_number"], "COMP-103")
        self.assertEqual(sub_bom.iloc[0]["quantity"], 4.0)

        # Leaf part COMP-103 should have an empty Mini-BOM
        leaf_bom = store.pits_assembly_mini_bom(
            self.project_id,
            part_id=c3_id,
            part_number="COMP-103",
            pits_tracker_number="103",
        )
        self.assertTrue(leaf_bom.empty)

    def test_assembly_grid_hidden_from_navigation_bar(self) -> None:
        streamlit_app_code = (store.ROOT / "streamlit_app.py").read_text(encoding="utf-8")
        # Ensure Assembly grid is not inside the Product structure visible navigation
        product_struct_section = streamlit_app_code.split('"Product structure": [')[1].split(']')[0]
        self.assertNotIn("app_pages/assemblies.py", product_struct_section)
        # Ensure it is still registered in unlisted_pages for internal navigation and smoke checks
        self.assertIn("unlisted_pages", streamlit_app_code)
        self.assertIn('st.Page("app_pages/assemblies.py"', streamlit_app_code)


if __name__ == "__main__":
    unittest.main()


